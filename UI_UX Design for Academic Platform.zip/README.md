
  # UI/UX Design for Academic Platform

  This is a code bundle for UI/UX Design for Academic Platform. The original project is available at https://www.figma.com/design/cMOgwrUDK8XwjiN8yroUaB/UI-UX-Design-for-Academic-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
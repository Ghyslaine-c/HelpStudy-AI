import { useState, useEffect, useRef, useCallback } from "react";
import {
  BookOpen, Brain, BarChart3, Bell, Calendar, Users, MessageSquare,
  Star, ChevronRight, GraduationCap, Sparkles, Shield, Zap, Globe,
  Menu, X, ArrowRight, CheckCircle, TrendingUp, Clock, Target,
  Lightbulb, Phone, Mail, MapPin, Send, Lock, Eye, EyeOff, LogIn,
  LayoutDashboard, FileText, ClipboardList, Award, RefreshCw, User,
  History, Settings, LogOut, ChevronDown, ChevronLeft, Plus, Edit2,
  Trash2, Search, Download, AlertCircle, Activity, Filter,
  ChevronUp, UserCog, BookMarked, Layers, MoreHorizontal,
  CheckSquare, Sliders, BellRing, Palette, HelpCircle, Upload,
  PieChart as PieChartIcon,
} from "lucide-react";
import {
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, AreaChart, Area,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from "recharts";

// ── TYPES ──────────────────────────────────────────────────────────────────
type View =
  | "landing" | "profile-select"
  | "s-dashboard" | "s-courses" | "s-course-detail" | "s-grades"
  | "s-retake" | "s-schedule" | "s-announcements" | "s-profile"
  | "s-ai-chat" | "s-ai-history" | "s-settings"
  | "a-dashboard" | "a-students" | "a-registrations" | "a-courses"
  | "a-grades" | "a-announcements" | "a-statistics"
  | "a-users" | "a-activity" | "a-settings";

type Role = "student" | "admin";
interface AiMsg { id: number; role: "user" | "ai"; content: string; time: string; }
interface Student { id: number; name: string; matricule: string; filiere: string; niveau: string; email: string; moyenne: number; status: string; }
interface Course { id: number; name: string; code: string; prof: string; dept: string; credits: number; enrolled: number; color: string; }
interface NavItem { label: string; icon: React.ElementType; view: View; }
interface Notif { id: number; title: string; body: string; time: string; read: boolean; type: "info" | "warning" | "success" | "error"; }

// ── DATA ───────────────────────────────────────────────────────────────────
const COURSES_BASE: Course[] = [
  { id: 1, name: "Algorithmes Avancés", code: "INFO301", prof: "Dr. Benali", dept: "Informatique", credits: 6, enrolled: 142, color: "#1d4ed8" },
  { id: 2, name: "Base de Données", code: "INFO302", prof: "Dr. Yousfi", dept: "Informatique", credits: 4, enrolled: 138, color: "#10b981" },
  { id: 3, name: "Réseaux Informatiques", code: "INFO303", prof: "Dr. Hamid", dept: "Informatique", credits: 4, enrolled: 97, color: "#8b5cf6" },
  { id: 4, name: "Analyse Numérique", code: "MATH301", prof: "Dr. Farid", dept: "Mathématiques", credits: 3, enrolled: 215, color: "#f59e0b" },
  { id: 5, name: "Génie Logiciel", code: "INFO304", prof: "Dr. Moulai", dept: "Informatique", credits: 5, enrolled: 88, color: "#ef4444" },
  { id: 6, name: "Intelligence Artificielle", code: "INFO401", prof: "Dr. Zerhouni", dept: "Informatique", credits: 6, enrolled: 73, color: "#06b6d4" },
];
const STUDENT_PROGRESS = [78, 65, 90, 45, 55, 30];
const STUDENT_GRADES_NUM: (number | null)[] = [15.5, 14.0, 17.0, 11.5, 13.0, null];
const GRADES_TABLE = [
  { course: "Algorithmes Avancés", code: "INFO301", cc: 16, td: 15, tp: 16, exam: 15, final: 15.5, coeff: 3, credits: 6, status: "Admis" },
  { course: "Base de Données", code: "INFO302", cc: 13, td: 14, tp: 15, exam: 14, final: 14.0, coeff: 2, credits: 4, status: "Admis" },
  { course: "Réseaux Informatiques", code: "INFO303", cc: 17, td: 18, tp: 17, exam: 17, final: 17.0, coeff: 2, credits: 4, status: "Admis" },
  { course: "Analyse Numérique", code: "MATH301", cc: 11, td: 10, tp: null, exam: 11, final: 11.5, coeff: 2, credits: 3, status: "Admis" },
  { course: "Génie Logiciel", code: "INFO304", cc: 12, td: 13, tp: 14, exam: 12, final: 13.0, coeff: 3, credits: 5, status: "Admis" },
  { course: "Intelligence Artificielle", code: "INFO401", cc: null, td: null, tp: null, exam: null, final: null, coeff: 3, credits: 6, status: "En cours" },
];
const GRADE_PROGRESSION = [
  { sem: "S1 L1", avg: 11.8 }, { sem: "S2 L1", avg: 12.5 },
  { sem: "S1 L2", avg: 13.2 }, { sem: "S2 L2", avg: 13.9 },
  { sem: "S1 L3", avg: 14.5 }, { sem: "S2 L3 (en cours)", avg: 14.2 },
];
const SCHEDULE_SLOTS = ["08h – 10h", "10h – 12h", "14h – 16h", "16h – 18h"];
const SCHEDULE_DAYS = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
type SlotCell = null | { name: string; room: string; type: string; color: string };
const SCHEDULE_GRID: Record<string, SlotCell[]> = {
  "Lundi":    [{ name: "Algorithmes Avancés", room: "A101", type: "CM", color: "#1d4ed8" }, null, { name: "TP Base de Données", room: "Info 2", type: "TP", color: "#10b981" }, null],
  "Mardi":    [null, { name: "Algo — TD", room: "A101", type: "TD", color: "#1d4ed8" }, null, { name: "TP Algorithmes", room: "Info 1", type: "TP", color: "#1d4ed8" }],
  "Mercredi": [{ name: "Base de Données", room: "Amphi B", type: "CM", color: "#10b981" }, null, { name: "Réseaux Info.", room: "B203", type: "CM", color: "#8b5cf6" }, null],
  "Jeudi":    [null, { name: "Génie Logiciel", room: "A205", type: "CM", color: "#ef4444" }, null, { name: "TP Génie Log.", room: "Info 3", type: "TP", color: "#ef4444" }],
  "Vendredi": [{ name: "TP Réseaux", room: "Info 2", type: "TP", color: "#8b5cf6" }, null, { name: "Analyse Num.", room: "A101", type: "TD", color: "#f59e0b" }, null],
  "Samedi":   [{ name: "Analyse Num.", room: "Amphi A", type: "CM", color: "#f59e0b" }, { name: "Intelligence Art.", room: "Amphi C", type: "CM", color: "#06b6d4" }, null, null],
};
const ANNOUNCEMENTS_DATA = [
  { id: 1, title: "Examen d'Algorithmes Avancés", content: "L'examen final aura lieu le 15 janvier 2024 à 09h00 en Amphi A. Toute la matière du semestre est au programme.", date: "10 Jan 2024", author: "Dr. Benali", type: "Examen", urgent: true },
  { id: 2, title: "Dépôt des projets de Génie Logiciel", content: "Les projets de fin de semestre doivent être déposés avant le 20 janvier 2024 à minuit.", date: "8 Jan 2024", author: "Dr. Moulai", type: "Devoir", urgent: false },
  { id: 3, title: "Conférence IA & Machine Learning", content: "Conférence sur les dernières avancées en IA le 12 janvier. Participation fortement recommandée.", date: "5 Jan 2024", author: "Administration", type: "Événement", urgent: false },
  { id: 4, title: "Inscription aux examens de rattrapage", content: "Les inscriptions aux rattrapages sont ouvertes du 18 au 22 janvier 2024 sur la plateforme.", date: "3 Jan 2024", author: "Scolarité", type: "Inscription", urgent: true },
  { id: 5, title: "Maintenance plateforme", content: "La plateforme sera indisponible le 7 janvier de 00h à 04h pour maintenance.", date: "1 Jan 2024", author: "Admin Technique", type: "Info", urgent: false },
];
const INIT_STUDENTS: Student[] = [
  { id: 1, name: "Amina Benali", matricule: "20210001", filiere: "Informatique", niveau: "L3", email: "a.benali@univ.dz", moyenne: 15.4, status: "Actif" },
  { id: 2, name: "Youssef Alaoui", matricule: "20210002", filiere: "Génie Civil", niveau: "M1", email: "y.alaoui@univ.dz", moyenne: 13.8, status: "Actif" },
  { id: 3, name: "Sara Mansouri", matricule: "20210003", filiere: "Informatique", niveau: "L3", email: "s.mansouri@univ.dz", moyenne: 11.2, status: "Actif" },
  { id: 4, name: "Karim Hadj", matricule: "20210004", filiere: "Mathématiques", niveau: "L2", email: "k.hadj@univ.dz", moyenne: 9.5, status: "Avertissement" },
  { id: 5, name: "Nadia Boukhari", matricule: "20210005", filiere: "Physique", niveau: "L3", email: "n.boukhari@univ.dz", moyenne: 16.1, status: "Actif" },
  { id: 6, name: "Rachid Benkhalil", matricule: "20210006", filiere: "Chimie", niveau: "M2", email: "r.benkhalil@univ.dz", moyenne: 14.7, status: "Actif" },
  { id: 7, name: "Fatima Zerrouk", matricule: "20210007", filiere: "Informatique", niveau: "L2", email: "f.zerrouk@univ.dz", moyenne: 8.3, status: "En risque" },
  { id: 8, name: "Omar Tabet", matricule: "20210008", filiere: "Génie Électrique", niveau: "M1", email: "o.tabet@univ.dz", moyenne: 15.9, status: "Actif" },
  { id: 9, name: "Lina Cherif", matricule: "20210009", filiere: "Biologie", niveau: "L1", email: "l.cherif@univ.dz", moyenne: 12.6, status: "Actif" },
  { id: 10, name: "Mehdi Saadaoui", matricule: "20210010", filiere: "Informatique", niveau: "M2", email: "m.saadaoui@univ.dz", moyenne: 17.2, status: "Actif" },
];
const INIT_NOTIFS: Notif[] = [
  { id: 1, title: "Examen imminent", body: "L'examen d'Algorithmes Avancés a lieu dans 5 jours.", time: "Il y a 10 min", read: false, type: "warning" },
  { id: 2, title: "Note publiée", body: "Votre note de Réseaux Informatiques est disponible : 17.0/20", time: "Il y a 1h", read: false, type: "success" },
  { id: 3, title: "Nouveau devoir", body: "Dr. Moulai a publié le sujet du projet de Génie Logiciel.", time: "Il y a 3h", read: false, type: "info" },
  { id: 4, title: "Rappel inscription", body: "Date limite d'inscription au rattrapage : 22 janvier 2024.", time: "Hier", read: true, type: "warning" },
  { id: 5, title: "Conférence IA", body: "La conférence IA & Machine Learning commence dans 2 jours.", time: "Hier", read: true, type: "info" },
];
const AI_SUGGESTIONS = ["Explique-moi les arbres AVL", "Comment préparer l'examen de BDD ?", "Complexité algorithmique O(n log n)", "Protocoles TCP et UDP"];
const AI_RESPONSES_MAP = [
  { keywords: ["avl", "arbre", "rouge", "noir"], response: "**Arbres AVL vs Arbres Rouge-Noir :**\n\n**Arbre AVL :**\n• Équilibrage strict (différence de hauteur max = 1)\n• Recherche très rapide\n• Insertions/suppressions coûteuses\n\n**Arbre Rouge-Noir :**\n• Équilibrage souple, insertions rapides\n• Utilisé dans Java TreeMap et C++ std::map\n\n**Résumé :** AVL = recherche intensive · Rouge-Noir = modifications fréquentes" },
  { keywords: ["complexité", "algorithme", "big o", "o(n)"], response: "**Complexité algorithmique :**\n\n• **O(1)** — Accès tableau, hashmap\n• **O(log n)** — Recherche binaire, arbres équilibrés\n• **O(n)** — Parcours liste\n• **O(n log n)** — Tri fusion, heapsort\n• **O(n²)** — Tri bulles\n\nPour INFO301, concentrez-vous sur O(log n) et O(n log n) aux examens." },
  { keywords: ["bdd", "base de données", "sql", "jointure"], response: "**Préparer l'examen de Base de Données :**\n\n1. Maîtrisez les **formes normales** (1NF → BCNF)\n2. Pratiquez les **requêtes SQL** : SELECT, JOIN, GROUP BY, HAVING\n3. Comprenez les **transactions** : propriétés ACID\n4. Révisez le **modèle entité-association**\n\nJe recommande de refaire les TDs 3, 4 et 5 sur les jointures complexes." },
  { keywords: ["tcp", "udp", "réseau", "protocole"], response: "**Points clés — Réseaux Informatiques :**\n\n• **Modèle OSI** : 7 couches (Physique → Application)\n• **TCP** : fiable, connexion établie, garantie de livraison\n• **UDP** : rapide, sans connexion, pas de garantie\n• **Protocoles** : HTTP/S, DNS, DHCP, ARP, ICMP\n\nPour les TPs, maîtrisez Wireshark pour analyser les trames réseau." },
  { keywords: ["règlement", "procédure", "inscription", "rattrapage"], response: "**Procédures et règlements universitaires :**\n\n• **Inscriptions** : Se font en ligne avant le 15 septembre de chaque année\n• **Rattrapage** : Accessible pour toute note < 10/20, inscription via la plateforme\n• **Absences** : Plus de 25% d'absences entraîne l'interdiction d'examen\n• **Réclamations** : Formulaire à déposer dans les 5 jours après publication des notes\n\nSouhaitez-vous plus d'informations sur un point spécifique ?" },
];
const getAiResponse = (input: string) => {
  const lower = input.toLowerCase();
  for (const { keywords, response } of AI_RESPONSES_MAP) {
    if (keywords.some((k) => lower.includes(k))) return response;
  }
  return `Bonne question concernant "${input}" !\n\nVoici ce que je peux vous dire :\n\n1. Consultez le **cours magistral** correspondant sur la plateforme\n2. Révisez les **exercices de TD** sur ce thème\n3. Consultez votre enseignant lors des séances de permanence\n\nPuis-je vous aider à créer un quiz de révision ou vous expliquer un concept précis de ce sujet ?`;
};
const GRADE_DIST = [
  { mention: "Très Bien", count: 23, fill: "#10b981" },
  { mention: "Bien", count: 45, fill: "#1d4ed8" },
  { mention: "Assez Bien", count: 67, fill: "#8b5cf6" },
  { mention: "Passable", count: 38, fill: "#f59e0b" },
  { mention: "Ajourné", count: 27, fill: "#ef4444" },
];
const MONTHLY_DATA = [
  { month: "Sep", inscrits: 1820, presents: 1640 },
  { month: "Oct", inscrits: 1780, presents: 1620 },
  { month: "Nov", inscrits: 1750, presents: 1580 },
  { month: "Déc", inscrits: 1680, presents: 1420 },
  { month: "Jan", inscrits: 1710, presents: 1540 },
  { month: "Fév", inscrits: 1695, presents: 1560 },
];
const DEPT_DATA = [
  { dept: "Informatique", reussite: 78, etudiants: 420 },
  { dept: "Mathématiques", reussite: 65, etudiants: 380 },
  { dept: "Physique", reussite: 71, etudiants: 290 },
  { dept: "Génie Civil", reussite: 82, etudiants: 340 },
  { dept: "Chimie", reussite: 69, etudiants: 210 },
];
const SEM_AVG = [
  { sem: "S1 21", avg: 12.4 }, { sem: "S2 21", avg: 13.1 },
  { sem: "S1 22", avg: 13.8 }, { sem: "S2 22", avg: 14.2 },
  { sem: "S1 23", avg: 14.7 }, { sem: "S2 23", avg: 15.1 },
];
const ACTIVITY_LOG = [
  { id: 1, user: "Dr. Benali", action: "Publication d'annonce", detail: "Examen INFO301 — 15 Jan 2024", time: "Il y a 15 min", type: "info" },
  { id: 2, user: "Admin Principal", action: "Ajout étudiant", detail: "Nouvel étudiant : Khalil Meziane (20210011)", time: "Il y a 1h", type: "success" },
  { id: 3, user: "Scolarité", action: "Mise à jour notes", detail: "Notes S1 publiées — 142 étudiants INFO", time: "Il y a 2h", type: "success" },
  { id: 4, user: "Admin Principal", action: "Suppression cours", detail: "Cours optionnel MATH401 supprimé", time: "Il y a 4h", type: "warning" },
  { id: 5, user: "Dr. Yousfi", action: "Modification cours", detail: "BDD INFO302 — ajout module NoSQL", time: "Hier, 16h30", type: "info" },
  { id: 6, user: "Scolarité", action: "Inscriptions ouvertes", detail: "Rattrapage session Jan 2024 — 156 inscriptions", time: "Hier, 09h00", type: "info" },
  { id: 7, user: "Admin Principal", action: "Import PDF", detail: "Supports de cours Algo Avancés — 8 fichiers", time: "Il y a 2 jours", type: "success" },
];
const SEARCH_INDEX = [
  { label: "Algorithmes Avancés", type: "Cours", view: "s-courses" as View, icon: BookOpen },
  { label: "Amina Benali — 20210001", type: "Étudiant", view: "a-students" as View, icon: User },
  { label: "Examen d'Algorithmes Avancés", type: "Annonce", view: "s-announcements" as View, icon: Bell },
  { label: "Réseaux Informatiques", type: "Cours", view: "s-courses" as View, icon: BookOpen },
  { label: "Mes Notes", type: "Page", view: "s-grades" as View, icon: Award },
  { label: "Tableau de bord", type: "Page", view: "s-dashboard" as View, icon: LayoutDashboard },
  { label: "Mehdi Saadaoui — 20210010", type: "Étudiant", view: "a-students" as View, icon: User },
  { label: "Emploi du Temps", type: "Page", view: "s-schedule" as View, icon: Calendar },
];

// ── UI HELPERS ─────────────────────────────────────────────────────────────
type BadgeVariant = "default" | "success" | "warning" | "danger" | "info";
function Badge({ children, variant = "default" }: { children: React.ReactNode; variant?: BadgeVariant }) {
  const s: Record<BadgeVariant, string> = {
    default: "bg-muted text-muted-foreground",
    success: "bg-emerald-100 text-emerald-700",
    warning: "bg-amber-100 text-amber-700",
    danger: "bg-red-100 text-red-700",
    info: "bg-blue-100 text-blue-700",
  };
  return <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold ${s[variant]}`}>{children}</span>;
}

type CardColor = "blue" | "green" | "amber" | "purple" | "red";
function StatCard({ icon: Icon, label, value, sub, color = "blue", trend }: {
  icon: React.ElementType; label: string; value: string | number; sub?: string; color?: CardColor; trend?: "up" | "down";
}) {
  const c: Record<CardColor, string> = { blue: "bg-blue-50 text-blue-600", green: "bg-emerald-50 text-emerald-600", amber: "bg-amber-50 text-amber-600", purple: "bg-violet-50 text-violet-600", red: "bg-red-50 text-red-600" };
  return (
    <div className="bg-card rounded-2xl border border-border p-5 flex items-start gap-4 hover:shadow-md transition-all duration-200 group">
      <div className={`w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 transition-transform duration-200 group-hover:scale-110 ${c[color]}`}><Icon className="w-5 h-5" /></div>
      <div className="min-w-0 flex-1">
        <div className="text-2xl font-bold text-foreground">{value}</div>
        <div className="text-sm font-medium text-foreground">{label}</div>
        {sub && <div className={`text-xs mt-0.5 flex items-center gap-1 ${trend === "up" ? "text-emerald-600" : trend === "down" ? "text-red-500" : "text-muted-foreground"}`}>
          {trend === "up" && <TrendingUp className="w-3 h-3" />}
          {trend === "down" && <ChevronDown className="w-3 h-3" />}
          {sub}
        </div>}
      </div>
    </div>
  );
}

function PageHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between mb-6 flex-wrap gap-3">
      <div><h1 className="text-2xl font-bold text-foreground">{title}</h1>{subtitle && <p className="text-sm text-muted-foreground mt-0.5">{subtitle}</p>}</div>
      {action}
    </div>
  );
}

function Modal({ open, onClose, title, children, size = "md" }: { open: boolean; onClose: () => void; title: string; children: React.ReactNode; size?: "sm" | "md" | "lg" }) {
  if (!open) return null;
  const w = { sm: "max-w-sm", md: "max-w-lg", lg: "max-w-2xl" };
  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm animate-[fadeIn_0.15s_ease]" onClick={onClose} />
      <div className={`relative bg-card rounded-2xl border border-border shadow-2xl w-full ${w[size]} max-h-[90vh] overflow-y-auto animate-[slideUp_0.2s_ease]`}>
        <div className="flex items-center justify-between p-5 border-b border-border">
          <h2 className="text-base font-bold text-foreground">{title}</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-muted flex items-center justify-center hover:bg-red-50 hover:text-red-500 transition-colors duration-150"><X className="w-4 h-4" /></button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

function ConfirmModal({ open, onClose, onConfirm, title, message, confirmLabel = "Confirmer", variant = "danger" }: {
  open: boolean; onClose: () => void; onConfirm: () => void; title: string; message: string; confirmLabel?: string; variant?: "danger" | "warning";
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[300] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-card rounded-2xl border border-border shadow-2xl w-full max-w-sm p-6 text-center">
        <div className={`w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-4 ${variant === "danger" ? "bg-red-100" : "bg-amber-100"}`}>
          <AlertCircle className={`w-7 h-7 ${variant === "danger" ? "text-red-500" : "text-amber-500"}`} />
        </div>
        <h3 className="text-base font-bold text-foreground mb-2">{title}</h3>
        <p className="text-sm text-muted-foreground mb-6">{message}</p>
        <div className="flex gap-3">
          <button onClick={onConfirm} className={`flex-1 py-2.5 text-sm font-semibold text-white rounded-xl transition-all duration-150 active:scale-95 ${variant === "danger" ? "bg-red-500 hover:bg-red-600" : "bg-amber-500 hover:bg-amber-600"}`}>{confirmLabel}</button>
          <button onClick={onClose} className="flex-1 py-2.5 text-sm font-semibold text-muted-foreground bg-muted rounded-xl hover:bg-muted/80 transition-all duration-150 active:scale-95">Annuler</button>
        </div>
      </div>
    </div>
  );
}

function InputField({ label, type = "text", value, onChange, placeholder, icon: Icon, required }: {
  label: string; type?: string; value: string; onChange: (v: string) => void; placeholder?: string; icon?: React.ElementType; required?: boolean;
}) {
  return (
    <div>
      <label className="text-xs font-semibold text-foreground mb-1 block">{label}{required && <span className="text-red-500 ml-0.5">*</span>}</label>
      <div className="relative">
        {Icon && <Icon className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />}
        <input type={type} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} required={required}
          className={`w-full ${Icon ? "pl-10" : "pl-3.5"} pr-4 py-2.5 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all duration-150 placeholder:text-muted-foreground/60`} />
      </div>
    </div>
  );
}

function SelectField({ label, value, onChange, options, required }: { label: string; value: string; onChange: (v: string) => void; options: string[]; required?: boolean }) {
  return (
    <div>
      <label className="text-xs font-semibold text-foreground mb-1 block">{label}{required && <span className="text-red-500 ml-0.5">*</span>}</label>
      <select value={value} onChange={(e) => onChange(e.target.value)} required={required}
        className="w-full px-3.5 py-2.5 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all duration-150 text-foreground">
        <option value="">Sélectionner</option>
        {options.map((o) => <option key={o}>{o}</option>)}
      </select>
    </div>
  );
}

function Btn({ children, onClick, variant = "primary", size = "md", disabled, icon: Icon, type = "button" }: {
  children?: React.ReactNode; onClick?: () => void; variant?: "primary" | "secondary" | "outline" | "ghost" | "danger"; size?: "sm" | "md" | "lg";
  disabled?: boolean; icon?: React.ElementType; type?: "button" | "submit";
}) {
  const variants = {
    primary: "bg-primary text-white hover:bg-blue-700 shadow-sm hover:shadow-md",
    secondary: "bg-accent text-white hover:bg-emerald-600 shadow-sm",
    outline: "border border-primary/40 text-primary hover:bg-primary/5",
    ghost: "text-muted-foreground hover:bg-muted hover:text-foreground",
    danger: "bg-red-500 text-white hover:bg-red-600 shadow-sm",
  };
  const sizes = { sm: "px-3 py-1.5 text-xs gap-1.5", md: "px-4 py-2 text-sm gap-2", lg: "px-6 py-2.5 text-sm gap-2" };
  return (
    <button type={type} onClick={onClick} disabled={disabled}
      className={`inline-flex items-center justify-center font-semibold rounded-xl transition-all duration-150 active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed disabled:active:scale-100 ${variants[variant]} ${sizes[size]}`}>
      {Icon && <Icon className="w-4 h-4 flex-shrink-0" />}
      {children}
    </button>
  );
}

// ── SIDEBAR ────────────────────────────────────────────────────────────────
const STUDENT_NAV: NavItem[] = [
  { label: "Tableau de bord", icon: LayoutDashboard, view: "s-dashboard" },
  { label: "Mes Cours", icon: BookOpen, view: "s-courses" },
  { label: "Mes Notes", icon: Award, view: "s-grades" },
  { label: "Cours à reprendre", icon: RefreshCw, view: "s-retake" },
  { label: "Horaire", icon: Calendar, view: "s-schedule" },
  { label: "Annonces", icon: Bell, view: "s-announcements" },
  { label: "Assistant IA", icon: Brain, view: "s-ai-chat" },
  { label: "Historique IA", icon: History, view: "s-ai-history" },
  { label: "Mon Profil", icon: User, view: "s-profile" },
  { label: "Paramètres", icon: Settings, view: "s-settings" },
];
const ADMIN_NAV: NavItem[] = [
  { label: "Tableau de bord", icon: LayoutDashboard, view: "a-dashboard" },
  { label: "Étudiants", icon: Users, view: "a-students" },
  { label: "Inscriptions", icon: ClipboardList, view: "a-registrations" },
  { label: "Cours", icon: BookOpen, view: "a-courses" },
  { label: "Notes", icon: Award, view: "a-grades" },
  { label: "Annonces", icon: Bell, view: "a-announcements" },
  { label: "Utilisateurs", icon: UserCog, view: "a-users" },
  { label: "Statistiques", icon: BarChart3, view: "a-statistics" },
  { label: "Journal d'activité", icon: Activity, view: "a-activity" },
  { label: "Paramètres", icon: Settings, view: "a-settings" },
];

function Sidebar({ role, view, setView, collapsed, setCollapsed, mobileOpen, setMobileOpen, onLogout }: {
  role: Role; view: View; setView: (v: View) => void;
  collapsed: boolean; setCollapsed: (c: boolean) => void;
  mobileOpen: boolean; setMobileOpen: (o: boolean) => void;
  onLogout: () => void;
}) {
  const nav = role === "student" ? STUDENT_NAV : ADMIN_NAV;
  const content = (
    <div className="flex flex-col h-full overflow-hidden">
      <div className={`flex items-center gap-2.5 p-4 border-b border-border flex-shrink-0 ${collapsed ? "justify-center" : ""}`}>
        <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center flex-shrink-0 shadow-sm"><GraduationCap className="w-4 h-4 text-white" /></div>
        {!collapsed && <div><div className="text-sm font-bold text-foreground leading-tight">AAI</div><div className="text-xs text-muted-foreground">Assistant Académique</div></div>}
      </div>
      {!collapsed && (
        <div className="px-3 py-2 flex-shrink-0">
          <div className={`text-xs font-semibold px-2 py-1.5 rounded-lg text-center ${role === "student" ? "bg-blue-50 text-blue-700" : "bg-emerald-50 text-emerald-700"}`}>
            {role === "student" ? "Espace Étudiant" : "Espace Administrateur"}
          </div>
        </div>
      )}
      <nav className="flex-1 px-2 py-2 space-y-0.5 overflow-y-auto" style={{ scrollbarWidth: "none" }}>
        {nav.map(({ label, icon: Icon, view: v }) => {
          const active = view === v;
          return (
            <button key={v} onClick={() => { setView(v); setMobileOpen(false); }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 ${active ? "bg-primary text-white shadow-sm" : "text-muted-foreground hover:bg-muted hover:text-foreground"} ${collapsed ? "justify-center" : ""}`}
              title={collapsed ? label : undefined}>
              <Icon className="w-4 h-4 flex-shrink-0" />
              {!collapsed && <span className="truncate">{label}</span>}
            </button>
          );
        })}
      </nav>
      <div className="p-2 border-t border-border flex-shrink-0 space-y-0.5">
        <button onClick={onLogout}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-red-500 hover:bg-red-50 transition-all duration-150 font-medium ${collapsed ? "justify-center" : ""}`}
          title={collapsed ? "Déconnexion" : undefined}>
          <LogOut className="w-4 h-4 flex-shrink-0" />
          {!collapsed && <span>Déconnexion</span>}
        </button>
      </div>
    </div>
  );
  return (
    <>
      <aside className={`hidden lg:flex flex-col bg-card border-r border-border transition-all duration-200 flex-shrink-0 relative ${collapsed ? "w-16" : "w-60"}`}>
        {content}
        <button onClick={() => setCollapsed(!collapsed)}
          className="absolute -right-3 top-20 w-6 h-6 bg-card border border-border rounded-full flex items-center justify-center hover:bg-muted transition-colors duration-150 z-10 shadow-sm">
          {collapsed ? <ChevronRight className="w-3 h-3 text-muted-foreground" /> : <ChevronLeft className="w-3 h-3 text-muted-foreground" />}
        </button>
      </aside>
      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div className="absolute inset-0 bg-black/40" onClick={() => setMobileOpen(false)} />
          <aside className="relative w-60 bg-card border-r border-border flex flex-col">{content}</aside>
        </div>
      )}
    </>
  );
}

// ── TOPBAR ─────────────────────────────────────────────────────────────────
function TopBar({ role, view, setView, setMobileOpen, notifs, setNotifs, onLogout }: {
  role: Role; view: View; setView: (v: View) => void; setMobileOpen: (o: boolean) => void;
  notifs: Notif[]; setNotifs: (n: Notif[]) => void; onLogout: () => void;
}) {
  const nav = role === "student" ? STUDENT_NAV : ADMIN_NAV;
  const current = nav.find((n) => n.view === view);
  const [drop, setDrop] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQ, setSearchQ] = useState("");
  const unread = notifs.filter((n) => !n.read).length;
  const searchResults = searchQ.length > 1 ? SEARCH_INDEX.filter((s) => s.label.toLowerCase().includes(searchQ.toLowerCase())).slice(0, 6) : [];

  const markAllRead = () => setNotifs(notifs.map((n) => ({ ...n, read: true })));

  return (
    <header className="h-14 bg-card border-b border-border flex items-center justify-between px-4 flex-shrink-0 z-40">
      <div className="flex items-center gap-3">
        <button className="lg:hidden p-2 rounded-lg hover:bg-muted transition-colors duration-150" onClick={() => setMobileOpen(true)}><Menu className="w-5 h-5 text-muted-foreground" /></button>
        <span className="text-sm font-semibold text-foreground hidden sm:block">{current?.label ?? ""}</span>
      </div>
      <div className="flex items-center gap-2">
        {/* Global search */}
        <div className="relative hidden sm:block">
          <div className={`flex items-center gap-2 bg-muted/50 border rounded-xl px-3 py-1.5 transition-all duration-150 ${searchOpen ? "border-primary ring-2 ring-primary/10 bg-card w-64" : "border-border w-40 hover:border-primary/30"}`}>
            <Search className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
            <input value={searchQ} onChange={(e) => setSearchQ(e.target.value)} onFocus={() => setSearchOpen(true)} onBlur={() => setTimeout(() => { setSearchOpen(false); setSearchQ(""); }, 200)}
              placeholder="Recherche globale..." className="text-xs bg-transparent focus:outline-none text-foreground placeholder:text-muted-foreground/60 w-full" />
          </div>
          {searchOpen && searchResults.length > 0 && (
            <div className="absolute top-full left-0 mt-1 w-72 bg-card rounded-xl border border-border shadow-lg py-1 z-50">
              {searchResults.map((r, i) => (
                <button key={i} onMouseDown={() => { setView(r.view); setSearchQ(""); }}
                  className="w-full flex items-center gap-3 px-3 py-2 hover:bg-muted transition-colors duration-100 text-left">
                  <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0"><r.icon className="w-3.5 h-3.5 text-primary" /></div>
                  <div><div className="text-xs font-semibold text-foreground">{r.label}</div><div className="text-xs text-muted-foreground">{r.type}</div></div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Notifications */}
        <div className="relative">
          <button onClick={() => { setNotifOpen(!notifOpen); setDrop(false); }} className="p-2 rounded-lg hover:bg-muted transition-colors duration-150 relative">
            <Bell className="w-4 h-4 text-muted-foreground" />
            {unread > 0 && <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-red-500 text-white text-[9px] font-bold flex items-center justify-center">{unread}</span>}
          </button>
          {notifOpen && (
            <div className="absolute right-0 top-full mt-1 w-80 bg-card rounded-xl border border-border shadow-xl z-50">
              <div className="flex items-center justify-between px-4 py-3 border-b border-border">
                <h3 className="text-sm font-bold text-foreground">Notifications</h3>
                <button onClick={markAllRead} className="text-xs text-primary font-medium hover:underline">Tout marquer lu</button>
              </div>
              <div className="max-h-80 overflow-y-auto" style={{ scrollbarWidth: "thin" }}>
                {notifs.map((n) => (
                  <div key={n.id} className={`flex gap-3 px-4 py-3 border-b border-border last:border-b-0 hover:bg-muted/40 transition-colors cursor-pointer ${!n.read ? "bg-blue-50/50" : ""}`}
                    onClick={() => setNotifs(notifs.map((x) => x.id === n.id ? { ...x, read: true } : x))}>
                    <div className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${n.type === "success" ? "bg-emerald-500" : n.type === "warning" ? "bg-amber-500" : n.type === "error" ? "bg-red-500" : "bg-blue-500"}`} />
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-semibold text-foreground">{n.title}</div>
                      <div className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{n.body}</div>
                      <div className="text-xs text-muted-foreground/60 mt-1">{n.time}</div>
                    </div>
                    {!n.read && <div className="w-2 h-2 rounded-full bg-primary mt-1 flex-shrink-0" />}
                  </div>
                ))}
              </div>
              <div className="px-4 py-2.5 border-t border-border"><button className="text-xs text-primary font-medium hover:underline w-full text-center">Voir toutes les notifications</button></div>
            </div>
          )}
        </div>

        {/* User dropdown */}
        <div className="relative">
          <button className="flex items-center gap-2 pl-2 pr-3 py-1.5 rounded-xl hover:bg-muted transition-colors duration-150" onClick={() => { setDrop(!drop); setNotifOpen(false); }}>
            <div className="w-7 h-7 rounded-full bg-primary flex items-center justify-center text-white text-xs font-bold">{role === "student" ? "AB" : "AD"}</div>
            <span className="text-sm font-medium text-foreground hidden sm:block">{role === "student" ? "Amina Benali" : "Administrateur"}</span>
            <ChevronDown className={`w-3.5 h-3.5 text-muted-foreground transition-transform duration-150 ${drop ? "rotate-180" : ""}`} />
          </button>
          {drop && (
            <div className="absolute right-0 top-full mt-1 w-48 bg-card rounded-xl border border-border shadow-lg py-1 z-50">
              <button className="w-full flex items-center gap-2 px-3 py-2 text-sm text-muted-foreground hover:bg-muted transition-colors duration-100" onClick={() => { setView(role === "student" ? "s-profile" : "a-settings"); setDrop(false); }}><User className="w-4 h-4" />Mon profil</button>
              <button className="w-full flex items-center gap-2 px-3 py-2 text-sm text-muted-foreground hover:bg-muted transition-colors duration-100" onClick={() => { setView(role === "student" ? "s-settings" : "a-settings"); setDrop(false); }}><Settings className="w-4 h-4" />Paramètres</button>
              <div className="border-t border-border my-1" />
              <button className="w-full flex items-center gap-2 px-3 py-2 text-sm text-red-500 hover:bg-red-50 transition-colors duration-100" onClick={() => { setDrop(false); onLogout(); }}><LogOut className="w-4 h-4" />Déconnexion</button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}

// ── STUDENT SCREENS ────────────────────────────────────────────────────────
function StudentDashboard({ setView }: { setView: (v: View) => void }) {
  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="mb-6 flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Bonjour, Amina 👋</h1>
          <p className="text-sm text-muted-foreground mt-1">Lundi 10 janvier 2024 · Semestre 2 — Licence 3 Informatique</p>
        </div>
        <div className="hidden sm:flex items-center gap-2 bg-emerald-50 border border-emerald-200 rounded-xl px-3 py-2">
          <CheckCircle className="w-4 h-4 text-emerald-600" />
          <span className="text-xs font-semibold text-emerald-700">Tous les modules validés</span>
        </div>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard icon={BookOpen} label="Cours inscrits" value="6" sub="+1 optionnel" color="blue" trend="up" />
        <StatCard icon={Award} label="Moyenne générale" value="14.2" sub="+0.3 vs S1" color="green" trend="up" />
        <StatCard icon={CheckCircle} label="Crédits validés" value="84" sub="sur 90 ce sem." color="amber" />
        <StatCard icon={AlertCircle} label="Cours à reprendre" value="0" sub="Félicitations !" color="purple" />
      </div>
      <div className="grid lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2 bg-card rounded-2xl border border-border p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base font-bold text-foreground">Mes Cours — Progression</h2>
            <button onClick={() => setView("s-courses")} className="text-xs text-primary font-semibold hover:underline flex items-center gap-1">Voir tout <ChevronRight className="w-3.5 h-3.5" /></button>
          </div>
          <div className="space-y-3">
            {COURSES_BASE.slice(0, 5).map((c, i) => (
              <div key={c.id} className="flex items-center gap-3 group">
                <div className="w-1.5 h-10 rounded-full flex-shrink-0" style={{ background: c.color }} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-semibold text-foreground truncate">{c.name}</span>
                    <span className="text-xs font-bold text-muted-foreground ml-2">{STUDENT_PROGRESS[i]}%</span>
                  </div>
                  <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-500" style={{ width: `${STUDENT_PROGRESS[i]}%`, background: c.color }} />
                  </div>
                </div>
                {STUDENT_GRADES_NUM[i] !== null && (
                  <span className={`text-xs font-bold flex-shrink-0 w-10 text-right ${(STUDENT_GRADES_NUM[i] ?? 0) >= 14 ? "text-emerald-600" : "text-foreground"}`}>{STUDENT_GRADES_NUM[i]}/20</span>
                )}
              </div>
            ))}
          </div>
        </div>
        <div className="bg-card rounded-2xl border border-border p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base font-bold text-foreground">Annonces</h2>
            <button onClick={() => setView("s-announcements")} className="text-xs text-primary font-semibold hover:underline">Voir tout</button>
          </div>
          <div className="space-y-3">
            {ANNOUNCEMENTS_DATA.slice(0, 4).map((a) => (
              <div key={a.id} className="flex gap-2.5 cursor-pointer hover:bg-muted/30 rounded-lg p-1.5 -mx-1.5 transition-colors duration-100">
                <div className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${a.urgent ? "bg-red-500" : "bg-muted-foreground/40"}`} />
                <div>
                  <p className="text-xs font-semibold text-foreground leading-tight">{a.title}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{a.date} · {a.author}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="bg-card rounded-2xl border border-border p-5">
          <h2 className="text-base font-bold text-foreground mb-4">Aujourd'hui — Lundi</h2>
          <div className="space-y-2">
            {(SCHEDULE_GRID["Lundi"] ?? []).map((slot, i) => (
              <div key={i} className={`flex gap-3 p-2.5 rounded-xl transition-colors duration-100 ${slot ? "bg-muted/40 hover:bg-muted/70" : ""}`}>
                <span className="text-xs text-muted-foreground font-mono w-16 flex-shrink-0 mt-0.5">{SCHEDULE_SLOTS[i]}</span>
                {slot ? <div><div className="text-xs font-semibold text-foreground">{slot.name}</div><div className="text-xs text-muted-foreground">{slot.type} · {slot.room}</div></div>
                  : <span className="text-xs text-muted-foreground/50 italic">Libre</span>}
              </div>
            ))}
          </div>
        </div>
        <div className="lg:col-span-2 bg-gradient-to-br from-primary/5 to-accent/5 rounded-2xl border border-primary/10 p-5">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center flex-shrink-0"><Brain className="w-5 h-5 text-white" /></div>
            <div><h2 className="text-base font-bold text-foreground">Assistant IA</h2><div className="flex items-center gap-1.5 mt-0.5"><div className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" /><p className="text-xs text-muted-foreground">En ligne · Prêt à vous aider</p></div></div>
          </div>
          <div className="grid grid-cols-2 gap-2 mb-3">
            {AI_SUGGESTIONS.map((s) => (
              <button key={s} onClick={() => setView("s-ai-chat")} className="text-left text-xs p-2.5 bg-white/80 rounded-xl border border-border hover:border-primary/30 hover:bg-white hover:shadow-sm transition-all duration-150 text-foreground font-medium">{s}</button>
            ))}
          </div>
          <Btn icon={MessageSquare} onClick={() => setView("s-ai-chat")} variant="primary">Ouvrir l'Assistant IA</Btn>
        </div>
      </div>
    </div>
  );
}

function StudentCourses({ setView, setSelectedCourse }: { setView: (v: View) => void; setSelectedCourse: (id: number) => void }) {
  const [search, setSearch] = useState("");
  const [filterDept, setFilterDept] = useState("Tous");
  const depts = ["Tous", ...Array.from(new Set(COURSES_BASE.map((c) => c.dept)))];
  const filtered = COURSES_BASE.filter((c) =>
    (c.name.toLowerCase().includes(search.toLowerCase()) || c.prof.toLowerCase().includes(search.toLowerCase())) &&
    (filterDept === "Tous" || c.dept === filterDept)
  );
  return (
    <div className="p-6 max-w-6xl mx-auto">
      <PageHeader title="Mes Cours" subtitle="Semestre 2 · Licence 3 Informatique" action={
        <div className="flex items-center gap-2 flex-wrap">
          <div className="relative"><Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" /><input type="text" placeholder="Rechercher un cours..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9 pr-4 py-2 text-sm bg-card border border-border rounded-xl focus:outline-none focus:border-primary w-48 transition-all duration-150" /></div>
          <select value={filterDept} onChange={(e) => setFilterDept(e.target.value)} className="px-3 py-2 text-sm bg-card border border-border rounded-xl focus:outline-none focus:border-primary transition-all duration-150 text-foreground">
            {depts.map((d) => <option key={d}>{d}</option>)}
          </select>
        </div>
      } />
      {filtered.length === 0 ? (
        <div className="bg-card rounded-2xl border border-border p-10 text-center"><Search className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" /><p className="text-sm font-medium text-muted-foreground">Aucun cours trouvé pour "{search}"</p></div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filtered.map((c, i) => {
            const grade = STUDENT_GRADES_NUM[i];
            return (
              <div key={c.id} className="bg-card rounded-2xl border border-border overflow-hidden hover:shadow-lg hover:-translate-y-1 transition-all duration-200 cursor-pointer group"
                onClick={() => { setSelectedCourse(c.id); setView("s-course-detail"); }}>
                <div className="h-1.5" style={{ background: c.color }} />
                <div className="p-5">
                  <div className="flex items-start justify-between mb-3">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center transition-transform duration-200 group-hover:scale-110" style={{ background: c.color + "20" }}>
                      <BookOpen className="w-5 h-5" style={{ color: c.color }} />
                    </div>
                    <Badge variant={grade !== null ? (grade >= 10 ? "success" : "danger") : "info"}>{grade !== null ? `${grade}/20` : "En cours"}</Badge>
                  </div>
                  <h3 className="text-sm font-bold text-foreground mb-1">{c.name}</h3>
                  <p className="text-xs text-muted-foreground mb-1">{c.prof}</p>
                  <p className="text-xs text-muted-foreground mb-4">{c.code} · {c.credits} crédits ECTS</p>
                  <div>
                    <div className="flex justify-between text-xs mb-1"><span className="text-muted-foreground">Progression</span><span className="font-semibold text-foreground">{STUDENT_PROGRESS[i]}%</span></div>
                    <div className="h-1.5 bg-muted rounded-full overflow-hidden"><div className="h-full rounded-full transition-all duration-500" style={{ width: `${STUDENT_PROGRESS[i]}%`, background: c.color }} /></div>
                  </div>
                  <div className="mt-4 flex items-center justify-between">
                    <div className="flex items-center gap-1 text-xs font-semibold text-primary opacity-0 group-hover:opacity-100 transition-opacity duration-150">Voir le cours <ChevronRight className="w-3.5 h-3.5" /></div>
                    <button className="w-7 h-7 rounded-lg bg-muted/50 flex items-center justify-center hover:bg-primary/10 transition-colors duration-150 opacity-0 group-hover:opacity-100" title="Télécharger le support PDF" onClick={(e) => { e.stopPropagation(); }}>
                      <Download className="w-3.5 h-3.5 text-primary" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function StudentCourseDetail({ courseId, setView }: { courseId: number; setView: (v: View) => void }) {
  const course = COURSES_BASE.find((c) => c.id === courseId) ?? COURSES_BASE[0];
  const idx = COURSES_BASE.indexOf(course);
  const modules = [
    { num: 1, title: "Introduction et concepts fondamentaux", status: "done", duration: "2h" },
    { num: 2, title: "Structures de données linéaires", status: "done", duration: "3h" },
    { num: 3, title: "Arbres binaires et AVL", status: "done", duration: "4h" },
    { num: 4, title: "Graphes et algorithmes de parcours", status: "active", duration: "3h" },
    { num: 5, title: "Algorithmes de tri avancés", status: "locked", duration: "3h" },
    { num: 6, title: "Programmation dynamique", status: "locked", duration: "4h" },
  ];
  return (
    <div className="p-6 max-w-4xl mx-auto">
      <button onClick={() => setView("s-courses")} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-5 transition-colors duration-150"><ChevronLeft className="w-4 h-4" />Retour aux cours</button>
      <div className="bg-card rounded-2xl border border-border p-6 mb-5">
        <div className="flex items-start gap-4 flex-wrap">
          <div className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0" style={{ background: course.color + "20" }}><BookOpen className="w-6 h-6" style={{ color: course.color }} /></div>
          <div className="flex-1"><div className="flex items-center gap-2 flex-wrap mb-1"><h1 className="text-xl font-bold text-foreground">{course.name}</h1><Badge variant="info">{course.code}</Badge></div><p className="text-sm text-muted-foreground">{course.prof} · {course.dept} · {course.credits} crédits ECTS</p></div>
          <div className="text-right"><div className="text-2xl font-bold" style={{ color: course.color }}>{STUDENT_GRADES_NUM[idx] ?? "—"}<span className="text-sm text-muted-foreground">/20</span></div><div className="text-xs text-muted-foreground">Note actuelle</div></div>
        </div>
        <div className="mt-4"><div className="flex justify-between text-xs mb-1.5"><span className="text-muted-foreground font-medium">Progression globale</span><span className="font-bold text-foreground">{STUDENT_PROGRESS[idx]}%</span></div><div className="h-2 bg-muted rounded-full overflow-hidden"><div className="h-full rounded-full transition-all duration-700" style={{ width: `${STUDENT_PROGRESS[idx]}%`, background: course.color }} /></div></div>
      </div>
      <div className="grid lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2 bg-card rounded-2xl border border-border p-5">
          <h2 className="text-base font-bold text-foreground mb-4">Chapitres du cours</h2>
          <div className="space-y-2.5">
            {modules.map((m) => (
              <div key={m.num} className={`flex items-center gap-3 p-3 rounded-xl border transition-all duration-150 cursor-pointer hover:shadow-sm ${m.status === "active" ? "border-primary/30 bg-primary/5" : m.status === "done" ? "border-emerald-200 bg-emerald-50/50 hover:bg-emerald-50" : "border-border bg-muted/30 opacity-60"}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${m.status === "done" ? "bg-emerald-100 text-emerald-700" : m.status === "active" ? "bg-primary text-white" : "bg-muted text-muted-foreground"}`}>{m.status === "done" ? <CheckCircle className="w-4 h-4" /> : m.num}</div>
                <div className="flex-1"><div className="text-xs font-semibold text-foreground">{m.title}</div><div className="text-xs text-muted-foreground">{m.duration}</div></div>
                {m.status === "active" && <Badge variant="info">En cours</Badge>}
                {m.status === "done" && <Download className="w-3.5 h-3.5 text-muted-foreground hover:text-primary transition-colors cursor-pointer" />}
              </div>
            ))}
          </div>
        </div>
        <div className="space-y-4">
          <div className="bg-card rounded-2xl border border-border p-4">
            <h3 className="text-sm font-bold text-foreground mb-3">Supports de cours</h3>
            <div className="space-y-2">
              {[{ name: "Cours Chap. 1–3 (PDF)", size: "2.4 MB" }, { name: "TD Corrections S1", size: "1.1 MB" }, { name: "TP Énoncés", size: "870 KB" }, { name: "Annales 2022–23", size: "3.2 MB" }].map((r) => (
                <div key={r.name} className="flex items-center gap-2 p-2 rounded-lg hover:bg-muted transition-colors duration-100 cursor-pointer group">
                  <FileText className="w-4 h-4 text-primary flex-shrink-0" />
                  <div className="flex-1 min-w-0"><div className="text-xs font-medium text-foreground truncate">{r.name}</div><div className="text-xs text-muted-foreground">{r.size}</div></div>
                  <Download className="w-3.5 h-3.5 text-muted-foreground group-hover:text-primary transition-colors duration-100" />
                </div>
              ))}
            </div>
          </div>
          <div className="bg-card rounded-2xl border border-border p-4">
            <h3 className="text-sm font-bold text-foreground mb-3">Prochaines séances</h3>
            <div className="space-y-2">
              {[{ day: "Lundi 13 Jan", time: "08h–10h", type: "CM" }, { day: "Mardi 14 Jan", time: "14h–16h", type: "TD" }, { day: "Mercredi 15 Jan", time: "16h–18h", type: "TP" }].map((s) => (
                <div key={s.day} className="flex items-center gap-2">
                  <div className={`text-xs font-semibold px-1.5 py-0.5 rounded ${s.type === "CM" ? "bg-blue-100 text-blue-700" : s.type === "TD" ? "bg-amber-100 text-amber-700" : "bg-emerald-100 text-emerald-700"}`}>{s.type}</div>
                  <div><div className="text-xs font-medium text-foreground">{s.day}</div><div className="text-xs text-muted-foreground">{s.time}</div></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function StudentGrades() {
  const valid = GRADES_TABLE.filter((g) => g.final !== null);
  const avg = valid.reduce((s, g) => s + (g.final ?? 0), 0) / valid.length;
  return (
    <div className="p-6 max-w-5xl mx-auto">
      <PageHeader title="Mes Notes" subtitle="Semestre 2 · Licence 3 Informatique" action={<Btn icon={Download} variant="outline" size="sm">Télécharger PDF</Btn>} />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard icon={Award} label="Moyenne générale" value={avg.toFixed(2)} sub="Sur 20" color="green" trend="up" />
        <StatCard icon={TrendingUp} label="Meilleure note" value="17.0" sub="Réseaux Info." color="blue" />
        <StatCard icon={CheckCircle} label="UEs validées" value="5/6" sub="1 en cours" color="amber" />
        <StatCard icon={BookOpen} label="Crédits ECTS" value="24/30" sub="Ce semestre" color="purple" />
      </div>
      <div className="grid lg:grid-cols-2 gap-5 mb-5">
        <div className="bg-card rounded-2xl border border-border p-5">
          <h2 className="text-base font-bold text-foreground mb-4">Progression sur les semestres</h2>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={GRADE_PROGRESSION}>
              <defs><linearGradient id="avgGrad" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#1d4ed8" stopOpacity={0.15} /><stop offset="95%" stopColor="#1d4ed8" stopOpacity={0} /></linearGradient></defs>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="sem" tick={{ fontSize: 10 }} />
              <YAxis domain={[10, 18]} tick={{ fontSize: 11 }} />
              <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid var(--border)", fontSize: 12 }} formatter={(v) => [`${v}/20`, "Moyenne"]} />
              <Area type="monotone" dataKey="avg" stroke="#1d4ed8" fill="url(#avgGrad)" strokeWidth={2.5} dot={{ fill: "#1d4ed8", r: 4 }} name="Moyenne" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-card rounded-2xl border border-border p-5">
          <h2 className="text-base font-bold text-foreground mb-4">Notes par matière</h2>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={GRADES_TABLE.filter((g) => g.final !== null).map((g) => ({ name: g.code, note: g.final, coeff: g.coeff }))} barSize={30}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="name" tick={{ fontSize: 11 }} />
              <YAxis domain={[0, 20]} tick={{ fontSize: 11 }} />
              <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid var(--border)", fontSize: 12 }} formatter={(v) => [`${v}/20`, "Note finale"]} />
              <Bar dataKey="note" radius={[6, 6, 0, 0]}>
                {GRADES_TABLE.filter((g) => g.final !== null).map((g, i) => <Cell key={i} fill={(g.final ?? 0) >= 14 ? "#10b981" : (g.final ?? 0) >= 10 ? "#1d4ed8" : "#ef4444"} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
      <div className="bg-card rounded-2xl border border-border overflow-hidden">
        <div className="p-4 border-b border-border"><h2 className="text-base font-bold text-foreground">Relevé de notes détaillé</h2></div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="bg-muted/50">{["Module", "Code", "CC", "TD", "TP", "Examen", "Note /20", "Coeff", "Crédits", "Statut"].map((h) => <th key={h} className="text-left text-xs font-semibold text-muted-foreground px-4 py-3 whitespace-nowrap">{h}</th>)}</tr></thead>
            <tbody className="divide-y divide-border">
              {GRADES_TABLE.map((g) => (
                <tr key={g.course} className="hover:bg-muted/30 transition-colors duration-100">
                  <td className="px-4 py-3 font-medium text-foreground text-xs whitespace-nowrap">{g.course}</td>
                  <td className="px-4 py-3 text-muted-foreground text-xs font-mono">{g.code}</td>
                  <td className="px-4 py-3 text-center text-xs">{g.cc ?? "—"}</td>
                  <td className="px-4 py-3 text-center text-xs">{g.td ?? "—"}</td>
                  <td className="px-4 py-3 text-center text-xs">{g.tp ?? "—"}</td>
                  <td className="px-4 py-3 text-center text-xs">{g.exam ?? "—"}</td>
                  <td className="px-4 py-3 text-center">{g.final !== null ? <span className={`text-sm font-bold ${g.final >= 14 ? "text-emerald-600" : g.final >= 10 ? "text-foreground" : "text-red-600"}`}>{g.final}</span> : <span className="text-muted-foreground text-xs">—</span>}</td>
                  <td className="px-4 py-3 text-center text-xs text-muted-foreground">{g.coeff}</td>
                  <td className="px-4 py-3 text-center text-xs text-muted-foreground">{g.credits}</td>
                  <td className="px-4 py-3"><Badge variant={g.status === "Admis" ? "success" : g.status === "En cours" ? "info" : "danger"}>{g.status}</Badge></td>
                </tr>
              ))}
            </tbody>
            <tfoot><tr className="bg-primary/5 border-t-2 border-primary/20"><td colSpan={6} className="px-4 py-3 text-sm font-bold text-foreground">Moyenne Générale</td><td className="px-4 py-3 text-center text-base font-bold text-primary">{avg.toFixed(2)}</td><td colSpan={3} /></tr></tfoot>
          </table>
        </div>
      </div>
    </div>
  );
}

function StudentRetake({ setView }: { setView: (v: View) => void }) {
  return (
    <div className="p-6 max-w-3xl mx-auto">
      <PageHeader title="Cours à reprendre" subtitle="Modules nécessitant révision ou rattrapage" />
      <div className="bg-card rounded-2xl border border-border p-10 text-center mb-5">
        <div className="w-16 h-16 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-4"><CheckCircle className="w-8 h-8 text-emerald-600" /></div>
        <h2 className="text-lg font-bold text-foreground mb-2">Félicitations !</h2>
        <p className="text-sm text-muted-foreground mb-6 max-w-sm mx-auto">Vous n'avez aucun cours en dessous de la moyenne. Tous vos modules sont validés pour ce semestre.</p>
        <div className="grid grid-cols-2 gap-3 max-w-xs mx-auto">
          <div className="bg-emerald-50 rounded-xl p-3"><div className="text-2xl font-bold text-emerald-600">5/5</div><div className="text-xs text-muted-foreground">Modules validés</div></div>
          <div className="bg-blue-50 rounded-xl p-3"><div className="text-2xl font-bold text-primary">14.2</div><div className="text-xs text-muted-foreground">Moyenne générale</div></div>
        </div>
      </div>
      <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5 mb-5 flex gap-3">
        <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
        <div><h3 className="text-sm font-bold text-amber-800 mb-1">Recommandation — Analyse Numérique (11.5/20)</h3><p className="text-xs text-amber-700">Ce module sera prérequis en M1. Bien que validé, nous vous recommandons de le consolider avant la rentrée.</p></div>
      </div>
      <div className="bg-gradient-to-r from-primary/5 to-accent/5 rounded-2xl border border-primary/10 p-5">
        <div className="flex items-start gap-3 mb-4">
          <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center flex-shrink-0"><Brain className="w-4 h-4 text-white" /></div>
          <div><h3 className="text-sm font-bold text-foreground">Recommandations de l'Assistant IA</h3><p className="text-xs text-muted-foreground">Plan de révision personnalisé pour Analyse Numérique</p></div>
        </div>
        <div className="space-y-3">
          {[
            { icon: BookMarked, title: "Réviser les méthodes d'interpolation", desc: "Polynôme de Lagrange, méthode des différences finies — 2h recommandées", badge: "Priorité haute" },
            { icon: CheckSquare, title: "Refaire les TDs 4, 5 et 6", desc: "Ces TDs couvrent 70% des questions d'examen types en Analyse Numérique.", badge: "Exercices" },
            { icon: Target, title: "Quiz de révision", desc: "Testez vos connaissances avec un quiz de 20 questions sur les méthodes numériques.", badge: "Quiz IA" },
          ].map(({ icon: Icon, title, desc, badge }) => (
            <div key={title} className="flex gap-3 bg-white/80 rounded-xl p-3 border border-border hover:shadow-sm transition-all duration-150 cursor-pointer">
              <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0"><Icon className="w-4 h-4 text-primary" /></div>
              <div className="flex-1"><div className="flex items-center gap-2 flex-wrap"><span className="text-xs font-bold text-foreground">{title}</span><Badge variant="info">{badge}</Badge></div><p className="text-xs text-muted-foreground mt-0.5">{desc}</p></div>
            </div>
          ))}
        </div>
        <div className="mt-4"><Btn icon={MessageSquare} onClick={() => setView("s-ai-chat")} variant="primary">Générer un plan de révision complet</Btn></div>
      </div>
    </div>
  );
}

function StudentSchedule() {
  const [activeDay, setActiveDay] = useState("Lundi");
  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div><h1 className="text-2xl font-bold text-foreground">Emploi du Temps</h1><p className="text-sm text-muted-foreground">Semaine du 10 – 15 Jan 2024</p></div>
        <div className="flex items-center gap-3 flex-wrap">
          {[{ label: "CM", color: "bg-primary" }, { label: "TD", color: "bg-amber-500" }, { label: "TP", color: "bg-emerald-500" }].map(({ label, color }) => (
            <div key={label} className="flex items-center gap-1.5"><div className={`w-3 h-3 rounded-sm ${color}`} /><span className="text-xs font-medium text-muted-foreground">{label}</span></div>
          ))}
          <Btn icon={Download} variant="outline" size="sm">Exporter</Btn>
        </div>
      </div>
      {/* Mobile: day selector */}
      <div className="flex gap-2 mb-4 overflow-x-auto lg:hidden pb-1" style={{ scrollbarWidth: "none" }}>
        {SCHEDULE_DAYS.map((d) => (
          <button key={d} onClick={() => setActiveDay(d)} className={`flex-shrink-0 px-3 py-1.5 text-xs font-semibold rounded-full transition-all duration-150 ${activeDay === d ? "bg-primary text-white" : "bg-card border border-border text-muted-foreground hover:border-primary/30"}`}>{d}</button>
        ))}
      </div>
      <div className="bg-card rounded-2xl border border-border overflow-hidden overflow-x-auto">
        <div className="min-w-[700px]">
          <div className="grid grid-cols-7 bg-muted/50 border-b border-border">
            <div className="p-3 border-r border-border" />
            {SCHEDULE_DAYS.map((d) => <div key={d} className={`p-3 text-center border-r border-border last:border-r-0 transition-colors duration-150 ${activeDay === d ? "bg-primary/5" : ""}`}><div className={`text-xs font-bold ${activeDay === d ? "text-primary" : "text-foreground"}`}>{d}</div></div>)}
          </div>
          {SCHEDULE_SLOTS.map((slot, si) => (
            <div key={slot} className="grid grid-cols-7 border-b border-border last:border-b-0">
              <div className="p-3 border-r border-border flex items-center justify-center bg-muted/20"><span className="text-xs font-mono text-muted-foreground text-center leading-tight">{slot}</span></div>
              {SCHEDULE_DAYS.map((day) => {
                const cell = SCHEDULE_GRID[day]?.[si];
                return (
                  <div key={day} className={`p-1.5 border-r border-border last:border-r-0 min-h-[72px] transition-colors duration-100 ${activeDay === day ? "bg-primary/3" : ""}`}>
                    {cell ? (
                      <div className="h-full rounded-lg p-2 flex flex-col justify-between text-white text-xs cursor-pointer hover:brightness-110 transition-all duration-150" style={{ background: cell.color }}>
                        <div className="font-semibold leading-tight text-[11px]">{cell.name}</div>
                        <div className="flex items-center justify-between mt-1">
                          <span className="opacity-80 text-[10px]">{cell.room}</span>
                          <span className="bg-white/20 px-1 rounded text-[10px] font-bold">{cell.type}</span>
                        </div>
                      </div>
                    ) : null}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function StudentAnnouncements() {
  const [filter, setFilter] = useState("Tous");
  const [search, setSearch] = useState("");
  const types = ["Tous", "Examen", "Devoir", "Événement", "Inscription", "Info"];
  const filtered = ANNOUNCEMENTS_DATA.filter((a) =>
    (filter === "Tous" || a.type === filter) &&
    (a.title.toLowerCase().includes(search.toLowerCase()) || a.content.toLowerCase().includes(search.toLowerCase()))
  );
  return (
    <div className="p-6 max-w-3xl mx-auto">
      <PageHeader title="Centre d'Annonces" subtitle={`${ANNOUNCEMENTS_DATA.length} annonces ce semestre`} action={
        <div className="relative"><Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" /><input type="text" placeholder="Rechercher..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9 pr-4 py-2 text-sm bg-card border border-border rounded-xl focus:outline-none focus:border-primary w-44 transition-all duration-150" /></div>
      } />
      <div className="flex gap-2 flex-wrap mb-5">
        {types.map((t) => <button key={t} onClick={() => setFilter(t)} className={`px-3 py-1.5 text-xs font-semibold rounded-full border transition-all duration-150 ${filter === t ? "bg-primary text-white border-primary shadow-sm" : "bg-card text-muted-foreground border-border hover:border-primary/30 hover:text-primary"}`}>{t}</button>)}
      </div>
      {filtered.length === 0 ? <div className="bg-card rounded-2xl border border-border p-8 text-center"><p className="text-sm text-muted-foreground">Aucune annonce trouvée.</p></div> : (
        <div className="space-y-3">
          {filtered.map((a) => (
            <div key={a.id} className={`bg-card rounded-2xl border p-5 hover:shadow-sm transition-all duration-150 ${a.urgent ? "border-red-200" : "border-border"}`}>
              <div className="flex items-start justify-between gap-3 mb-2">
                <div className="flex items-center gap-2 flex-wrap"><h3 className="text-sm font-bold text-foreground">{a.title}</h3>{a.urgent && <Badge variant="danger">Urgent</Badge>}</div>
                <Badge variant={a.type === "Examen" ? "danger" : a.type === "Devoir" ? "warning" : a.type === "Événement" ? "success" : "info"}>{a.type}</Badge>
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed mb-3">{a.content}</p>
              <div className="flex items-center gap-3 text-xs text-muted-foreground"><span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" />{a.date}</span><span>·</span><span className="flex items-center gap-1"><User className="w-3.5 h-3.5" />{a.author}</span></div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function StudentProfile() {
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ name: "Amina Benali", email: "a.benali@univ.dz", phone: "+213 555 12 34 56", address: "12 Rue des Oliviers, Alger", bio: "Étudiante passionnée par l'informatique et l'IA." });
  const [saved, setSaved] = useState(false);
  const save = () => { setEditing(false); setSaved(true); setTimeout(() => setSaved(false), 2500); };
  return (
    <div className="p-6 max-w-3xl mx-auto">
      <PageHeader title="Mon Profil" />
      {saved && <div className="mb-4 flex items-center gap-2 bg-emerald-50 border border-emerald-200 rounded-xl px-4 py-3"><CheckCircle className="w-4 h-4 text-emerald-600" /><p className="text-sm font-medium text-emerald-700">Profil mis à jour avec succès !</p></div>}
      <div className="bg-card rounded-2xl border border-border p-6 mb-5">
        <div className="flex items-start gap-4 flex-wrap">
          <div className="relative group cursor-pointer">
            <div className="w-20 h-20 rounded-2xl bg-primary flex items-center justify-center text-white text-2xl font-bold">AB</div>
            <div className="absolute inset-0 rounded-2xl bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-150">
              <Upload className="w-5 h-5 text-white" />
            </div>
            <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-accent flex items-center justify-center shadow"><Edit2 className="w-3 h-3 text-white" /></div>
          </div>
          <div className="flex-1">
            <h2 className="text-xl font-bold text-foreground">Amina Benali</h2>
            <p className="text-sm text-muted-foreground">Matricule : 20210001</p>
            <p className="text-sm text-muted-foreground">Informatique · Licence 3 · Promo 2024</p>
            <div className="flex gap-2 mt-2"><Badge variant="success">Actif</Badge><Badge variant="info">Semestre 2</Badge></div>
          </div>
          <div className="grid grid-cols-3 gap-3 text-center">
            {[{ val: "14.2", label: "Moyenne" }, { val: "84", label: "Crédits" }, { val: "2024", label: "Promo" }].map(({ val, label }) => (
              <div key={label} className="bg-muted/50 rounded-xl px-3 py-2"><div className="text-base font-bold text-foreground">{val}</div><div className="text-xs text-muted-foreground">{label}</div></div>
            ))}
          </div>
        </div>
      </div>
      <div className="bg-card rounded-2xl border border-border p-5 mb-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-bold text-foreground">Informations personnelles</h3>
          <Btn icon={Edit2} variant="ghost" size="sm" onClick={() => editing ? save() : setEditing(true)}>{editing ? "Enregistrer" : "Modifier"}</Btn>
        </div>
        <div className="grid sm:grid-cols-2 gap-4">
          {([["name", "Nom complet"], ["email", "Email universitaire"], ["phone", "Téléphone"], ["address", "Adresse"], ["bio", "Biographie"]] as const).map(([field, label]) => (
            <div key={field} className={field === "bio" ? "sm:col-span-2" : ""}>
              <label className="text-xs font-semibold text-muted-foreground mb-1 block">{label}</label>
              {editing ? (field === "bio" ?
                <textarea value={form[field]} onChange={(e) => setForm({ ...form, [field]: e.target.value })} rows={2} className="w-full px-3 py-2 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:border-primary transition-all duration-150 resize-none" />
                : <input value={form[field]} onChange={(e) => setForm({ ...form, [field]: e.target.value })} className="w-full px-3 py-2 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:border-primary transition-all duration-150" />)
                : <div className="text-sm text-foreground font-medium">{form[field]}</div>}
            </div>
          ))}
        </div>
      </div>
      <div className="bg-card rounded-2xl border border-border p-5">
        <h3 className="text-sm font-bold text-foreground mb-4">Sécurité — Changer le mot de passe</h3>
        <div className="space-y-3">
          {["Mot de passe actuel", "Nouveau mot de passe", "Confirmer le mot de passe"].map((label) => (
            <div key={label}><label className="text-xs font-semibold text-muted-foreground mb-1 block">{label}</label><input type="password" placeholder="••••••••" className="w-full px-3 py-2 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:border-primary transition-all duration-150" /></div>
          ))}
          <Btn variant="primary">Changer le mot de passe</Btn>
        </div>
      </div>
    </div>
  );
}

function StudentAIChat() {
  const [messages, setMessages] = useState<AiMsg[]>([
    { id: 1, role: "ai", content: "Bonjour ! Je suis votre Assistant Académique Intelligent 🎓\n\nJe suis là pour vous aider avec vos cours, vos questions pédagogiques, les règlements universitaires et votre organisation. Comment puis-je vous aider aujourd'hui ?", time: "09:00" },
    { id: 2, role: "user", content: "Peux-tu m'expliquer la différence entre un arbre AVL et un arbre rouge-noir ?", time: "09:02" },
    { id: 3, role: "ai", content: "**Arbres AVL vs Arbres Rouge-Noir :**\n\n**Arbre AVL :**\n• Équilibrage strict (différence de hauteur max = 1)\n• Recherche très rapide\n• Insertions/suppressions coûteuses\n\n**Arbre Rouge-Noir :**\n• Équilibrage souple, insertions rapides\n• Utilisé dans Java TreeMap et C++ std::map\n\n**Résumé :** AVL = recherche intensive · Rouge-Noir = modifications fréquentes", time: "09:02" },
  ]);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, typing]);
  const send = useCallback(() => {
    if (!input.trim() || typing) return;
    const now = new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
    const userInput = input;
    setMessages((p) => [...p, { id: Date.now(), role: "user", content: userInput, time: now }]);
    setInput(""); if (textareaRef.current) { textareaRef.current.style.height = "auto"; }
    setTyping(true);
    setTimeout(() => { setMessages((p) => [...p, { id: Date.now() + 1, role: "ai", content: getAiResponse(userInput), time: now }]); setTyping(false); }, 1400);
  }, [input, typing]);
  const renderContent = (content: string) =>
    content.split("\n").map((line, i) => {
      if (line.startsWith("**") && line.endsWith("**")) return <p key={i} className="font-bold mt-2 first:mt-0">{line.slice(2, -2)}</p>;
      if (line.startsWith("• ")) return <p key={i} className="flex gap-2"><span className="text-accent flex-shrink-0">•</span><span>{line.slice(2)}</span></p>;
      if (line.trim() === "") return <div key={i} className="h-1" />;
      return <p key={i}>{line}</p>;
    });
  return (
    <div className="flex flex-col h-full">
      <div className="px-5 py-3 border-b border-border bg-card flex items-center justify-between flex-shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center"><Brain className="w-5 h-5 text-white" /></div>
          <div><div className="text-sm font-bold text-foreground">Assistant Académique IA</div><div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-accent animate-pulse" /><span className="text-xs text-muted-foreground">En ligne</span></div></div>
        </div>
        <Btn icon={RefreshCw} variant="ghost" size="sm" onClick={() => setMessages([])}>Nouvelle conversation</Btn>
      </div>
      <div className="flex-1 overflow-y-auto px-4 py-5 space-y-4" style={{ scrollbarWidth: "thin" }}>
        {messages.map((m) => (
          <div key={m.id} className={`flex gap-3 ${m.role === "user" ? "flex-row-reverse" : ""}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${m.role === "ai" ? "bg-primary text-white" : "bg-muted text-muted-foreground"}`}>{m.role === "ai" ? <Brain className="w-4 h-4" /> : <span className="text-xs font-bold">A</span>}</div>
            <div className={`max-w-[78%] flex flex-col gap-1 ${m.role === "user" ? "items-end" : "items-start"}`}>
              <div className={`rounded-2xl px-4 py-3 text-sm leading-relaxed space-y-0.5 ${m.role === "ai" ? "bg-card border border-border text-foreground rounded-tl-sm" : "bg-primary text-white rounded-tr-sm"}`}>{renderContent(m.content)}</div>
              <span className="text-xs text-muted-foreground px-1">{m.time}</span>
            </div>
          </div>
        ))}
        {typing && (
          <div className="flex gap-3">
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center flex-shrink-0"><Brain className="w-4 h-4 text-white" /></div>
            <div className="bg-card border border-border rounded-2xl rounded-tl-sm px-4 py-3 flex items-center gap-1">{[0, 1, 2].map((i) => <div key={i} className="w-2 h-2 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />)}</div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>
      {messages.length <= 3 && (
        <div className="px-4 pb-2 flex gap-2 flex-wrap">
          {AI_SUGGESTIONS.map((s) => <button key={s} onClick={() => setInput(s)} className="text-xs px-3 py-1.5 bg-card border border-border rounded-full text-muted-foreground hover:border-primary/30 hover:text-primary transition-all duration-150">{s}</button>)}
        </div>
      )}
      <div className="px-4 pb-4 flex-shrink-0">
        <div className="flex items-end gap-2 bg-card border border-border rounded-2xl p-3 focus-within:border-primary focus-within:ring-2 focus-within:ring-primary/10 transition-all duration-150">
          <textarea ref={textareaRef} rows={1} value={input}
            onChange={(e) => { setInput(e.target.value); e.target.style.height = "auto"; e.target.style.height = Math.min(e.target.scrollHeight, 120) + "px"; }}
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
            placeholder="Posez votre question... (Entrée pour envoyer, Maj+Entrée pour un retour à la ligne)"
            className="flex-1 text-sm bg-transparent resize-none focus:outline-none text-foreground placeholder:text-muted-foreground/60 max-h-[120px]" />
          <button onClick={send} disabled={!input.trim() || typing} className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center text-white hover:bg-blue-700 transition-all duration-150 disabled:opacity-40 disabled:cursor-not-allowed active:scale-95 flex-shrink-0"><Send className="w-4 h-4" /></button>
        </div>
        <p className="text-xs text-muted-foreground text-center mt-2">L'IA peut faire des erreurs. Vérifiez les informations importantes auprès de votre établissement.</p>
      </div>
    </div>
  );
}

function StudentAIHistory() {
  const history = [
    { id: 1, question: "Différence entre AVL et Arbre Rouge-Noir", date: "Aujourd'hui, 09:00", topic: "Algorithmes", messages: 4 },
    { id: 2, question: "Comment préparer l'examen de BDD ?", date: "Hier, 21:30", topic: "Base de Données", messages: 6 },
    { id: 3, question: "Complexité algorithmique O(n log n)", date: "8 Jan 2024", topic: "Algorithmes", messages: 3 },
    { id: 4, question: "Protocoles TCP et UDP expliqués", date: "5 Jan 2024", topic: "Réseaux", messages: 5 },
    { id: 5, question: "Formes normales en BDD (1NF, 2NF, 3NF)", date: "2 Jan 2024", topic: "Base de Données", messages: 8 },
    { id: 6, question: "Procédure d'inscription au rattrapage", date: "30 Déc 2023", topic: "Règlements", messages: 3 },
  ];
  return (
    <div className="p-6 max-w-3xl mx-auto">
      <PageHeader title="Historique des Conversations IA" subtitle={`${history.length} conversations`} />
      <div className="space-y-3">
        {history.map((h) => (
          <div key={h.id} className="bg-card rounded-2xl border border-border p-4 hover:shadow-sm hover:border-primary/20 transition-all duration-150 cursor-pointer group">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0 group-hover:bg-primary/20 transition-colors duration-150"><MessageSquare className="w-4 h-4 text-primary" /></div>
                <div><h3 className="text-sm font-semibold text-foreground">{h.question}</h3><div className="flex items-center gap-2 mt-1"><Badge variant="info">{h.topic}</Badge><span className="text-xs text-muted-foreground">{h.messages} messages</span></div></div>
              </div>
              <span className="text-xs text-muted-foreground whitespace-nowrap">{h.date}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function StudentSettings() {
  const [notifications, setNotifications] = useState({ email: true, push: true, examens: true, notes: true, annonces: false });
  const [theme, setTheme] = useState("system");
  const [lang, setLang] = useState("Français");
  return (
    <div className="p-6 max-w-2xl mx-auto">
      <PageHeader title="Paramètres du compte" subtitle="Gérez vos préférences et notifications" />
      <div className="space-y-5">
        <div className="bg-card rounded-2xl border border-border p-5">
          <div className="flex items-center gap-3 mb-4"><BellRing className="w-5 h-5 text-primary" /><h3 className="text-sm font-bold text-foreground">Notifications</h3></div>
          <div className="space-y-3">
            {([["email", "Notifications par email"], ["push", "Notifications push"], ["examens", "Rappels d'examens"], ["notes", "Publication des notes"], ["annonces", "Nouvelles annonces"]] as const).map(([key, label]) => (
              <div key={key} className="flex items-center justify-between py-2 border-b border-border last:border-b-0">
                <span className="text-sm text-foreground">{label}</span>
                <button onClick={() => setNotifications((p) => ({ ...p, [key]: !p[key] }))}
                  className={`w-11 h-6 rounded-full transition-all duration-200 relative ${notifications[key] ? "bg-primary" : "bg-muted"}`}>
                  <div className={`w-4 h-4 rounded-full bg-white shadow absolute top-1 transition-all duration-200 ${notifications[key] ? "right-1" : "left-1"}`} />
                </button>
              </div>
            ))}
          </div>
        </div>
        <div className="bg-card rounded-2xl border border-border p-5">
          <div className="flex items-center gap-3 mb-4"><Palette className="w-5 h-5 text-primary" /><h3 className="text-sm font-bold text-foreground">Apparence</h3></div>
          <div className="grid grid-cols-3 gap-3">
            {["light", "dark", "system"].map((t) => (
              <button key={t} onClick={() => setTheme(t)} className={`p-3 rounded-xl border text-xs font-medium transition-all duration-150 capitalize ${theme === t ? "border-primary bg-primary/5 text-primary" : "border-border text-muted-foreground hover:border-primary/30"}`}>{{ light: "Clair", dark: "Sombre", system: "Système" }[t]}</button>
            ))}
          </div>
        </div>
        <div className="bg-card rounded-2xl border border-border p-5">
          <div className="flex items-center gap-3 mb-4"><Globe className="w-5 h-5 text-primary" /><h3 className="text-sm font-bold text-foreground">Langue et région</h3></div>
          <SelectField label="Langue de l'interface" value={lang} onChange={setLang} options={["Français", "العربية", "English"]} />
        </div>
        <div className="bg-card rounded-2xl border border-border p-5">
          <div className="flex items-center gap-3 mb-4"><HelpCircle className="w-5 h-5 text-primary" /><h3 className="text-sm font-bold text-foreground">Support</h3></div>
          <div className="space-y-2">
            {["Centre d'aide", "Signaler un problème", "Conditions d'utilisation", "Politique de confidentialité"].map((item) => (
              <button key={item} className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl hover:bg-muted transition-colors duration-150 text-sm text-foreground group">
                <span>{item}</span><ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors duration-150" />
              </button>
            ))}
          </div>
        </div>
        <div className="flex justify-end"><Btn variant="primary">Enregistrer les modifications</Btn></div>
      </div>
    </div>
  );
}

// ── ADMIN SCREENS ──────────────────────────────────────────────────────────
function AdminDashboard() {
  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="mb-6 flex items-start justify-between flex-wrap gap-3">
        <div><h1 className="text-2xl font-bold text-foreground">Tableau de bord</h1><p className="text-sm text-muted-foreground mt-1">Année universitaire 2023–2024 · Semestre 2</p></div>
        <div className="flex items-center gap-2 bg-emerald-50 border border-emerald-200 rounded-xl px-3 py-2"><Activity className="w-4 h-4 text-emerald-600" /><span className="text-xs font-semibold text-emerald-700">Système opérationnel</span></div>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard icon={Users} label="Étudiants inscrits" value="1 710" sub="+42 vs S1" color="blue" trend="up" />
        <StatCard icon={BookOpen} label="Cours actifs" value="87" sub="6 départements" color="green" />
        <StatCard icon={TrendingUp} label="Taux de réussite" value="74.3%" sub="+2.1% vs S1" color="amber" trend="up" />
        <StatCard icon={Award} label="Moyenne générale" value="13.8" sub="/20 tous niveaux" color="purple" trend="up" />
      </div>
      <div className="grid lg:grid-cols-2 gap-5 mb-5">
        <div className="bg-card rounded-2xl border border-border p-5">
          <h2 className="text-base font-bold text-foreground mb-4">Répartition des mentions</h2>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={GRADE_DIST} barSize={34}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="mention" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid var(--border)", fontSize: 12 }} />
              <Bar dataKey="count" radius={[6, 6, 0, 0]}>{GRADE_DIST.map((e, i) => <Cell key={i} fill={e.fill} />)}</Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-card rounded-2xl border border-border p-5">
          <h2 className="text-base font-bold text-foreground mb-4">Présences mensuelles</h2>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={MONTHLY_DATA}>
              <defs>
                <linearGradient id="gI" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#1d4ed8" stopOpacity={0.15} /><stop offset="95%" stopColor="#1d4ed8" stopOpacity={0} /></linearGradient>
                <linearGradient id="gP" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#10b981" stopOpacity={0.15} /><stop offset="95%" stopColor="#10b981" stopOpacity={0} /></linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="month" tick={{ fontSize: 11 }} /><YAxis tick={{ fontSize: 11 }} />
              <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid var(--border)", fontSize: 12 }} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Area type="monotone" dataKey="inscrits" stroke="#1d4ed8" fill="url(#gI)" strokeWidth={2} name="Inscrits" />
              <Area type="monotone" dataKey="presents" stroke="#10b981" fill="url(#gP)" strokeWidth={2} name="Présents" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
      <div className="bg-card rounded-2xl border border-border p-5">
        <div className="flex items-center justify-between mb-4"><h2 className="text-base font-bold text-foreground">Activité récente</h2><button className="text-xs text-primary font-semibold hover:underline">Voir tout</button></div>
        <div className="space-y-3">
          {ACTIVITY_LOG.slice(0, 5).map(({ id, user, action, detail, time, type }) => (
            <div key={id} className="flex items-start gap-3 hover:bg-muted/30 rounded-lg p-1.5 -mx-1.5 transition-colors duration-100">
              <div className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${type === "success" ? "bg-emerald-500" : type === "warning" ? "bg-amber-500" : "bg-blue-500"}`} />
              <div className="flex-1"><p className="text-xs font-medium text-foreground"><span className="font-bold">{user}</span> — {action}</p><p className="text-xs text-muted-foreground">{detail}</p></div>
              <span className="text-xs text-muted-foreground whitespace-nowrap">{time}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function AdminStudents() {
  const [students, setStudents] = useState<Student[]>(INIT_STUDENTS);
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("Tous");
  const [modal, setModal] = useState<{ open: boolean; mode: "add" | "edit"; data: Partial<Student> }>({ open: false, mode: "add", data: {} });
  const [deleteModal, setDeleteModal] = useState<{ open: boolean; id: number | null }>({ open: false, id: null });
  const filtered = students.filter((s) =>
    (s.name.toLowerCase().includes(search.toLowerCase()) || s.matricule.includes(search) || s.filiere.toLowerCase().includes(search.toLowerCase())) &&
    (filterStatus === "Tous" || s.status === filterStatus)
  );
  const closeModal = () => setModal({ open: false, mode: "add", data: {} });
  const save = () => {
    if (modal.mode === "add") setStudents((p) => [...p, { id: Date.now(), name: modal.data.name ?? "", matricule: modal.data.matricule ?? "", filiere: modal.data.filiere ?? "", niveau: modal.data.niveau ?? "", email: modal.data.email ?? "", moyenne: Number(modal.data.moyenne ?? 0), status: modal.data.status ?? "Actif" }]);
    else setStudents((p) => p.map((s) => s.id === modal.data.id ? { ...s, ...modal.data } as Student : s));
    closeModal();
  };
  const sv = (s: string): BadgeVariant => s === "Actif" ? "success" : s === "Avertissement" ? "warning" : "danger";
  return (
    <div className="p-6 max-w-6xl mx-auto">
      <PageHeader title="Gestion des Étudiants" subtitle={`${students.length} étudiants inscrits`} action={
        <div className="flex items-center gap-2 flex-wrap">
          <div className="relative"><Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" /><input type="text" placeholder="Rechercher..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9 pr-4 py-2 text-sm bg-card border border-border rounded-xl focus:outline-none focus:border-primary w-44 transition-all duration-150" /></div>
          <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="px-3 py-2 text-sm bg-card border border-border rounded-xl focus:outline-none focus:border-primary transition-all duration-150 text-foreground">
            {["Tous", "Actif", "Avertissement", "En risque"].map((s) => <option key={s}>{s}</option>)}
          </select>
          <Btn icon={Plus} onClick={() => setModal({ open: true, mode: "add", data: { status: "Actif" } })}>Ajouter</Btn>
        </div>
      } />
      <div className="bg-card rounded-2xl border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="bg-muted/50 border-b border-border">{["Étudiant", "Matricule", "Filière", "Niveau", "Moyenne", "Statut", "Actions"].map((h) => <th key={h} className="text-left text-xs font-semibold text-muted-foreground px-4 py-3 whitespace-nowrap">{h}</th>)}</tr></thead>
            <tbody className="divide-y divide-border">
              {filtered.map((s) => (
                <tr key={s.id} className="hover:bg-muted/30 transition-colors duration-100">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-xs font-bold text-primary flex-shrink-0">{s.name.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase()}</div>
                      <div><div className="text-xs font-semibold text-foreground">{s.name}</div><div className="text-xs text-muted-foreground">{s.email}</div></div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-xs font-mono text-muted-foreground">{s.matricule}</td>
                  <td className="px-4 py-3 text-xs text-foreground">{s.filiere}</td>
                  <td className="px-4 py-3"><Badge variant="info">{s.niveau}</Badge></td>
                  <td className="px-4 py-3"><span className={`text-sm font-bold ${s.moyenne >= 14 ? "text-emerald-600" : s.moyenne >= 10 ? "text-foreground" : "text-red-600"}`}>{s.moyenne.toFixed(1)}</span></td>
                  <td className="px-4 py-3"><Badge variant={sv(s.status)}>{s.status}</Badge></td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <button onClick={() => setModal({ open: true, mode: "edit", data: { ...s } })} className="w-7 h-7 rounded-lg hover:bg-blue-50 flex items-center justify-center transition-colors duration-100" title="Modifier"><Edit2 className="w-3.5 h-3.5 text-primary" /></button>
                      <button onClick={() => setDeleteModal({ open: true, id: s.id })} className="w-7 h-7 rounded-lg hover:bg-red-50 flex items-center justify-center transition-colors duration-100" title="Supprimer"><Trash2 className="w-3.5 h-3.5 text-red-500" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="px-4 py-3 border-t border-border bg-muted/20 flex items-center justify-between">
          <p className="text-xs text-muted-foreground">{filtered.length} résultat{filtered.length > 1 ? "s" : ""} sur {students.length} étudiants</p>
          {search && <button onClick={() => setSearch("")} className="text-xs text-primary hover:underline">Effacer la recherche</button>}
        </div>
      </div>
      <Modal open={modal.open} onClose={closeModal} title={modal.mode === "add" ? "Ajouter un étudiant" : "Modifier l'étudiant"}>
        <div className="grid grid-cols-2 gap-4">
          {[{ label: "Nom complet", field: "name", ph: "Amina Benali" }, { label: "Matricule", field: "matricule", ph: "20210001" }, { label: "Email", field: "email", ph: "a.benali@univ.dz" }, { label: "Filière", field: "filiere", ph: "Informatique" }].map(({ label, field, ph }) => (
            <div key={field}><label className="text-xs font-semibold text-muted-foreground mb-1 block">{label}</label><input value={(modal.data as Record<string, string>)[field] ?? ""} onChange={(e) => setModal({ ...modal, data: { ...modal.data, [field]: e.target.value } })} placeholder={ph} className="w-full px-3 py-2.5 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:border-primary transition-all duration-150" /></div>
          ))}
          <div><label className="text-xs font-semibold text-muted-foreground mb-1 block">Niveau</label><select value={modal.data.niveau ?? ""} onChange={(e) => setModal({ ...modal, data: { ...modal.data, niveau: e.target.value } })} className="w-full px-3 py-2.5 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:border-primary transition-all duration-150">{["", "L1", "L2", "L3", "M1", "M2"].map((n) => <option key={n}>{n}</option>)}</select></div>
          <div><label className="text-xs font-semibold text-muted-foreground mb-1 block">Statut</label><select value={modal.data.status ?? "Actif"} onChange={(e) => setModal({ ...modal, data: { ...modal.data, status: e.target.value } })} className="w-full px-3 py-2.5 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:border-primary transition-all duration-150">{["Actif", "Avertissement", "En risque"].map((s) => <option key={s}>{s}</option>)}</select></div>
          <div><label className="text-xs font-semibold text-muted-foreground mb-1 block">Moyenne</label><input type="number" min={0} max={20} step={0.1} value={modal.data.moyenne ?? ""} onChange={(e) => setModal({ ...modal, data: { ...modal.data, moyenne: parseFloat(e.target.value) } })} placeholder="0–20" className="w-full px-3 py-2.5 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:border-primary transition-all duration-150" /></div>
        </div>
        <div className="flex gap-3 mt-5"><Btn variant="primary" onClick={save}>{modal.mode === "add" ? "Ajouter" : "Enregistrer"}</Btn><Btn variant="ghost" onClick={closeModal}>Annuler</Btn></div>
      </Modal>
      <ConfirmModal open={deleteModal.open} onClose={() => setDeleteModal({ open: false, id: null })} onConfirm={() => { setStudents((p) => p.filter((s) => s.id !== deleteModal.id)); setDeleteModal({ open: false, id: null }); }} title="Supprimer l'étudiant ?" message="Cette action est irréversible. Toutes les données de l'étudiant seront supprimées définitivement." confirmLabel="Supprimer" />
    </div>
  );
}

function AdminRegistrations() {
  return (
    <div className="p-6 max-w-6xl mx-auto">
      <PageHeader title="Gestion des Inscriptions" subtitle="Semestre 2 · 2023–2024" action={<Btn icon={Download} variant="outline" size="sm">Exporter</Btn>} />
      <div className="grid grid-cols-3 gap-4 mb-6">
        <StatCard icon={CheckCircle} label="Inscriptions validées" value="1 642" sub="96.6%" color="green" trend="up" />
        <StatCard icon={Clock} label="En attente" value="68" sub="3.4%" color="amber" />
        <StatCard icon={AlertCircle} label="Paiements en attente" value="24" sub="1.4%" color="red" />
      </div>
      <div className="bg-card rounded-2xl border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="bg-muted/50 border-b border-border">{["Étudiant", "Matricule", "Filière / Niveau", "Cours inscrits", "Date", "Paiement", "Statut"].map((h) => <th key={h} className="text-left text-xs font-semibold text-muted-foreground px-4 py-3">{h}</th>)}</tr></thead>
            <tbody className="divide-y divide-border">
              {INIT_STUDENTS.map((s, i) => (
                <tr key={s.id} className="hover:bg-muted/30 transition-colors duration-100">
                  <td className="px-4 py-3 text-xs font-semibold text-foreground">{s.name}</td>
                  <td className="px-4 py-3 text-xs font-mono text-muted-foreground">{s.matricule}</td>
                  <td className="px-4 py-3 text-xs text-muted-foreground">{s.filiere} · {s.niveau}</td>
                  <td className="px-4 py-3"><span className="text-xs font-bold text-primary">{4 + (i % 3)} cours</span></td>
                  <td className="px-4 py-3 text-xs text-muted-foreground">Sep 2023</td>
                  <td className="px-4 py-3"><Badge variant={i % 5 === 3 ? "warning" : "success"}>{i % 5 === 3 ? "En attente" : "Réglé"}</Badge></td>
                  <td className="px-4 py-3"><Badge variant={i % 7 === 4 ? "warning" : "success"}>{i % 7 === 4 ? "En attente" : "Validée"}</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function AdminCourses() {
  const [courses, setCourses] = useState<Course[]>(COURSES_BASE);
  const [search, setSearch] = useState("");
  const [modal, setModal] = useState<{ open: boolean; mode: "add" | "edit"; data: Partial<Course> }>({ open: false, mode: "add", data: {} });
  const [deleteModal, setDeleteModal] = useState<{ open: boolean; id: number | null }>({ open: false, id: null });
  const filtered = courses.filter((c) => c.name.toLowerCase().includes(search.toLowerCase()) || c.prof.toLowerCase().includes(search.toLowerCase()));
  const closeModal = () => setModal({ open: false, mode: "add", data: {} });
  const save = () => {
    if (modal.mode === "add") setCourses((p) => [...p, { id: Date.now(), name: modal.data.name ?? "", code: modal.data.code ?? "", prof: modal.data.prof ?? "", dept: modal.data.dept ?? "", credits: Number(modal.data.credits ?? 3), enrolled: 0, color: "#1d4ed8" }]);
    else setCourses((p) => p.map((c) => c.id === modal.data.id ? { ...c, ...modal.data } as Course : c));
    closeModal();
  };
  return (
    <div className="p-6 max-w-6xl mx-auto">
      <PageHeader title="Gestion des Cours" subtitle={`${courses.length} cours actifs`} action={
        <div className="flex items-center gap-2">
          <div className="relative"><Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" /><input type="text" placeholder="Rechercher..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9 pr-4 py-2 text-sm bg-card border border-border rounded-xl focus:outline-none focus:border-primary w-44 transition-all duration-150" /></div>
          <Btn icon={Plus} onClick={() => setModal({ open: true, mode: "add", data: {} })}>Ajouter</Btn>
        </div>
      } />
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((c) => (
          <div key={c.id} className="bg-card rounded-2xl border border-border overflow-hidden hover:shadow-md transition-all duration-200 group">
            <div className="h-1.5" style={{ background: c.color }} />
            <div className="p-4">
              <div className="flex items-start justify-between mb-3">
                <div className="w-9 h-9 rounded-xl flex items-center justify-center transition-transform duration-200 group-hover:scale-110" style={{ background: c.color + "20" }}><BookOpen className="w-4 h-4" style={{ color: c.color }} /></div>
                <div className="flex gap-1">
                  <button onClick={() => setModal({ open: true, mode: "edit", data: { ...c } })} className="w-7 h-7 rounded-lg hover:bg-blue-50 flex items-center justify-center transition-colors duration-100"><Edit2 className="w-3.5 h-3.5 text-primary" /></button>
                  <button onClick={() => setDeleteModal({ open: true, id: c.id })} className="w-7 h-7 rounded-lg hover:bg-red-50 flex items-center justify-center transition-colors duration-100"><Trash2 className="w-3.5 h-3.5 text-red-500" /></button>
                </div>
              </div>
              <h3 className="text-sm font-bold text-foreground mb-1">{c.name}</h3>
              <p className="text-xs text-muted-foreground mb-1">{c.prof}</p>
              <p className="text-xs text-muted-foreground mb-3">{c.code} · {c.dept}</p>
              <div className="flex gap-2 flex-wrap"><Badge variant="info">{c.credits} crédits</Badge><Badge variant="success">{c.enrolled} inscrits</Badge></div>
              <button className="mt-3 w-full flex items-center justify-center gap-1.5 text-xs font-medium text-muted-foreground hover:text-primary hover:bg-muted rounded-lg py-1.5 transition-all duration-150"><Upload className="w-3.5 h-3.5" />Importer support PDF</button>
            </div>
          </div>
        ))}
      </div>
      <Modal open={modal.open} onClose={closeModal} title={modal.mode === "add" ? "Ajouter un cours" : "Modifier le cours"}>
        <div className="grid grid-cols-2 gap-4">
          {[{ label: "Nom du cours", field: "name", ph: "Algorithmes Avancés" }, { label: "Code", field: "code", ph: "INFO301" }, { label: "Enseignant", field: "prof", ph: "Dr. Benali" }, { label: "Département", field: "dept", ph: "Informatique" }].map(({ label, field, ph }) => (
            <div key={field}><label className="text-xs font-semibold text-muted-foreground mb-1 block">{label}</label><input value={(modal.data as Record<string, string>)[field] ?? ""} onChange={(e) => setModal({ ...modal, data: { ...modal.data, [field]: e.target.value } })} placeholder={ph} className="w-full px-3 py-2.5 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:border-primary transition-all duration-150" /></div>
          ))}
          <div><label className="text-xs font-semibold text-muted-foreground mb-1 block">Crédits ECTS</label><input type="number" min={1} max={10} value={modal.data.credits ?? ""} onChange={(e) => setModal({ ...modal, data: { ...modal.data, credits: Number(e.target.value) } })} className="w-full px-3 py-2.5 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:border-primary transition-all duration-150" /></div>
        </div>
        <div className="flex gap-3 mt-5"><Btn variant="primary" onClick={save}>{modal.mode === "add" ? "Ajouter" : "Enregistrer"}</Btn><Btn variant="ghost" onClick={closeModal}>Annuler</Btn></div>
      </Modal>
      <ConfirmModal open={deleteModal.open} onClose={() => setDeleteModal({ open: false, id: null })} onConfirm={() => { setCourses((p) => p.filter((c) => c.id !== deleteModal.id)); setDeleteModal({ open: false, id: null }); }} title="Supprimer ce cours ?" message="Cette action est irréversible. Toutes les données associées à ce cours seront supprimées." confirmLabel="Supprimer" />
    </div>
  );
}

function AdminGrades() {
  const [addOpen, setAddOpen] = useState(false);
  const [gf, setGf] = useState({ student: "", course: "", cc: "", td: "", tp: "", exam: "" });
  return (
    <div className="p-6 max-w-5xl mx-auto">
      <PageHeader title="Gestion des Notes" subtitle="Saisie et suivi des notes" action={<Btn icon={Plus} onClick={() => setAddOpen(true)}>Ajouter une note</Btn>} />
      <div className="bg-card rounded-2xl border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="bg-muted/50 border-b border-border">{["Étudiant", "Cours", "CC", "TD", "TP", "Examen", "Finale /20", "Statut", "Actions"].map((h) => <th key={h} className="text-left text-xs font-semibold text-muted-foreground px-4 py-3">{h}</th>)}</tr></thead>
            <tbody className="divide-y divide-border">
              {INIT_STUDENTS.slice(0, 8).flatMap((s, si) =>
                GRADES_TABLE.slice(0, 2).map((g, gi) => {
                  const adj = g.final !== null ? Math.max(0, Math.min(20, g.final - si * 0.4 + gi * 0.3)) : null;
                  return (
                    <tr key={`${s.id}-${gi}`} className="hover:bg-muted/30 transition-colors duration-100">
                      <td className="px-4 py-3 text-xs font-semibold text-foreground">{s.name}</td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{g.course}</td>
                      <td className="px-4 py-3 text-center text-xs">{g.cc ?? "—"}</td>
                      <td className="px-4 py-3 text-center text-xs">{g.td ?? "—"}</td>
                      <td className="px-4 py-3 text-center text-xs">{g.tp ?? "—"}</td>
                      <td className="px-4 py-3 text-center text-xs">{g.exam ?? "—"}</td>
                      <td className="px-4 py-3 text-center">{adj !== null ? <span className={`text-sm font-bold ${adj >= 14 ? "text-emerald-600" : adj >= 10 ? "text-foreground" : "text-red-600"}`}>{adj.toFixed(1)}</span> : "—"}</td>
                      <td className="px-4 py-3"><Badge variant={adj !== null && adj >= 10 ? "success" : "danger"}>{adj !== null && adj >= 10 ? "Admis" : "Ajourné"}</Badge></td>
                      <td className="px-4 py-3"><button className="w-7 h-7 rounded-lg hover:bg-blue-50 flex items-center justify-center transition-colors duration-100"><Edit2 className="w-3.5 h-3.5 text-primary" /></button></td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
      <Modal open={addOpen} onClose={() => setAddOpen(false)} title="Ajouter une note">
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2"><label className="text-xs font-semibold text-muted-foreground mb-1 block">Étudiant</label><select value={gf.student} onChange={(e) => setGf({ ...gf, student: e.target.value })} className="w-full px-3 py-2.5 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:border-primary transition-all duration-150"><option value="">Sélectionner un étudiant</option>{INIT_STUDENTS.map((s) => <option key={s.id}>{s.name} ({s.matricule})</option>)}</select></div>
          <div className="col-span-2"><label className="text-xs font-semibold text-muted-foreground mb-1 block">Cours</label><select value={gf.course} onChange={(e) => setGf({ ...gf, course: e.target.value })} className="w-full px-3 py-2.5 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:border-primary transition-all duration-150"><option value="">Sélectionner un cours</option>{COURSES_BASE.map((c) => <option key={c.id}>{c.name}</option>)}</select></div>
          {[{ label: "CC /20", field: "cc" as const }, { label: "TD /20", field: "td" as const }, { label: "TP /20", field: "tp" as const }, { label: "Examen /20", field: "exam" as const }].map(({ label, field }) => (
            <div key={field}><label className="text-xs font-semibold text-muted-foreground mb-1 block">{label}</label><input type="number" min={0} max={20} step={0.5} value={gf[field]} onChange={(e) => setGf({ ...gf, [field]: e.target.value })} placeholder="0–20" className="w-full px-3 py-2.5 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:border-primary transition-all duration-150" /></div>
          ))}
        </div>
        <div className="flex gap-3 mt-5"><Btn variant="primary" onClick={() => setAddOpen(false)}>Enregistrer</Btn><Btn variant="ghost" onClick={() => setAddOpen(false)}>Annuler</Btn></div>
      </Modal>
    </div>
  );
}

function AdminAnnouncements() {
  const [announcements, setAnnouncements] = useState(ANNOUNCEMENTS_DATA);
  const [addOpen, setAddOpen] = useState(false);
  const [form, setForm] = useState({ title: "", content: "", type: "Info", urgent: false });
  const add = () => { setAnnouncements((p) => [{ id: Date.now(), ...form, date: "Aujourd'hui", author: "Administration" }, ...p]); setAddOpen(false); setForm({ title: "", content: "", type: "Info", urgent: false }); };
  return (
    <div className="p-6 max-w-4xl mx-auto">
      <PageHeader title="Gestion des Annonces" subtitle={`${announcements.length} annonces publiées`} action={<Btn icon={Plus} onClick={() => setAddOpen(true)}>Nouvelle annonce</Btn>} />
      <div className="space-y-3">
        {announcements.map((a) => (
          <div key={a.id} className={`bg-card rounded-2xl border p-4 flex gap-3 hover:shadow-sm transition-all duration-150 ${a.urgent ? "border-red-200" : "border-border"}`}>
            <div className="flex-1"><div className="flex items-center gap-2 flex-wrap mb-1"><h3 className="text-sm font-bold text-foreground">{a.title}</h3>{a.urgent && <Badge variant="danger">Urgent</Badge>}<Badge variant="info">{a.type}</Badge></div><p className="text-xs text-muted-foreground mb-2 leading-relaxed">{a.content}</p><p className="text-xs text-muted-foreground">{a.date} · {a.author}</p></div>
            <button onClick={() => setAnnouncements((p) => p.filter((x) => x.id !== a.id))} className="w-7 h-7 rounded-lg hover:bg-red-50 flex items-center justify-center flex-shrink-0 transition-colors duration-100"><Trash2 className="w-3.5 h-3.5 text-red-500" /></button>
          </div>
        ))}
      </div>
      <Modal open={addOpen} onClose={() => setAddOpen(false)} title="Nouvelle annonce">
        <div className="flex flex-col gap-4">
          <div><label className="text-xs font-semibold text-muted-foreground mb-1 block">Titre</label><input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Titre de l'annonce" className="w-full px-3 py-2.5 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:border-primary transition-all duration-150" /></div>
          <div><label className="text-xs font-semibold text-muted-foreground mb-1 block">Contenu</label><textarea rows={4} value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} placeholder="Contenu de l'annonce..." className="w-full px-3 py-2.5 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:border-primary transition-all duration-150 resize-none" /></div>
          <div className="grid grid-cols-2 gap-4">
            <div><label className="text-xs font-semibold text-muted-foreground mb-1 block">Type</label><select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} className="w-full px-3 py-2.5 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:border-primary transition-all duration-150">{["Examen", "Devoir", "Événement", "Inscription", "Info"].map((t) => <option key={t}>{t}</option>)}</select></div>
            <div className="flex items-end pb-1"><label className="flex items-center gap-2.5 cursor-pointer"><input type="checkbox" checked={form.urgent} onChange={(e) => setForm({ ...form, urgent: e.target.checked })} className="w-4 h-4 accent-primary" /><span className="text-sm font-medium text-foreground">Marquer comme urgent</span></label></div>
          </div>
          <div className="flex gap-3"><Btn variant="primary" onClick={add}>Publier</Btn><Btn variant="ghost" onClick={() => setAddOpen(false)}>Annuler</Btn></div>
        </div>
      </Modal>
    </div>
  );
}

function AdminUsers() {
  const users = [
    { id: 1, name: "Prof. Benali", email: "benali@univ.dz", role: "Enseignant", dept: "Informatique", status: "Actif", lastLogin: "Aujourd'hui, 09h15" },
    { id: 2, name: "Prof. Yousfi", email: "yousfi@univ.dz", role: "Enseignant", dept: "Informatique", status: "Actif", lastLogin: "Hier, 14h30" },
    { id: 3, name: "Scolarité DZ", email: "scolarite@univ.dz", role: "Administrateur", dept: "Administration", status: "Actif", lastLogin: "Il y a 2h" },
    { id: 4, name: "Prof. Farid", email: "farid@univ.dz", role: "Enseignant", dept: "Mathématiques", status: "Inactif", lastLogin: "Il y a 5 jours" },
    { id: 5, name: "Support Tech", email: "support@univ.dz", role: "Technicien", dept: "DSI", status: "Actif", lastLogin: "Il y a 1h" },
  ];
  const [addOpen, setAddOpen] = useState(false);
  return (
    <div className="p-6 max-w-5xl mx-auto">
      <PageHeader title="Gestion des Utilisateurs" subtitle={`${users.length} comptes actifs`} action={<Btn icon={Plus} onClick={() => setAddOpen(true)}>Ajouter un utilisateur</Btn>} />
      <div className="bg-card rounded-2xl border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="bg-muted/50 border-b border-border">{["Utilisateur", "Rôle", "Département", "Dernière connexion", "Statut", "Actions"].map((h) => <th key={h} className="text-left text-xs font-semibold text-muted-foreground px-4 py-3">{h}</th>)}</tr></thead>
            <tbody className="divide-y divide-border">
              {users.map((u) => (
                <tr key={u.id} className="hover:bg-muted/30 transition-colors duration-100">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-xs font-bold text-primary">{u.name.split(" ").map((n) => n[0]).join("").slice(0, 2)}</div>
                      <div><div className="text-xs font-semibold text-foreground">{u.name}</div><div className="text-xs text-muted-foreground">{u.email}</div></div>
                    </div>
                  </td>
                  <td className="px-4 py-3"><Badge variant={u.role === "Administrateur" ? "danger" : u.role === "Enseignant" ? "info" : "default"}>{u.role}</Badge></td>
                  <td className="px-4 py-3 text-xs text-muted-foreground">{u.dept}</td>
                  <td className="px-4 py-3 text-xs text-muted-foreground">{u.lastLogin}</td>
                  <td className="px-4 py-3"><Badge variant={u.status === "Actif" ? "success" : "default"}>{u.status}</Badge></td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <button className="w-7 h-7 rounded-lg hover:bg-blue-50 flex items-center justify-center transition-colors duration-100"><Edit2 className="w-3.5 h-3.5 text-primary" /></button>
                      <button className="w-7 h-7 rounded-lg hover:bg-red-50 flex items-center justify-center transition-colors duration-100"><Trash2 className="w-3.5 h-3.5 text-red-500" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <Modal open={addOpen} onClose={() => setAddOpen(false)} title="Ajouter un utilisateur">
        <div className="grid grid-cols-2 gap-4">
          {[{ label: "Nom complet", ph: "Prof. Benali" }, { label: "Email", ph: "benali@univ.dz" }].map(({ label, ph }) => (
            <div key={label}><label className="text-xs font-semibold text-muted-foreground mb-1 block">{label}</label><input placeholder={ph} className="w-full px-3 py-2.5 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:border-primary transition-all duration-150" /></div>
          ))}
          <div><label className="text-xs font-semibold text-muted-foreground mb-1 block">Rôle</label><select className="w-full px-3 py-2.5 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:border-primary transition-all duration-150">{["Enseignant", "Administrateur", "Technicien"].map((r) => <option key={r}>{r}</option>)}</select></div>
          <div><label className="text-xs font-semibold text-muted-foreground mb-1 block">Département</label><select className="w-full px-3 py-2.5 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:border-primary transition-all duration-150">{["Informatique", "Mathématiques", "Physique", "Administration", "DSI"].map((d) => <option key={d}>{d}</option>)}</select></div>
        </div>
        <div className="flex gap-3 mt-5"><Btn variant="primary" onClick={() => setAddOpen(false)}>Ajouter</Btn><Btn variant="ghost" onClick={() => setAddOpen(false)}>Annuler</Btn></div>
      </Modal>
    </div>
  );
}

function AdminStatistics() {
  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="flex items-start justify-between mb-6 flex-wrap gap-3">
        <div><h1 className="text-2xl font-bold text-foreground">Statistiques</h1><p className="text-sm text-muted-foreground">Année 2023–2024 · Semestre 2</p></div>
        <div className="flex gap-2"><select className="px-3 py-2 text-sm bg-card border border-border rounded-xl focus:outline-none focus:border-primary transition-all duration-150 text-foreground"><option>S2 2023-2024</option><option>S1 2023-2024</option><option>S2 2022-2023</option></select><Btn icon={Download} variant="outline" size="sm">Exporter</Btn></div>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard icon={Users} label="Total étudiants" value="1 710" sub="12 filières" color="blue" trend="up" />
        <StatCard icon={TrendingUp} label="Taux de réussite" value="74.3%" sub="+2.1% vs S1" color="green" trend="up" />
        <StatCard icon={Award} label="Moyenne générale" value="13.8" sub="/20" color="amber" trend="up" />
        <StatCard icon={BookOpen} label="Cours dispensés" value="87" sub="450h au total" color="purple" />
      </div>
      <div className="grid lg:grid-cols-2 gap-5 mb-5">
        <div className="bg-card rounded-2xl border border-border p-5">
          <h2 className="text-base font-bold text-foreground mb-4">Taux de réussite par département (%)</h2>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={DEPT_DATA} layout="vertical" barSize={20}>
              <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="var(--border)" />
              <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 11 }} />
              <YAxis type="category" dataKey="dept" tick={{ fontSize: 11 }} width={95} />
              <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid var(--border)", fontSize: 12 }} formatter={(v) => [`${v}%`, "Taux de réussite"]} />
              <Bar dataKey="reussite" fill="#1d4ed8" radius={[0, 6, 6, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-card rounded-2xl border border-border p-5">
          <h2 className="text-base font-bold text-foreground mb-4">Évolution de la moyenne générale</h2>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={SEM_AVG}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="sem" tick={{ fontSize: 11 }} /><YAxis domain={[11, 16]} tick={{ fontSize: 11 }} />
              <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid var(--border)", fontSize: 12 }} />
              <Line type="monotone" dataKey="avg" stroke="#10b981" strokeWidth={2.5} dot={{ fill: "#10b981", r: 4 }} name="Moyenne" />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-card rounded-2xl border border-border p-5">
          <h2 className="text-base font-bold text-foreground mb-4">Répartition des mentions</h2>
          <div className="flex items-center gap-4">
            <ResponsiveContainer width={180} height={180}>
              <PieChart><Pie data={GRADE_DIST} cx="50%" cy="50%" innerRadius={45} outerRadius={75} dataKey="count" paddingAngle={3}>{GRADE_DIST.map((e, i) => <Cell key={i} fill={e.fill} />)}</Pie><Tooltip contentStyle={{ borderRadius: 12, border: "1px solid var(--border)", fontSize: 12 }} /></PieChart>
            </ResponsiveContainer>
            <div className="space-y-2 flex-1">
              {GRADE_DIST.map((d) => (
                <div key={d.mention} className="flex items-center gap-2"><div className="w-3 h-3 rounded-sm flex-shrink-0" style={{ background: d.fill }} /><span className="text-xs text-foreground flex-1">{d.mention}</span><span className="text-xs font-bold">{d.count}</span></div>
              ))}
            </div>
          </div>
        </div>
        <div className="bg-card rounded-2xl border border-border p-5">
          <h2 className="text-base font-bold text-foreground mb-4">Effectifs par département</h2>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={DEPT_DATA} barSize={26}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="dept" tick={{ fontSize: 10 }} /><YAxis tick={{ fontSize: 11 }} />
              <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid var(--border)", fontSize: 12 }} />
              <Bar dataKey="etudiants" fill="#10b981" radius={[6, 6, 0, 0]} name="Étudiants" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

function AdminActivity() {
  const [filter, setFilter] = useState("Tous");
  const types = ["Tous", "info", "success", "warning"];
  const filtered = filter === "Tous" ? ACTIVITY_LOG : ACTIVITY_LOG.filter((a) => a.type === filter);
  return (
    <div className="p-6 max-w-4xl mx-auto">
      <PageHeader title="Journal d'Activité" subtitle="Historique des actions administratives" action={<Btn icon={Download} variant="outline" size="sm">Exporter</Btn>} />
      <div className="flex gap-2 mb-5">
        {types.map((t) => <button key={t} onClick={() => setFilter(t)} className={`px-3 py-1.5 text-xs font-semibold rounded-full border transition-all duration-150 capitalize ${filter === t ? "bg-primary text-white border-primary shadow-sm" : "bg-card text-muted-foreground border-border hover:border-primary/30"}`}>{{ Tous: "Tous", info: "Info", success: "Succès", warning: "Avertissement" }[t]}</button>)}
      </div>
      <div className="bg-card rounded-2xl border border-border overflow-hidden">
        <div className="divide-y divide-border">
          {filtered.map((a) => (
            <div key={a.id} className="flex items-start gap-4 p-4 hover:bg-muted/30 transition-colors duration-100">
              <div className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 ${a.type === "success" ? "bg-emerald-100" : a.type === "warning" ? "bg-amber-100" : "bg-blue-100"}`}>
                <Activity className={`w-4 h-4 ${a.type === "success" ? "text-emerald-600" : a.type === "warning" ? "text-amber-600" : "text-blue-600"}`} />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-0.5"><span className="text-xs font-bold text-foreground">{a.user}</span><span className="text-xs text-muted-foreground">—</span><span className="text-xs font-medium text-foreground">{a.action}</span></div>
                <p className="text-xs text-muted-foreground">{a.detail}</p>
              </div>
              <span className="text-xs text-muted-foreground whitespace-nowrap">{a.time}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function AdminSettings() {
  const [notifications, setNotifications] = useState({ newStudent: true, newCourse: false, lowGrades: true, systemAlerts: true });
  return (
    <div className="p-6 max-w-2xl mx-auto">
      <PageHeader title="Paramètres Administrateur" subtitle="Configuration de la plateforme" />
      <div className="space-y-5">
        <div className="bg-card rounded-2xl border border-border p-5">
          <div className="flex items-center gap-3 mb-4"><GraduationCap className="w-5 h-5 text-primary" /><h3 className="text-sm font-bold text-foreground">Informations de l'établissement</h3></div>
          <div className="grid sm:grid-cols-2 gap-4">
            {[["Nom de l'université", "Université d'Alger 1"], ["Adresse", "123 Rue de l'Université, Alger"], ["Email de contact", "admin@univ.dz"], ["Téléphone", "+213 21 123 456"]].map(([label, val]) => (
              <div key={label}><label className="text-xs font-semibold text-muted-foreground mb-1 block">{label}</label><input defaultValue={val} className="w-full px-3 py-2.5 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:border-primary transition-all duration-150" /></div>
            ))}
          </div>
        </div>
        <div className="bg-card rounded-2xl border border-border p-5">
          <div className="flex items-center gap-3 mb-4"><BellRing className="w-5 h-5 text-primary" /><h3 className="text-sm font-bold text-foreground">Notifications administrateur</h3></div>
          <div className="space-y-3">
            {([["newStudent", "Nouveau étudiant inscrit"], ["newCourse", "Nouveau cours ajouté"], ["lowGrades", "Alerte notes insuffisantes"], ["systemAlerts", "Alertes système"]] as const).map(([key, label]) => (
              <div key={key} className="flex items-center justify-between py-2 border-b border-border last:border-b-0">
                <span className="text-sm text-foreground">{label}</span>
                <button onClick={() => setNotifications((p) => ({ ...p, [key]: !p[key] }))} className={`w-11 h-6 rounded-full transition-all duration-200 relative ${notifications[key] ? "bg-primary" : "bg-muted"}`}>
                  <div className={`w-4 h-4 rounded-full bg-white shadow absolute top-1 transition-all duration-200 ${notifications[key] ? "right-1" : "left-1"}`} />
                </button>
              </div>
            ))}
          </div>
        </div>
        <div className="bg-card rounded-2xl border border-border p-5">
          <div className="flex items-center gap-3 mb-4"><Sliders className="w-5 h-5 text-primary" /><h3 className="text-sm font-bold text-foreground">Paramètres académiques</h3></div>
          <div className="grid sm:grid-cols-2 gap-4">
            <div><label className="text-xs font-semibold text-muted-foreground mb-1 block">Note minimale de validation</label><input type="number" defaultValue={10} min={0} max={20} className="w-full px-3 py-2.5 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:border-primary transition-all duration-150" /></div>
            <div><label className="text-xs font-semibold text-muted-foreground mb-1 block">Taux d'absence maximum (%)</label><input type="number" defaultValue={25} min={0} max={100} className="w-full px-3 py-2.5 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:border-primary transition-all duration-150" /></div>
          </div>
        </div>
        <div className="flex justify-end"><Btn variant="primary">Enregistrer les modifications</Btn></div>
      </div>
    </div>
  );
}

// ── APP LAYOUT ─────────────────────────────────────────────────────────────
function AppLayout({ role, view, setView, children, isChat, notifs, setNotifs, onLogout }: {
  role: Role; view: View; setView: (v: View) => void; children: React.ReactNode; isChat?: boolean;
  notifs: Notif[]; setNotifs: (n: Notif[]) => void; onLogout: () => void;
}) {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  return (
    <div className="flex h-screen bg-background overflow-hidden relative" style={{ fontFamily: "'Poppins', sans-serif" }}>
      <Sidebar role={role} view={view} setView={setView} collapsed={collapsed} setCollapsed={setCollapsed} mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} onLogout={onLogout} />
      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        <TopBar role={role} view={view} setView={setView} setMobileOpen={setMobileOpen} notifs={notifs} setNotifs={setNotifs} onLogout={onLogout} />
        <main className={`flex-1 ${isChat ? "overflow-hidden flex flex-col" : "overflow-y-auto"}`} style={{ scrollbarWidth: "thin" }}>
          {children}
        </main>
      </div>
    </div>
  );
}

// ── PROFILE SELECT ─────────────────────────────────────────────────────────
function ProfileSelect({ setView, setRole }: { setView: (v: View) => void; setRole: (r: Role) => void }) {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4" style={{ fontFamily: "'Poppins', sans-serif" }}>
      <div className="w-full max-w-lg">
        <div className="text-center mb-10">
          <div className="w-14 h-14 rounded-2xl bg-primary flex items-center justify-center shadow-lg mx-auto mb-4"><GraduationCap className="w-7 h-7 text-white" /></div>
          <h1 className="text-2xl font-bold text-foreground">Choisissez votre profil</h1>
          <p className="text-muted-foreground text-sm mt-2">Sélectionnez votre espace pour accéder à la plateforme</p>
        </div>
        <div className="grid sm:grid-cols-2 gap-5">
          {[
            { role: "student" as Role, icon: User, label: "Étudiant", desc: "Accédez à vos cours, notes, horaires et à votre assistant IA personnel.", borderHover: "hover:border-primary", iconBg: "bg-blue-50", iconColor: "text-primary", actionColor: "text-primary", view: "s-dashboard" as View },
            { role: "admin" as Role, icon: Shield, label: "Administrateur", desc: "Gérez étudiants, cours, notes et consultez les statistiques complètes.", borderHover: "hover:border-accent", iconBg: "bg-emerald-50", iconColor: "text-accent", actionColor: "text-accent", view: "a-dashboard" as View },
          ].map(({ role, icon: Icon, label, desc, borderHover, iconBg, iconColor, actionColor, view }) => (
            <button key={role} onClick={() => { setRole(role); setView(view); }}
              className={`group bg-card rounded-2xl border-2 border-border ${borderHover} hover:shadow-lg transition-all duration-200 p-8 text-center`}>
              <div className={`w-16 h-16 rounded-2xl ${iconBg} flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-200`}><Icon className={`w-8 h-8 ${iconColor}`} /></div>
              <h2 className="text-base font-bold text-foreground mb-2">{label}</h2>
              <p className="text-xs text-muted-foreground leading-relaxed">{desc}</p>
              <div className={`mt-4 flex items-center justify-center gap-1 text-xs font-semibold ${actionColor} opacity-0 group-hover:opacity-100 transition-opacity duration-200`}>Accéder <ArrowRight className="w-3.5 h-3.5" /></div>
            </button>
          ))}
        </div>
        <div className="text-center mt-6"><button onClick={() => setView("landing")} className="text-sm text-muted-foreground hover:text-foreground transition-colors duration-150">← Retour à l'accueil</button></div>
      </div>
    </div>
  );
}

// ── LANDING PAGE ───────────────────────────────────────────────────────────
const FEATURES_DATA = [
  { icon: BookOpen, color: "blue", title: "Suivi des Cours", description: "Accédez à tous vos cours, supports et ressources. Organisation claire par module et recherche avancée." },
  { icon: BarChart3, color: "green", title: "Notes & Résultats", description: "Consultez vos notes en temps réel avec graphiques de progression et analyses détaillées." },
  { icon: Calendar, color: "blue", title: "Emploi du Temps", description: "Grille hebdomadaire interactive avec rappels automatiques et export PDF." },
  { icon: Brain, color: "green", title: "Assistant IA", description: "Posez vos questions sur vos cours, règlements et procédures. Disponible 24h/24." },
  { icon: Bell, color: "blue", title: "Annonces & Alertes", description: "Restez informé des annonces et notifications en temps réel." },
  { icon: Users, color: "green", title: "Gestion Administrative", description: "CRUD complet pour étudiants, cours, notes et statistiques avec graphiques." },
];
const STATS_LANDING = [{ value: "12,000+", label: "Étudiants actifs", icon: Users }, { value: "320+", label: "Cours disponibles", icon: BookOpen }, { value: "98%", label: "Satisfaction étudiante", icon: Star }, { value: "24/7", label: "Assistant IA disponible", icon: Brain }];
const TESTIMONIALS_DATA = [
  { name: "Amina Benali", role: "Étudiante en Informatique, L3", avatar: "AB", text: "L'assistant IA m'a vraiment aidée à comprendre des concepts complexes. Je l'utilise chaque jour avant mes examens.", rating: 5 },
  { name: "Youssef Alaoui", role: "Étudiant en Génie Civil, M1", avatar: "YA", text: "Le suivi des notes en temps réel avec les graphiques de progression est exceptionnel.", rating: 5 },
  { name: "Prof. Leila Mansouri", role: "Professeure, Département Sciences", avatar: "LM", text: "La gestion des annonces et des notes est devenue tellement plus simple. Un gain de temps considérable.", rating: 5 },
];

function LandingPage({ onLogin, onStart }: { onLogin: () => void; onStart: () => void }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [contactSent, setContactSent] = useState(false);
  const [contactForm, setContactForm] = useState({ name: "", email: "", subject: "", message: "" });
  useEffect(() => { const fn = () => setScrolled(window.scrollY > 20); window.addEventListener("scroll", fn); return () => window.removeEventListener("scroll", fn); }, []);
  const navLinks = [{ label: "Fonctionnalités", href: "#features" }, { label: "Comment ça marche", href: "#how-it-works" }, { label: "À propos", href: "#about" }, { label: "Contact", href: "#contact" }];
  return (
    <div>
      <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? "bg-white/95 backdrop-blur-md shadow-sm border-b border-border" : "bg-transparent"}`}>
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center shadow-md"><GraduationCap className="w-5 h-5 text-white" /></div>
              <div className="leading-tight"><span className="font-bold text-sm text-foreground tracking-tight">AAI</span><span className="hidden sm:block text-xs text-muted-foreground leading-none">Assistant Académique</span></div>
            </div>
            <nav className="hidden md:flex items-center gap-8">{navLinks.map((l) => <a key={l.label} href={l.href} className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors duration-150">{l.label}</a>)}</nav>
            <div className="hidden md:flex items-center gap-3">
              <button onClick={onLogin} className="px-4 py-2 text-sm font-semibold text-primary border border-primary/30 rounded-xl hover:bg-primary/5 transition-all duration-150 active:scale-95">Se connecter</button>
              <button onClick={onStart} className="px-4 py-2 text-sm font-semibold text-white bg-primary rounded-xl hover:bg-blue-700 transition-all duration-150 active:scale-95 shadow-sm">Commencer</button>
            </div>
            <button className="md:hidden p-2 rounded-lg hover:bg-muted transition-colors duration-150" onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}</button>
          </div>
        </div>
        {menuOpen && (
          <div className="md:hidden bg-white border-t border-border px-6 py-4 flex flex-col gap-4">
            {navLinks.map((l) => <a key={l.label} href={l.href} className="text-sm font-medium text-foreground" onClick={() => setMenuOpen(false)}>{l.label}</a>)}
            <div className="flex flex-col gap-2 pt-2 border-t border-border">
              <button onClick={() => { setMenuOpen(false); onLogin(); }} className="w-full py-2.5 text-sm font-semibold text-primary border border-primary/30 rounded-xl active:scale-95 transition-all duration-150">Se connecter</button>
              <button onClick={() => { setMenuOpen(false); onStart(); }} className="w-full py-2.5 text-sm font-semibold text-white bg-primary rounded-xl active:scale-95 transition-all duration-150">Commencer</button>
            </div>
          </div>
        )}
      </header>

      {/* Hero */}
      <section className="relative pt-28 pb-20 lg:pt-36 lg:pb-28 overflow-hidden">
        <div className="absolute inset-0 -z-10"><div className="absolute top-0 left-1/2 -translate-x-1/2 w-[900px] h-[600px] rounded-full bg-gradient-to-br from-blue-100/80 via-blue-50/60 to-emerald-100/50 blur-3xl" /></div>
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-6"><Sparkles className="w-3.5 h-3.5 text-primary" /><span className="text-xs font-semibold text-primary">Propulsé par l'Intelligence Artificielle</span></div>
              <h1 className="text-4xl lg:text-5xl xl:text-6xl font-bold text-foreground leading-tight mb-6">
                Votre <span className="text-primary relative">réussite académique<svg className="absolute -bottom-1 left-0 w-full" viewBox="0 0 300 8" fill="none"><path d="M1 5.5C50 2 100 1 150 2.5C200 4 250 5.5 299 5" stroke="#10b981" strokeWidth="3" strokeLinecap="round" /></svg></span> commence ici
              </h1>
              <p className="text-lg text-muted-foreground leading-relaxed mb-8 max-w-lg">Plateforme universitaire intelligente avec assistant IA, suivi de cours, notes avec graphiques et gestion administrative complète.</p>
              <div className="flex flex-wrap gap-4 mb-10">
                <button onClick={onStart} className="flex items-center gap-2 px-6 py-3 text-white font-semibold bg-primary rounded-xl hover:bg-blue-700 transition-all duration-150 active:scale-95 shadow-md hover:shadow-lg">Commencer gratuitement <ArrowRight className="w-4 h-4" /></button>
                <button onClick={onLogin} className="flex items-center gap-2 px-6 py-3 text-foreground font-semibold bg-white rounded-xl border border-border hover:border-primary/40 hover:bg-primary/5 transition-all duration-150 active:scale-95 shadow-sm">Se connecter</button>
              </div>
              <div className="flex flex-wrap gap-5">{["Inscription gratuite", "Accès instantané", "IA 24h/24"].map((item) => <div key={item} className="flex items-center gap-1.5"><CheckCircle className="w-4 h-4 text-accent" /><span className="text-sm font-medium text-muted-foreground">{item}</span></div>)}</div>
            </div>
            <div className="relative">
              <div className="bg-white rounded-2xl shadow-2xl border border-border p-5">
                <div className="flex items-center justify-between mb-4 pb-4 border-b border-border"><div className="flex items-center gap-2"><div className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center"><GraduationCap className="w-4 h-4 text-white" /></div><span className="text-sm font-bold text-foreground">Tableau de bord</span></div><div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-accent animate-pulse" /><span className="text-xs text-accent font-medium">IA Active</span></div></div>
                <div className="grid grid-cols-3 gap-3 mb-4">{[{ label: "Cours", val: "8", bg: "bg-blue-50", text: "text-blue-600", Icon: BookOpen }, { label: "Moyenne", val: "15.4", bg: "bg-emerald-50", text: "text-emerald-600", Icon: TrendingUp }, { label: "Heures", val: "24h", bg: "bg-purple-50", text: "text-purple-600", Icon: Clock }].map(({ label, val, bg, text, Icon }) => <div key={label} className={`${bg} rounded-xl p-3`}><Icon className={`w-4 h-4 ${text} mb-1`} /><div className={`text-lg font-bold ${text}`}>{val}</div><div className="text-xs text-muted-foreground">{label}</div></div>)}</div>
                <div className="space-y-2 mb-4">{[{ name: "Algorithmes Avancés", progress: 78, color: "bg-blue-500" }, { name: "Base de Données", progress: 65, color: "bg-emerald-500" }, { name: "Réseaux Informatiques", progress: 90, color: "bg-violet-500" }].map((c) => <div key={c.name} className="flex items-center gap-3 p-2.5 rounded-xl bg-muted/50"><div className={`w-1.5 h-8 rounded-full ${c.color}`} /><div className="flex-1"><div className="text-xs font-semibold text-foreground">{c.name}</div><div className="h-1 mt-1 bg-border rounded-full overflow-hidden"><div className={`h-full ${c.color} rounded-full`} style={{ width: `${c.progress}%` }} /></div></div><span className="text-xs font-bold text-muted-foreground">{c.progress}%</span></div>)}</div>
                <div className="bg-gradient-to-r from-primary/5 to-accent/5 border border-primary/10 rounded-xl p-3 flex gap-2"><div className="w-6 h-6 rounded-lg bg-primary flex items-center justify-center flex-shrink-0"><Brain className="w-3.5 h-3.5 text-white" /></div><div><div className="text-xs font-semibold text-primary mb-0.5">Assistant IA</div><p className="text-xs text-muted-foreground">Votre examen d'algorithmes est dans 5 jours. Souhaitez-vous réviser les arbres binaires ?</p></div></div>
              </div>
              <div className="absolute -top-4 -right-4 bg-white rounded-2xl shadow-lg border border-border px-3 py-2 flex items-center gap-2"><div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center"><Star className="w-4 h-4 text-emerald-600 fill-emerald-600" /></div><div><div className="text-xs font-bold text-foreground">4.9/5</div><div className="text-xs text-muted-foreground">Satisfaction</div></div></div>
              <div className="absolute -bottom-4 -left-4 bg-white rounded-2xl shadow-lg border border-border px-3 py-2 flex items-center gap-2"><div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center"><Users className="w-4 h-4 text-blue-600" /></div><div><div className="text-xs font-bold text-foreground">12k+</div><div className="text-xs text-muted-foreground">Étudiants</div></div></div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 bg-primary"><div className="max-w-7xl mx-auto px-6 lg:px-8"><div className="grid grid-cols-2 md:grid-cols-4 gap-6 lg:divide-x lg:divide-white/20">{STATS_LANDING.map(({ value, label, icon: Icon }) => <div key={label} className="flex flex-col items-center text-center px-6"><Icon className="w-6 h-6 text-white/70 mb-2" /><div className="text-3xl font-bold text-white">{value}</div><div className="text-sm text-blue-200 mt-0.5">{label}</div></div>)}</div></div></section>

      {/* Features */}
      <section id="features" className="py-20 lg:py-28">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-14"><div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-accent/10 border border-accent/20 mb-4"><Zap className="w-3.5 h-3.5 text-accent" /><span className="text-xs font-semibold text-accent">Fonctionnalités Complètes</span></div><h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">Tout ce dont vous avez besoin</h2><p className="text-muted-foreground max-w-xl mx-auto leading-relaxed">Suite complète pour étudiants et administrateurs.</p></div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {FEATURES_DATA.map(({ icon: Icon, color, title, description }) => (
              <div key={title} className="group bg-card rounded-2xl border border-border p-6 hover:shadow-lg hover:-translate-y-1 transition-all duration-200 cursor-pointer">
                <div className={`w-11 h-11 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-200 ${color === "blue" ? "bg-blue-50" : "bg-emerald-50"}`}><Icon className={`w-5 h-5 ${color === "blue" ? "text-blue-600" : "text-emerald-600"}`} /></div>
                <h3 className="text-base font-bold text-foreground mb-2">{title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section id="how-it-works" className="py-20 lg:py-28 bg-gradient-to-br from-primary/5 via-background to-accent/5">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-14"><div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-4"><Globe className="w-3.5 h-3.5 text-primary" /><span className="text-xs font-semibold text-primary">Démarrez en 3 étapes</span></div><h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">Comment ça marche ?</h2></div>
          <div className="grid md:grid-cols-3 gap-8">
            {[{ step: "01", title: "Créez votre compte", desc: "Inscrivez-vous avec votre email universitaire.", icon: Users }, { step: "02", title: "Explorez votre tableau de bord", desc: "Accédez à vos cours, notes et emploi du temps.", icon: GraduationCap }, { step: "03", title: "Interagissez avec l'IA", desc: "Posez vos questions et optimisez votre apprentissage.", icon: Sparkles }].map(({ step, title, desc, icon: Icon }, i) => (
              <div key={step} className="text-center">
                <div className="relative inline-flex mb-6"><div className="w-16 h-16 rounded-2xl bg-white shadow-md border border-border flex items-center justify-center"><Icon className="w-7 h-7 text-primary" /></div><div className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-primary text-white text-xs font-bold flex items-center justify-center shadow">{i + 1}</div></div>
                <div className="text-xs font-bold text-primary/50 tracking-widest mb-2">ÉTAPE {step}</div>
                <h3 className="text-lg font-bold text-foreground mb-3">{title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed max-w-xs mx-auto">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 lg:py-28"><div className="max-w-7xl mx-auto px-6 lg:px-8"><div className="text-center mb-14"><h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">Ce que disent nos utilisateurs</h2></div><div className="grid md:grid-cols-3 gap-6">{TESTIMONIALS_DATA.map(({ name, role, avatar, text, rating }) => <div key={name} className="bg-card rounded-2xl border border-border p-6 hover:shadow-md transition-shadow duration-200"><div className="flex items-center gap-1 mb-4">{Array.from({ length: rating }).map((_, i) => <Star key={i} className="w-4 h-4 text-amber-400 fill-amber-400" />)}</div><p className="text-sm text-muted-foreground leading-relaxed mb-5">"{text}"</p><div className="flex items-center gap-3"><div className="w-9 h-9 rounded-full bg-primary flex items-center justify-center text-white text-xs font-bold">{avatar}</div><div><div className="text-sm font-semibold text-foreground">{name}</div><div className="text-xs text-muted-foreground">{role}</div></div></div></div>)}</div></div></section>

      {/* About */}
      <section id="about" className="py-20 lg:py-28 bg-gradient-to-br from-primary/5 via-background to-accent/5">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-14"><div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-4"><Lightbulb className="w-3.5 h-3.5 text-primary" /><span className="text-xs font-semibold text-primary">À propos de nous</span></div><h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">Notre Mission</h2><p className="text-muted-foreground max-w-2xl mx-auto leading-relaxed">Démocratiser l'accès à un accompagnement pédagogique intelligent et personnalisé pour tous les étudiants universitaires.</p></div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {[{ icon: Target, title: "Centraliser l'information", description: "Regrouper cours, notes, horaires et annonces en une seule plateforme." }, { icon: Brain, title: "Personnaliser l'apprentissage", description: "Adapter les ressources pédagogiques grâce à l'IA." }, { icon: TrendingUp, title: "Améliorer les performances", description: "Analyses détaillées pour identifier les axes d'amélioration." }, { icon: Users, title: "Faciliter la gestion", description: "Outils puissants pour les administrateurs universitaires." }].map(({ icon: Icon, title, description }) => (
              <div key={title} className="bg-card rounded-2xl border border-border p-5 hover:shadow-md hover:-translate-y-1 transition-all duration-200 text-center"><div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4"><Icon className="w-5 h-5 text-primary" /></div><h4 className="text-sm font-bold text-foreground mb-2">{title}</h4><p className="text-xs text-muted-foreground leading-relaxed">{description}</p></div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="py-20 lg:py-28">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-14"><div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-accent/10 border border-accent/20 mb-4"><MessageSquare className="w-3.5 h-3.5 text-accent" /><span className="text-xs font-semibold text-accent">Contactez-nous</span></div><h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">Nous sommes à votre écoute</h2></div>
          <div className="grid lg:grid-cols-5 gap-10">
            <div className="lg:col-span-2 flex flex-col gap-5">
              {[{ icon: Phone, label: "Téléphone", value: "+213 (0) 21 123 456", sub: "Lun – Ven, 08h – 17h", style: "bg-blue-50 text-blue-600" }, { icon: Mail, label: "Email", value: "contact@aai-universite.dz", sub: "Réponse sous 24h", style: "bg-emerald-50 text-emerald-600" }, { icon: MapPin, label: "Adresse", value: "123 Rue de l'Université, Alger", sub: "Campus Central, Bât. A", style: "bg-violet-50 text-violet-600" }].map(({ icon: Icon, label, value, sub, style }) => (
                <div key={label} className="bg-card rounded-2xl border border-border p-5 flex gap-4 hover:shadow-sm transition-shadow duration-200"><div className={`w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 ${style.split(" ")[0]}`}><Icon className={`w-5 h-5 ${style.split(" ")[1]}`} /></div><div><div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-0.5">{label}</div><div className="text-sm font-semibold text-foreground">{value}</div><div className="text-xs text-muted-foreground mt-0.5">{sub}</div></div></div>
              ))}
            </div>
            <div className="lg:col-span-3 bg-card rounded-2xl border border-border p-7">
              <h3 className="text-lg font-bold text-foreground mb-6">Envoyez-nous un message</h3>
              {contactSent ? (
                <div className="flex flex-col items-center justify-center py-12 gap-4">
                  <div className="w-16 h-16 rounded-full bg-emerald-100 flex items-center justify-center"><CheckCircle className="w-8 h-8 text-emerald-600" /></div>
                  <h4 className="text-lg font-bold text-foreground">Message envoyé !</h4>
                  <p className="text-sm text-muted-foreground text-center">Notre équipe vous répondra dans les 24 heures.</p>
                  <button onClick={() => setContactSent(false)} className="text-sm text-primary font-semibold hover:underline">Envoyer un autre message</button>
                </div>
              ) : (
                <form onSubmit={(e) => { e.preventDefault(); setContactSent(true); }} className="flex flex-col gap-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div><label className="text-xs font-semibold text-foreground mb-1 block">Nom complet *</label><input required value={contactForm.name} onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })} placeholder="Amina Benali" className="w-full px-4 py-2.5 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all duration-150" /></div>
                    <div><label className="text-xs font-semibold text-foreground mb-1 block">Email *</label><input type="email" required value={contactForm.email} onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })} placeholder="amina@universite.dz" className="w-full px-4 py-2.5 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all duration-150" /></div>
                  </div>
                  <div><label className="text-xs font-semibold text-foreground mb-1 block">Sujet</label><select value={contactForm.subject} onChange={(e) => setContactForm({ ...contactForm, subject: e.target.value })} className="w-full px-4 py-2.5 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:border-primary transition-all duration-150 text-foreground"><option value="">Sélectionnez un sujet</option><option>Question générale</option><option>Demande de démo</option><option>Partenariat universitaire</option><option>Support technique</option></select></div>
                  <div><label className="text-xs font-semibold text-foreground mb-1 block">Message *</label><textarea required rows={5} value={contactForm.message} onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })} placeholder="Décrivez votre demande..." className="w-full px-4 py-2.5 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:border-primary transition-all duration-150 resize-none" /></div>
                  <button type="submit" className="flex items-center justify-center gap-2 py-3 text-sm font-semibold text-white bg-primary rounded-xl hover:bg-blue-700 transition-all duration-150 active:scale-95 shadow-sm"><Send className="w-4 h-4" />Envoyer le message</button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 lg:py-28"><div className="max-w-4xl mx-auto px-6 lg:px-8 text-center"><div className="bg-gradient-to-br from-primary to-blue-700 rounded-3xl p-10 lg:p-16 relative overflow-hidden shadow-2xl"><div className="absolute top-0 right-0 w-64 h-64 rounded-full bg-white/5 -translate-y-1/2 translate-x-1/2 pointer-events-none" /><div className="relative z-10"><div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/15 border border-white/20 mb-6"><Sparkles className="w-3.5 h-3.5 text-white" /><span className="text-xs font-semibold text-white">Rejoignez 12,000+ étudiants</span></div><h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">Prêt à transformer votre expérience universitaire ?</h2><p className="text-blue-100 mb-8 max-w-lg mx-auto leading-relaxed">Accédez gratuitement à tous vos cours, notes et à votre assistant IA. Inscription en 30 secondes.</p><div className="flex flex-wrap justify-center gap-4"><button onClick={onStart} className="flex items-center gap-2 px-7 py-3.5 text-primary font-semibold bg-white rounded-xl hover:bg-blue-50 transition-all duration-150 active:scale-95 shadow-lg">Commencer gratuitement <ArrowRight className="w-4 h-4" /></button><button onClick={onLogin} className="flex items-center gap-2 px-7 py-3.5 text-white font-semibold border-2 border-white/40 rounded-xl hover:bg-white/10 transition-all duration-150 active:scale-95">Se connecter</button></div></div></div></div></section>

      <footer className="bg-foreground text-white py-12"><div className="max-w-7xl mx-auto px-6 lg:px-8"><div className="grid md:grid-cols-4 gap-8 mb-8"><div><div className="flex items-center gap-2.5 mb-4"><div className="w-8 h-8 rounded-xl bg-white/10 flex items-center justify-center"><GraduationCap className="w-4 h-4 text-white" /></div><span className="font-bold text-white">AAI</span></div><p className="text-sm text-white/50 leading-relaxed">Plateforme universitaire intelligente propulsée par l'IA.</p></div>{[{ title: "Produit", links: ["Fonctionnalités", "Tarifs", "Sécurité", "Mises à jour"] }, { title: "Université", links: ["Étudiants", "Enseignants", "Administration", "Partenaires"] }, { title: "Support", links: ["Documentation", "Tutoriels", "Contact", "Statut"] }].map(({ title, links }) => <div key={title}><h4 className="text-sm font-semibold text-white mb-3">{title}</h4><ul className="space-y-2">{links.map((l) => <li key={l}><a href="#" className="text-sm text-white/50 hover:text-white transition-colors duration-150">{l}</a></li>)}</ul></div>)}</div><div className="border-t border-white/10 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4"><p className="text-xs text-white/40">© 2024 Assistant Académique Intelligent. Tous droits réservés.</p><div className="flex items-center gap-4">{["Confidentialité", "Conditions", "Cookies"].map((l) => <a key={l} href="#" className="text-xs text-white/40 hover:text-white/70 transition-colors duration-150">{l}</a>)}</div></div></div></footer>
    </div>
  );
}

// ── LOGIN MODAL ─────────────────────────────────────────────────────────────
function LoginModal({ open, onClose, onSuccess }: { open: boolean; onClose: () => void; onSuccess: () => void }) {
  const [showPw, setShowPw] = useState(false);
  const [form, setForm] = useState({ credential: "", password: "" });
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4" style={{ fontFamily: "'Poppins', sans-serif" }}>
      <div className="absolute inset-0 bg-foreground/50 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-card rounded-3xl border border-border shadow-2xl w-full max-w-md p-8">
        <button onClick={onClose} className="absolute top-4 right-4 w-8 h-8 rounded-full bg-muted flex items-center justify-center hover:bg-red-50 hover:text-red-500 transition-colors duration-150"><X className="w-4 h-4" /></button>
        <div className="flex flex-col items-center mb-8"><div className="w-14 h-14 rounded-2xl bg-primary flex items-center justify-center shadow-lg mb-4"><GraduationCap className="w-7 h-7 text-white" /></div><h2 className="text-xl font-bold text-foreground">Connexion</h2><p className="text-sm text-muted-foreground mt-1">Accédez à votre espace académique</p></div>
        <form onSubmit={(e) => { e.preventDefault(); onClose(); onSuccess(); }} className="flex flex-col gap-4">
          <div><label className="text-xs font-semibold text-foreground mb-1 block">Email ou Matricule</label><div className="relative"><Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" /><input type="text" required placeholder="amina@universite.dz ou 20210001" value={form.credential} onChange={(e) => setForm({ ...form, credential: e.target.value })} className="w-full pl-10 pr-4 py-3 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all duration-150" /></div></div>
          <div><div className="flex items-center justify-between"><label className="text-xs font-semibold text-foreground">Mot de passe</label><button type="button" className="text-xs text-primary font-medium hover:underline">Mot de passe oublié ?</button></div><div className="relative mt-1"><Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" /><input type={showPw ? "text" : "password"} required placeholder="••••••••" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} className="w-full pl-10 pr-11 py-3 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all duration-150" /><button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors duration-150">{showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}</button></div></div>
          <label className="flex items-center gap-2.5 cursor-pointer"><input type="checkbox" className="w-4 h-4 rounded accent-primary" /><span className="text-sm text-muted-foreground">Se souvenir de moi</span></label>
          <button type="submit" className="flex items-center justify-center gap-2 w-full py-3 text-sm font-semibold text-white bg-primary rounded-xl hover:bg-blue-700 transition-all duration-150 active:scale-95 shadow-sm mt-1"><LogIn className="w-4 h-4" />Se connecter</button>
        </form>
        <div className="flex items-center gap-3 my-5"><div className="flex-1 h-px bg-border" /><span className="text-xs text-muted-foreground">ou</span><div className="flex-1 h-px bg-border" /></div>
        <p className="text-center text-sm text-muted-foreground">Pas encore de compte ? <button className="text-primary font-semibold hover:underline" onClick={() => { onClose(); onSuccess(); }}>S'inscrire gratuitement</button></p>
        <div className="mt-4 bg-muted/60 rounded-xl p-3 flex items-start gap-2"><Shield className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" /><p className="text-xs text-muted-foreground leading-relaxed">Connexion sécurisée. Vos données sont protégées et ne seront jamais partagées sans votre consentement.</p></div>
      </div>
    </div>
  );
}

// ── MAIN APP ───────────────────────────────────────────────────────────────
export default function App() {
  const [view, setView] = useState<View>("landing");
  const [role, setRole] = useState<Role | null>(null);
  const [loginOpen, setLoginOpen] = useState(false);
  const [selectedCourse, setSelectedCourse] = useState<number>(1);
  const [notifs, setNotifs] = useState<Notif[]>(INIT_NOTIFS);
  const [logoutConfirm, setLogoutConfirm] = useState(false);

  useEffect(() => { if (loginOpen) document.body.style.overflow = "hidden"; else document.body.style.overflow = ""; return () => { document.body.style.overflow = ""; }; }, [loginOpen]);

  const handleLogout = () => setLogoutConfirm(true);
  const confirmLogout = () => { setLogoutConfirm(false); setRole(null); setView("landing"); };

  if (view !== "landing" && view !== "profile-select" && role) {
    const isChat = view === "s-ai-chat";
    const renderScreen = () => {
      switch (view) {
        case "s-dashboard": return <StudentDashboard setView={setView} />;
        case "s-courses": return <StudentCourses setView={setView} setSelectedCourse={setSelectedCourse} />;
        case "s-course-detail": return <StudentCourseDetail courseId={selectedCourse} setView={setView} />;
        case "s-grades": return <StudentGrades />;
        case "s-retake": return <StudentRetake setView={setView} />;
        case "s-schedule": return <StudentSchedule />;
        case "s-announcements": return <StudentAnnouncements />;
        case "s-profile": return <StudentProfile />;
        case "s-ai-chat": return <StudentAIChat />;
        case "s-ai-history": return <StudentAIHistory />;
        case "s-settings": return <StudentSettings />;
        case "a-dashboard": return <AdminDashboard />;
        case "a-students": return <AdminStudents />;
        case "a-registrations": return <AdminRegistrations />;
        case "a-courses": return <AdminCourses />;
        case "a-grades": return <AdminGrades />;
        case "a-announcements": return <AdminAnnouncements />;
        case "a-users": return <AdminUsers />;
        case "a-statistics": return <AdminStatistics />;
        case "a-activity": return <AdminActivity />;
        case "a-settings": return <AdminSettings />;
        default: return null;
      }
    };
    return (
      <>
        <AppLayout role={role} view={view} setView={setView} isChat={isChat} notifs={notifs} setNotifs={setNotifs} onLogout={handleLogout}>
          {renderScreen()}
        </AppLayout>
        <ConfirmModal open={logoutConfirm} onClose={() => setLogoutConfirm(false)} onConfirm={confirmLogout} title="Se déconnecter ?" message="Vous allez être redirigé vers la page d'accueil. Votre session sera terminée." confirmLabel="Déconnexion" variant="warning" />
      </>
    );
  }

  if (view === "profile-select") return <ProfileSelect setView={setView} setRole={setRole} />;

  return (
    <div style={{ fontFamily: "'Poppins', sans-serif" }}>
      <LandingPage onLogin={() => setLoginOpen(true)} onStart={() => setLoginOpen(true)} />
      <LoginModal open={loginOpen} onClose={() => setLoginOpen(false)} onSuccess={() => { setLoginOpen(false); setView("profile-select"); }} />
    </div>
  );
}

from sqlalchemy.orm import Session
from app import models, schemas
from app.security import get_password_hash

# --- CRUD Utilisateurs ---
def create_utilisateur(db: Session, user: schemas.UtilisateurCreate):
    db_user = models.Utilisateur(
        nom=user.nom,
        prenom=user.prenom,
        email=user.email,
        mot_de_passe_hash=get_password_hash(user.mot_de_passe),
        role=user.role,
        promotion=user.promotion,
        faculte=user.faculte,
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user


def get_utilisateurs(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.Utilisateur).offset(skip).limit(limit).all()


# --- CRUD Étudiant / Professeur / Administration ---
def create_etudiant(db: Session, etudiant: schemas.EtudiantCreate):
    db_etudiant = models.Etudiant(**etudiant.model_dump())
    db.add(db_etudiant)
    db.commit()
    db.refresh(db_etudiant)
    return db_etudiant


def create_professeur(db: Session, professeur: schemas.ProfesseurCreate):
    db_professeur = models.Professeur(**professeur.model_dump())
    db.add(db_professeur)
    db.commit()
    db.refresh(db_professeur)
    return db_professeur


def create_administration(db: Session, admin: schemas.AdministrationCreate):
    db_admin = models.Administration(**admin.model_dump())
    db.add(db_admin)
    db.commit()
    db.refresh(db_admin)
    return db_admin


# --- CRUD Cours ---
def create_cours(db: Session, cours: schemas.CoursCreate):
    db_cours = models.Cours(**cours.model_dump())
    db.add(db_cours)
    db.commit()
    db.refresh(db_cours)
    return db_cours


def get_cours(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.Cours).offset(skip).limit(limit).all()


# --- CRUD Documents ---
def create_document(db: Session, doc: schemas.DocumentCreate):
    db_doc = models.Document(**doc.model_dump())
    db.add(db_doc)
    db.commit()
    db.refresh(db_doc)
    return db_doc


def get_documents(db: Session):
    return db.query(models.Document).all()


# --- CRUD Quiz / Questions ---
def create_quiz(db: Session, quiz: schemas.QuizCreate):
    db_quiz = models.Quiz(**quiz.model_dump())
    db.add(db_quiz)
    db.commit()
    db.refresh(db_quiz)
    return db_quiz


def add_question(db: Session, quiz_id: int, question: schemas.QuestionCreate):
    db_question = models.Question(quiz_id=quiz_id, **question.model_dump())
    db.add(db_question)
    db.commit()
    db.refresh(db_question)
    return db_question


# --- CRUD Résultats ---
def create_resultat(db: Session, resultat: schemas.ResultatCreate):
    db_resultat = models.Resultat(**resultat.model_dump())
    db.add(db_resultat)
    db.commit()
    db.refresh(db_resultat)
    return db_resultat


# --- CRUD Recommandations ---
def create_recommandation(db: Session, recomm: schemas.RecommandationCreate):
    db_recommandation = models.Recommandation(**recomm.model_dump())
    db.add(db_recommandation)
    db.commit()
    db.refresh(db_recommandation)
    return db_recommandation


# --- CRUD Conversations & Messages ---
def create_conversation(db: Session, user_id: int, conv: schemas.ConversationCreate):
    db_conv = models.Conversation(utilisateur_id=user_id, titre=conv.titre)
    db.add(db_conv)
    db.commit()
    db.refresh(db_conv)
    return db_conv


def add_message(db: Session, conv_id: int, msg: schemas.MessageCreate):
    db_msg = models.Message(conversation_id=conv_id, **msg.model_dump())
    db.add(db_msg)
    db.commit()
    db.refresh(db_msg)
    return db_msg



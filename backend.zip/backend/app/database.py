import os

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from dotenv import load_dotenv


# Charger les variables du fichier .env
load_dotenv()

# Récupérer l'URL de la base de données
# Si aucune variable n'est définie, on utilise SQLite pour le développement local.
DATABASE_URL = os.getenv("DATABASE_URL")

# Créer le moteur SQLAlchemy.
engine = create_engine(DATABASE_URL)

# Créer une session locale de travail avec la DB
SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine
)

# Classe de base pour les modèles SQLAlchemy. Tous les modèles doivent hériter de cette classe.
Base = declarative_base()
# fonction dependance pour recuperer la session DB dans les retours FastAPI...permet d'ouvrir et fermer la session automatiquement
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

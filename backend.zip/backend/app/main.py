# Point d'entrée principal de l'application FastAPI.
# Il centralise les informations de base et branche les différents modules de routes.

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
#from app import models
from app.database import engine, Base   
from app.routers import (
    health,
    utilisateurs,
    documents,
    chat,
    auth,
    cours,
    quiz,
    administration,
    etudiants,
    professeurs,
    resultats,
    recommandations,
)

app = FastAPI(
    title="HelpStudy AI API",
    description="API d'assistance académique intelligente pour l'université",
    version="1.0.0"
)
# CONFIGURATION DU CORS POUR LE FRONTEND REACT 
origins = [
    "http://localhost:5173",    # Port par défaut de Vite
    "http://127.0.0.1:5173",  # Alternative courante
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,       # Autorise ces origines
    allow_credentials=True,      # Autorise l'envoi de cookies/tokens
    allow_methods=["*"],         # Autorise toutes les méthodes (GET, POST, PUT, DELETE...)
    allow_headers=["*"],         # Autorise tous les entêtes HTTP
)

# Cette fonction est appelée au démarrage du serveur.
# Elle crée automatiquement les tables définies dans les modèles SQLAlchemy.
@app.on_event("startup")
def startup_event():
    Base.metadata.create_all(bind=engine)

# On enregistre ici chaque fichier de route du projet.

app.include_router(health.router)
app.include_router(utilisateurs.router)
app.include_router(documents.router)
app.include_router(chat.router)
app.include_router(auth.router)
app.include_router(cours.router)
app.include_router(quiz.router)
app.include_router(administration.router)
app.include_router(etudiants.router)
app.include_router(professeurs.router)
app.include_router(resultats.router)
app.include_router(recommandations.router)
from sqlalchemy import Column, Integer, String, Text, ForeignKey, DateTime, Float
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from pgvector.sqlalchemy import Vector
from app.database import Base

#Entites et relations pour l'application HelpStudy AI
class Utilisateur(Base):
    __tablename__ = "utilisateurs"

    id = Column(Integer, primary_key=True, index=True)
    nom = Column(String(50), nullable=False)
    prenom = Column(String(50), nullable=False)
    email = Column(String(100), unique=True, index=True, nullable=False)
    mot_de_passe_hash = Column(Text, nullable=False)
    role = Column(String(20), nullable=False, default="etudiant")
    promotion = Column(String(50), nullable=True)
    faculte = Column(String(100), nullable=True)
    date_creation = Column(DateTime(timezone=True), server_default=func.now())

    etudiant = relationship("Etudiant", back_populates="utilisateur", uselist=False, cascade="all, delete-orphan")
    professeur = relationship("Professeur", back_populates="utilisateur", uselist=False, cascade="all, delete-orphan")
    administration = relationship("Administration", back_populates="utilisateur", uselist=False, cascade="all, delete-orphan")
    conversations = relationship("Conversation", back_populates="utilisateur", cascade="all, delete-orphan")
    evenements = relationship("Evenement", back_populates="utilisateur", cascade="all, delete-orphan")
    recommandations = relationship("Recommandation", back_populates="utilisateur", cascade="all, delete-orphan")


class Etudiant(Base):
    __tablename__ = "etudiants"

    id = Column(Integer, primary_key=True, index=True)
    utilisateur_id = Column(Integer, ForeignKey("utilisateurs.id", ondelete="CASCADE"), nullable=False, unique=True)
    promotion = Column(String(50), nullable=True)
    niveau = Column(String(50), nullable=True)
    filiere = Column(String(100), nullable=True)

    utilisateur = relationship("Utilisateur", back_populates="etudiant")
    resultats = relationship("Resultat", back_populates="etudiant", cascade="all, delete-orphan")


class Professeur(Base):
    __tablename__ = "professeurs"

    id = Column(Integer, primary_key=True, index=True)
    utilisateur_id = Column(Integer, ForeignKey("utilisateurs.id", ondelete="CASCADE"), nullable=False, unique=True)
    specialite = Column(String(100), nullable=True)
    departement = Column(String(100), nullable=True)

    utilisateur = relationship("Utilisateur", back_populates="professeur")
    cours = relationship("Cours", back_populates="professeur", cascade="all, delete-orphan")
    documents = relationship("Document", back_populates="professeur", cascade="all, delete-orphan")


class Administration(Base):
    __tablename__ = "administrations"

    id = Column(Integer, primary_key=True, index=True)
    utilisateur_id = Column(Integer, ForeignKey("utilisateurs.id", ondelete="CASCADE"), nullable=False, unique=True)
    service = Column(String(100), nullable=True)
    poste = Column(String(100), nullable=True)

    utilisateur = relationship("Utilisateur", back_populates="administration")


class Cours(Base):
    __tablename__ = "cours"

    id = Column(Integer, primary_key=True, index=True)
    titre = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    credits = Column(Integer, default=0)
    professeur_id = Column(Integer, ForeignKey("professeurs.id", ondelete="SET NULL"), nullable=True)

    professeur = relationship("Professeur", back_populates="cours")
    documents = relationship("Document", back_populates="cours", cascade="all, delete-orphan")
    quizs = relationship("Quiz", back_populates="cours", cascade="all, delete-orphan")


class Document(Base):
    __tablename__ = "documents"

    id = Column(Integer, primary_key=True, index=True)
    titre = Column(String(255), nullable=False)
    categorie = Column(String(100), nullable=False)
    chemin_fichier_url = Column(Text, nullable=False)
    contenu_texte = Column(Text, nullable=True)
    embedding = Column(Text, nullable=True)
    cours_id = Column(Integer, ForeignKey("cours.id", ondelete="SET NULL"), nullable=True)
    professeur_id = Column(Integer, ForeignKey("professeurs.id", ondelete="SET NULL"), nullable=True)
    date_versement = Column(DateTime(timezone=True), server_default=func.now())

    cours = relationship("Cours", back_populates="documents")
    professeur = relationship("Professeur", back_populates="documents")

    chunks = relationship("DocumentChunk", back_populates="document", cascade="all, delete-orphan")

class DocumentChunk(Base):
    __tablename__ = "document_chunks"

    id = Column(Integer, primary_key=True, index=True)

    document_id = Column(
        Integer,
        ForeignKey("documents.id", ondelete="CASCADE"),
        nullable=False,
        index=True
    )

    contenu = Column(Text, nullable=False)
    chunk_index = Column(Integer, nullable=False)
    page_number = Column(Integer, nullable=True)
    embedding = Column(Vector(384), nullable=False)
    document = relationship(
        "Document",
        back_populates="chunks"
    )

class Quiz(Base):
    __tablename__ = "quizs"

    id = Column(Integer, primary_key=True, index=True)
    titre = Column(String(255), nullable=False)
    cours_id = Column(Integer, ForeignKey("cours.id", ondelete="CASCADE"), nullable=False)
    professeur_id = Column(Integer, ForeignKey("professeurs.id", ondelete="SET NULL"), nullable=True)

    cours = relationship("Cours", back_populates="quizs")
    questions = relationship("Question", back_populates="quiz", cascade="all, delete-orphan")
    resultats = relationship("Resultat", back_populates="quiz", cascade="all, delete-orphan")


class Question(Base):
    __tablename__ = "questions"

    id = Column(Integer, primary_key=True, index=True)
    quiz_id = Column(Integer, ForeignKey("quizs.id", ondelete="CASCADE"), nullable=False)
    libelle = Column(Text, nullable=False)
    reponse_correcte = Column(Text, nullable=False)

    quiz = relationship("Quiz", back_populates="questions")


class Resultat(Base):
    __tablename__ = "resultats"

    id = Column(Integer, primary_key=True, index=True)
    etudiant_id = Column(Integer, ForeignKey("etudiants.id", ondelete="CASCADE"), nullable=False)
    quiz_id = Column(Integer, ForeignKey("quizs.id", ondelete="CASCADE"), nullable=False)
    score = Column(Float, nullable=False, default=0)
    date_resultat = Column(DateTime(timezone=True), server_default=func.now())

    etudiant = relationship("Etudiant", back_populates="resultats")
    quiz = relationship("Quiz", back_populates="resultats")


class Recommandation(Base):
    __tablename__ = "recommandations"

    id = Column(Integer, primary_key=True, index=True)
    utilisateur_id = Column(Integer, ForeignKey("utilisateurs.id", ondelete="CASCADE"), nullable=False)
    contenu = Column(Text, nullable=False)
    type_recommandation = Column(String(50), nullable=True, default="generale")
    date_generation = Column(DateTime(timezone=True), server_default=func.now())

    utilisateur = relationship("Utilisateur", back_populates="recommandations")


class Conversation(Base):
    __tablename__ = "conversations"

    id = Column(Integer, primary_key=True, index=True)
    utilisateur_id = Column(Integer, ForeignKey("utilisateurs.id", ondelete="CASCADE"), nullable=False)
    titre = Column(String(150), default="Nouvelle discussion")
    date_creation = Column(DateTime(timezone=True), server_default=func.now())

    utilisateur = relationship("Utilisateur", back_populates="conversations")
    messages = relationship("Message", back_populates="conversation", cascade="all, delete-orphan")


class Message(Base):
    __tablename__ = "messages"

    id = Column(Integer, primary_key=True, index=True)
    conversation_id = Column(Integer, ForeignKey("conversations.id", ondelete="CASCADE"), nullable=False)
    role_expediteur = Column(String(10), nullable=False)
    contenu = Column(Text, nullable=False)
    date_envoi = Column(DateTime(timezone=True), server_default=func.now())

    conversation = relationship("Conversation", back_populates="messages")


class Evenement(Base):
    __tablename__ = "evenements"

    id = Column(Integer, primary_key=True, index=True)
    utilisateur_id = Column(Integer, ForeignKey("utilisateurs.id", ondelete="CASCADE"), nullable=False)
    titre = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    date_debut = Column(DateTime, nullable=False)
    date_fin = Column(DateTime, nullable=True)
    statut = Column(String(20), default="A faire")

    utilisateur = relationship("Utilisateur", back_populates="evenements")


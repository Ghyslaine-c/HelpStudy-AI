#Fichier de routes pour le module administration.
#Il contient les endpoints utiles au suivi académique et au dashboard de gestion.

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app import schemas, crud

router = APIRouter(
    prefix="/administration",
    tags=["Administration"]
)

#l'endpoint pour créer un profil d'administration
@router.post(
    "/profil/",
    response_model=schemas.AdministrationResponse,
    summary="Créer le profil d'un membre de l'administration"
)
def reponse_creer_administration(
    admin: schemas.AdministrationCreate,
    db: Session = Depends(get_db)
):
    return crud.create_administration(db=db, admin=admin)

#lister les profils d'administration
@router.get(
    "/dashboard",
    summary="Aperçu général du tableau de bord administratif"
)
def dashboard_admin(
    db: Session = Depends(get_db)
):
    # Ce tableau de bord est volontairement simple pour le démarrage.
    # On compte les utilisateurs, les étudiants et les cours.
    total_utilisateurs = db.query(crud.models.Utilisateur).count()
    total_etudiants = db.query(crud.models.Etudiant).count()
    total_cours = db.query(crud.models.Cours).count()
    total_quiz = db.query(crud.models.Quiz).count()

    return {
        "total_utilisateurs": total_utilisateurs,
        "total_etudiants": total_etudiants,
        "total_cours": total_cours,
        "total_quiz": total_quiz,
        "message": "Dashboard administratif opérationnel"
    }

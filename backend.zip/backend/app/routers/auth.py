#Fichier de routes pour l'authentification des utilisateurs.
#Il centralise les endpoints d'inscription, de connexion et de sécurité.
#La sécurisation passe par le hashage des mots de passe et la génération de JWT.

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database import get_db
from app import schemas, crud, models
from app.security import create_access_token, verify_password, get_current_user

# Router dédié à l'authentification.
router = APIRouter(
    prefix="/auth",
    tags=["Authentification"]
)

#importation des fonctions de sécurité pour le hashage et la vérification des mots de passe, ainsi que pour la création de tokens JWT.
@router.post(
    "/register",
    response_model=schemas.UtilisateurResponse,
    summary="Créer un compte utilisateur"
)
def register_user(
    user: schemas.UtilisateurCreate,
    db: Session = Depends(get_db)
):
    # On vérifie s'il existe déjà un compte avec cet email.
    existing_user = db.query(models.Utilisateur).filter_by(email=user.email).first()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Un utilisateur avec cet email existe déjà."
        )

    # La création passe par le CRUD, qui applique maintenant le hashage sécurisé.
    return crud.create_utilisateur(db=db, user=user)

# Endpoint pour la connexion d'un utilisateur et la génération d'un token JWT.
@router.post(
    "/login",
    response_model=schemas.Token,
    summary="Connexion d'un utilisateur et génération d'un jeton JWT"
)
def login_user(
    login_data: schemas.LoginRequest,
    db: Session = Depends(get_db)
):
    # On recherche l'utilisateur par son email.
    db_user = db.query(models.Utilisateur).filter_by(email=login_data.email).first()

    if not db_user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Utilisateur introuvable."
        )

    # Vérification du mot de passe avec le hash enregistré.
    if not verify_password(login_data.password, db_user.mot_de_passe_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Mot de passe incorrect."
        )

    # Génération du JWT qui servira pour les routes protégées.
    access_token = create_access_token({
        "sub": db_user.email,
        "role": db_user.role,
    })

    return {
        "access_token": access_token,
        "token_type": "bearer"
    }

@router.get(
    "/me",
    response_model=schemas.UtilisateurResponse,
    summary="Récupérer les informations de l'utilisateur connecté"
)
def get_me(current_user: models.Utilisateur = Depends(get_current_user)):
    return current_user
#--ENDPOINT DE CONVERSATION ET DE MESSAGES---

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app import schemas, crud


router = APIRouter(
    tags=["Chat"]
)

#implementation de l'endpoint pour créer une nouvelle conversation pour un utilisateur donné
@router.post(
    "/utilisateurs/{user_id}/conversations/",
    response_model=schemas.ConversationResponse
)
def reponse_creer_conversation(
    user_id: int,
    conv: schemas.ConversationCreate,
    db: Session = Depends(get_db)
):
    return crud.create_conversation(
        db=db,
        user_id=user_id,
        conv=conv
    )

#implementation de l'endpoint pour lister les conversations d'un utilisateur donné
@router.post(
    "/conversations/{conv_id}/messages/",
    response_model=schemas.MessageResponse
)
def reponse_ajouter_message(
    conv_id: int,
    msg: schemas.MessageCreate,
    db: Session = Depends(get_db)
):
    return crud.add_message(
        db=db,
        conv_id=conv_id,
        msg=msg
    )
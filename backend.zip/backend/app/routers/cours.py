#Fichier de routes pour la gestion des cours.
#Il expose les endpoints permettant d'ajouter et de lister les cours.
#Les routes sont protégées par JWT et des règles de rôle.

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.database import get_db
from app import schemas, crud, models
from app.security import get_current_user

router = APIRouter(
    prefix="/cours",
    tags=["Cours"]
)

#endpoint pour créer un cours
@router.post(
    "/",
    response_model=schemas.CoursResponse,
    summary="Créer un cours"
)
def reponse_creer_cours(
    cours: schemas.CoursCreate,
    db: Session = Depends(get_db),
    current_user: models.Utilisateur = Depends(get_current_user)
):
    # Seuls les professeurs et les administrateurs peuvent publier un cours.
    if current_user.role not in ["professeur", "admin"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Vous n'êtes pas autorisé à créer un cours."
        )

    return crud.create_cours(db=db, cours=cours)

#lister les cours avec pagination
@router.get(
    "/",
    response_model=List[schemas.CoursResponse],
    summary="Lister les cours"
)
def reponse_lire_cours(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: models.Utilisateur = Depends(get_current_user)
):
    # Les étudiants et les professeurs peuvent consulter les cours.
    if current_user.role not in ["etudiant", "professeur", "admin"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Accès refusé."
        )

    return crud.get_cours(db=db, skip=skip, limit=limit)

#--- CREATION ET LECTURE DE DOCUMENTS---

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List

from app.database import get_db
from app import schemas, crud

router = APIRouter(
    prefix="/documents",
    tags=["Documents"]
)

#création d'un nouveau document
@router.post(
    "/",
    response_model=schemas.DocumentResponse
)
def reponse_ajouter_document(
    doc: schemas.DocumentCreate,
    db: Session = Depends(get_db)
):
    return crud.create_document(
        db=db,
        doc=doc
    )

#lister tous les documents
@router.get(
    "/",
    response_model=List[schemas.DocumentResponse]
)
def reponse_liste_documents(
    db: Session = Depends(get_db)
):
    return crud.get_documents(
        db=db
    )
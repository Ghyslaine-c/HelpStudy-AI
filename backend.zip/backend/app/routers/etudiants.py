#Fichier de routes pour le profil étudiant.

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.database import get_db
from app import schemas, crud, models
from app.security import get_current_user

#création d'un routeur FastAPI pour les endpoints liés aux étudiants
router = APIRouter(
    prefix="/etudiants",
    tags=["Étudiants"]
)

#création d'un profil étudiant
@router.post(
    "/",
    response_model=schemas.EtudiantResponse,
    summary="Créer le profil d'un étudiant"
)
def create_etudiant_profile(
    etudiant: schemas.EtudiantCreate,
    db: Session = Depends(get_db),
    current_user: models.Utilisateur = Depends(get_current_user)
):
    # L'utilisateur connecté doit avoir le rôle étudiant ou admin.
    if current_user.role not in ["etudiant", "admin"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Vous n'êtes pas autorisé à créer ce profil."
        )

    return crud.create_etudiant(db=db, etudiant=etudiant)

#lister les profils étudiants
@router.get(
    "/",
    response_model=List[schemas.EtudiantResponse],
    summary="Lister les profils étudiants"
)
def list_etudiants(
    db: Session = Depends(get_db),
    current_user: models.Utilisateur = Depends(get_current_user)
):
    # Un étudiant ne voit pas forcément tous les profils. En version simple, on autorise admin.
    if current_user.role != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Accès refusé."
        )

    return db.query(models.Etudiant).all()

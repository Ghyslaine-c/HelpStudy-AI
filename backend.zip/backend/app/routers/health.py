#ACCUEIL ET TEST DE CONNEXION A LA BASE DE DONNEES

from fastapi import APIRouter
from sqlalchemy import text

from app.database import engine

# creation d'un router pour les endpoints de santé de l'API
router = APIRouter(
    tags=["Santé"]
)

#endpoint pour vérifier si le serveur est opérationnel
@router.get("/")
def accueil():
    return {
        "message": "Bienvenue sur HelpStudy AI API",
        "status": "Serveur opérationnel"
    }
#endpoint pour tester la connexion à la base de données PostgreSQL
@router.get("/test-db")
def test_db():
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))

        return {
            "message": "Connexion PostgreSQL réussie"
        }

    except Exception as e:
        return {
            "erreur": str(e)
        }
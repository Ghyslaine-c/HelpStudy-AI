#Fichier de routes pour le profil professeur.

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.database import get_db
from app import schemas, crud, models
from app.security import get_current_user

router = APIRouter(
    prefix="/professeurs",
    tags=["Professeurs"]
)

#création d'un profil professeur
@router.post(
    "/",
    response_model=schemas.ProfesseurResponse,
    summary="Créer le profil d'un professeur"
)
def create_professeur_profile(
    professeur: schemas.ProfesseurCreate,
    db: Session = Depends(get_db),
    current_user: models.Utilisateur = Depends(get_current_user)
):
    if current_user.role not in ["professeur", "admin"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Vous n'êtes pas autorisé à créer ce profil."
        )

    return crud.create_professeur(db=db, professeur=professeur)

#lister les profils professeurs
@router.get(
    "/",
    response_model=List[schemas.ProfesseurResponse],
    summary="Lister les profils professeurs"
)
def list_professeurs(
    db: Session = Depends(get_db),
    current_user: models.Utilisateur = Depends(get_current_user)
):
    if current_user.role != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Accès refusé."
        )

    return db.query(models.Professeur).all()

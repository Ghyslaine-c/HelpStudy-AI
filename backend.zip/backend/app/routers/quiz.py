#Fichier de routes pour les quiz et les questions associées.
#Il regroupe les endpoints de création de quiz et d'ajout de questions.
#Les quiz sont des éléments pédagogiques : leur création est réservée aux professeurs.

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.database import get_db
from app import schemas, crud, models
from app.security import get_current_user

#création d'un routeur FastAPI pour les endpoints liés aux quiz
router = APIRouter(
    prefix="/quizs",
    tags=["Quiz"]
)

#endpoint pour créer un quiz
@router.post(
    "/",
    response_model=schemas.QuizResponse,
    summary="Créer un quiz"
)
def reponse_creer_quiz(
    quiz: schemas.QuizCreate,
    db: Session = Depends(get_db),
    current_user: models.Utilisateur = Depends(get_current_user)
):
    if current_user.role not in ["professeur", "admin"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Vous n'êtes pas autorisé à créer un quiz."
        )

    return crud.create_quiz(db=db, quiz=quiz)

#endpoint pour ajouter une question à un quiz existant
@router.post(
    "/{quiz_id}/questions/",
    response_model=schemas.QuestionResponse,
    summary="Ajouter une question à un quiz"
)
def reponse_ajouter_question(
    quiz_id: int,
    question: schemas.QuestionCreate,
    db: Session = Depends(get_db),
    current_user: models.Utilisateur = Depends(get_current_user)
):
    if current_user.role not in ["professeur", "admin"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Vous n'êtes pas autorisé à modifier ce quiz."
        )

    return crud.add_question(db=db, quiz_id=quiz_id, question=question)

#endpoint pour lister les questions d'un quiz donné
@router.get(
    "/{quiz_id}/questions/",
    response_model=List[schemas.QuestionResponse],
    summary="Lister les questions d'un quiz"
)
def reponse_lire_questions(
    quiz_id: int,
    db: Session = Depends(get_db),
    current_user: models.Utilisateur = Depends(get_current_user)
):
    if current_user.role not in ["etudiant", "professeur", "admin"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Accès refusé."
        )

    quiz = db.query(crud.models.Quiz).filter_by(id=quiz_id).first()
    if not quiz:
        return []
    return quiz.questions

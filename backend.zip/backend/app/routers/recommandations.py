#Fichier de routes pour les recommandations académiques.

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.database import get_db
from app import schemas, crud, models
from app.security import get_current_user

router = APIRouter(
    prefix="/recommandations",
    tags=["Recommandations"]
)

#création d'une recommandation
@router.post(
    "/",
    response_model=schemas.RecommandationResponse,
    summary="Créer une recommandation"
)
def creer_recommandation(
    recommandation: schemas.RecommandationCreate,
    db: Session = Depends(get_db),
    current_user: models.Utilisateur = Depends(get_current_user)
):
    if current_user.role not in ["professeur", "admin", "etudiant"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Accès refusé."
        )

    return crud.create_recommandation(db=db, recomm=recommandation)

#endpoint pour lister les recommandations
@router.get(
    "/",
    response_model=List[schemas.RecommandationResponse],
    summary="Lister les recommandations"
)
def lister_recommandations(
    db: Session = Depends(get_db),
    current_user: models.Utilisateur = Depends(get_current_user)
):
    if current_user.role not in ["professeur", "admin", "etudiant"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Accès refusé."
        )

    return db.query(models.Recommandation).all()

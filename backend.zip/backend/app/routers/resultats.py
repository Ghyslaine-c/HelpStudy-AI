#Fichier de routes pour les résultats académiques.

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.database import get_db
from app import schemas, crud, models
from app.security import get_current_user

router = APIRouter(
    prefix="/resultats",
    tags=["Résultats"]
)

#création d'un résultat de quiz
@router.post(
    "/",
    response_model=schemas.ResultatResponse,
    summary="Enregistrer un résultat de quiz"
)
def creer_resultat(
    resultat: schemas.ResultatCreate,
    db: Session = Depends(get_db),
    current_user: models.Utilisateur = Depends(get_current_user)
):
    if current_user.role not in ["professeur", "admin", "etudiant"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Accès refusé."
        )

    return crud.create_resultat(db=db, resultat=resultat)

#endpoint pour lister les résultats de quiz
@router.get(
    "/",
    response_model=List[schemas.ResultatResponse],
    summary="Lister les résultats"
)
def lister_resultats(
    db: Session = Depends(get_db),
    current_user: models.Utilisateur = Depends(get_current_user)
):
    if current_user.role not in ["professeur", "admin", "etudiant"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Accès refusé."
        )

    return db.query(models.Resultat).all()

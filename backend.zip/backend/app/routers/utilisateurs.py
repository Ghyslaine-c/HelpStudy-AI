#CREATION ET LECTURE DES UTILISATEURS---

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List

from app.database import get_db
from app import schemas, crud

router = APIRouter(
    prefix="/utilisateurs",     #tous les endpoints de ce router auront le prefixe /utilisateurs
    tags=["Utilisateurs"]       #groupe les routes de cette categorie utilisateurs dans la documentation Swagger UI
)

#creation d'un nouvel utilisateur
@router.post(
    "/",
    response_model=schemas.UtilisateurResponse
)
def reponse_creer_utilisateur(
    user: schemas.UtilisateurCreate,
    db: Session = Depends(get_db)
):
    return crud.create_utilisateur(
        db=db,
        user=user
    )

#lister tous les utilisateurs avec pagination
@router.get(
    "/",
    response_model=List[schemas.UtilisateurResponse]
)
def reponse_lire_utilisateurs(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    return crud.get_utilisateurs(
        db=db,
        skip=skip,
        limit=limit
    )
from pydantic import BaseModel, EmailStr
from datetime import datetime
from typing import Optional, List

#--schemas Pydantic correspondant aux models de la base de données pour l'application HelpStudy AI---
class UtilisateurBase(BaseModel):
    nom: str
    prenom: str
    email: str
    role: Optional[str] = "etudiant"
    promotion: Optional[str] = None
    faculte: Optional[str] = None


class UtilisateurCreate(UtilisateurBase):
    mot_de_passe: str

#schema de réponse pour l'utilisateur, incluant l'ID et la date de création
class UtilisateurResponse(UtilisateurBase):
    id: int
    date_creation: datetime

    class Config:
        from_attributes = True


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class TokenData(BaseModel):
    email: Optional[str] = None
    role: Optional[str] = None


class EtudiantCreate(BaseModel):
    utilisateur_id: int
    promotion: Optional[str] = None
    niveau: Optional[str] = None
    filiere: Optional[str] = None


class EtudiantResponse(EtudiantCreate):
    id: int

    class Config:
        from_attributes = True


class ProfesseurCreate(BaseModel):
    utilisateur_id: int
    specialite: Optional[str] = None
    departement: Optional[str] = None


class ProfesseurResponse(ProfesseurCreate):
    id: int

    class Config:
        from_attributes = True


class AdministrationCreate(BaseModel):
    utilisateur_id: int
    service: Optional[str] = None
    poste: Optional[str] = None


class AdministrationResponse(AdministrationCreate):
    id: int

    class Config:
        from_attributes = True


class CoursCreate(BaseModel):
    titre: str
    description: Optional[str] = None
    credits: int = 0
    professeur_id: Optional[int] = None


class CoursResponse(CoursCreate):
    id: int

    class Config:
        from_attributes = True


class DocumentCreate(BaseModel):
    titre: str
    categorie: str
    chemin_fichier_url: str
    contenu_texte: Optional[str] = None
    cours_id: Optional[int] = None
    professeur_id: Optional[int] = None


class DocumentResponse(DocumentCreate):
    id: int
    date_versement: datetime

    class Config:
        from_attributes = True


class QuestionCreate(BaseModel):
    libelle: str
    reponse_correcte: str


class QuestionResponse(QuestionCreate):
    id: int
    quiz_id: int

    class Config:
        from_attributes = True


class QuizCreate(BaseModel):
    titre: str
    cours_id: int
    professeur_id: Optional[int] = None


class QuizResponse(QuizCreate):
    id: int
    questions: List[QuestionResponse] = []

    class Config:
        from_attributes = True


class ResultatCreate(BaseModel):
    etudiant_id: int
    quiz_id: int
    score: float


class ResultatResponse(ResultatCreate):
    id: int
    date_resultat: datetime

    class Config:
        from_attributes = True


class RecommandationCreate(BaseModel):
    utilisateur_id: int
    contenu: str
    type_recommandation: Optional[str] = "generale"


class RecommandationResponse(RecommandationCreate):
    id: int
    date_generation: datetime

    class Config:
        from_attributes = True


class MessageCreate(BaseModel):
    role_expediteur: str
    contenu: str


class MessageResponse(MessageCreate):
    id: int
    date_envoi: datetime

    class Config:
        from_attributes = True


class ConversationCreate(BaseModel):
    titre: Optional[str] = "Nouvelle discussion"


class ConversationResponse(BaseModel):
    id: int
    utilisateur_id: int
    titre: str
    date_creation: datetime
    messages: List[MessageResponse] = []

    class Config:
        from_attributes = True


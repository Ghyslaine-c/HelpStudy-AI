#Ce fichier centralise toute la logique de sécurité.
#Il contient le hashage du mot de passe et la création/validation des JWT.

from datetime import datetime, timedelta
from typing import Any, Dict, Optional

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from passlib.context import CryptContext
from sqlalchemy.orm import Session

from app.database import get_db
from app import models

# Clef secrète utilisée pour signer les JWT.
# Dans un vrai projet, on met cette clé dans les variables d'environnement.
SECRET_KEY = "helpstudy-secret-key-change-in-production"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60

# Outil de hashage des mots de passe.
# On utilise pbkdf2_sha256 pour éviter l'incompatibilité de bcrypt avec certains
# environnements Python 3.13 / passlib, tout en conservant un hash sécurisé.
pwd_context = CryptContext(schemes=["pbkdf2_sha256"], deprecated="auto")

# OAuth2PasswordBearer permet de lire le token dans le header Authorization.
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")

#fonction pour vérifier le mot de passe en clair avec le hash stocké dans la base de données.
def verify_password(plain_password: str, hashed_password: str) -> bool:
    # Vérifie si le mot de passe en clair correspond au hash stocké.
    return pwd_context.verify(plain_password, hashed_password)

#fonction pour hasher le mot de passe avant de le stocker dans la base de données.
def get_password_hash(password: str) -> str:
    # Transforme le mot de passe en hash sécurisé.
    return pwd_context.hash(password)

#fonction pour créer un token JWT pour un utilisateur donné.
def create_access_token(data: Dict[str, Any], expires_delta: Optional[timedelta] = None) -> str:
    # Crée un JWT avec les informations utilisateur.
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

#fonction pour récupérer l'utilisateur courant à partir du token JWT... bloque l'acces si l'utilisateur n'est pas authentifié.
def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    # Décode et vérifie le token JWT.
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Token invalide ou expiré",
        headers={"WWW-Authenticate": "Bearer"},
    )

    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email: Optional[str] = payload.get("sub")
        if email is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception

    user = db.query(models.Utilisateur).filter(models.Utilisateur.email == email).first()
    if user is None:
        raise credentials_exception

    return user

#fonction pour vérifier que l'utilisateur courant est un administrateur.
def get_current_admin(current_user: models.Utilisateur = Depends(get_current_user)):
    # Vérifie que l'utilisateur connecté est un administrateur.
    if current_user.role != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Accès refusé : droits administrateur requis."
        )
    return current_user

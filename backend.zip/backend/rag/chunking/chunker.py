# CHUNKING

def create_chunks(text, page_number, chunk_size=1000, overlap=200, start_chunk_id=1):
    """
    Découpe un texte en chunks en essayant de préserver
    les frontières naturelles du texte.

    Paramètres :
    - text : texte nettoyé
    - page_number : numéro de la page d'origine
    - chunk_size : taille approximative maximale
    - overlap : nombre approximatif de caractères conservés
               entre deux chunks

    Retourne :
    une liste de dictionnaires contenant :
    - chunk_id
    - page
    - text
    """

    if not text.strip():
        return []

    if overlap >= chunk_size:
        raise ValueError(
            "L'overlap doit être inférieur à la taille du chunk."
        )

    # On sépare le texte en lignes non vides.
    lines = [
        line.strip()
        for line in text.splitlines()
        if line.strip()
    ]

    chunks = []
    current_chunk = []
    current_length = 0
    chunk_id = start_chunk_id

    for line in lines:

        line_length = len(line)

        # Si l'ajout de la ligne dépasse la taille cible, on termine le chunk actuel.
        if (current_chunk and current_length + line_length + 1 > chunk_size):
            chunk_text = "\n".join(current_chunk).strip()

            chunks.append({
                "chunk_id": chunk_id,
                "page": page_number,
                "text": chunk_text
            })

            chunk_id += 1

            # Création de l'overlap.
            overlap_lines = []
            overlap_length = 0

            for previous_line in reversed(current_chunk):
                if overlap_length + len(previous_line) + 1 > overlap:
                    break

                overlap_lines.insert(0, previous_line)
                overlap_length += len(previous_line) + 1

            current_chunk = overlap_lines
            current_length = overlap_length

        current_chunk.append(line)
        current_length += line_length + 1

    # Ajouter le dernier chunk.
    if current_chunk:
        chunk_text = "\n".join(current_chunk).strip()

        chunks.append({
            "chunk_id": chunk_id,
            "page": page_number,
            "text": chunk_text
        })

    return chunks
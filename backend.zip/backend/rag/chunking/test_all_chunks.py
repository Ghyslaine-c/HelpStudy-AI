#TEST GLOBAL

from rag.extraction.pdf_extractor import extract_text_from_pdf
from rag.cleaning.text_cleaner import clean_text
from rag.chunking.chunker import create_chunks


document = "data/documents/Circuits_logiques_01.pdf"

# 1. Extraction
pages = extract_text_from_pdf(document)

all_chunks = []

next_chunk_id = 1

# 2. Traitement page par page
for page in pages:

    page_number = page["page"]

    # Nettoyage
    cleaned_text = clean_text(page["text"])

    # Chunking
    page_chunks = create_chunks(
        cleaned_text,
        page_number=page_number,
        start_chunk_id=next_chunk_id
    )

    # Ajouter les chunks de cette page
    all_chunks.extend(page_chunks)

    # Préparer l'identifiant suivant
    next_chunk_id += len(page_chunks)


print("Nombre de pages :", len(pages))
print("Nombre total de chunks :", len(all_chunks))


# Afficher quelques statistiques
if all_chunks:
    print("\n--- PREMIER CHUNK ---")
    print("ID :", all_chunks[0]["chunk_id"])
    print("Page :", all_chunks[0]["page"])
    print(all_chunks[0]["text"])

    print("\n--- DERNIER CHUNK ---")
    print("ID :", all_chunks[-1]["chunk_id"])
    print("Page :", all_chunks[-1]["page"])
    print(all_chunks[-1]["text"])
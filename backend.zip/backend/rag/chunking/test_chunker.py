#TEST DES CHUNKS

from rag.extraction.pdf_extractor import extract_text_from_pdf
from rag.cleaning.text_cleaner import clean_text
from rag.chunking.chunker import create_chunks


document = "data/documents/Circuits_logiques_01.pdf"

pages = extract_text_from_pdf(document)

cleaned_text = clean_text(pages[49]["text"])

chunks = create_chunks(
    cleaned_text,
    page_number=50
)

print("Page testee : 50 \n Nombre de chunks :", len(chunks))

for chunk in chunks:
    print("\n" + "=" * 60)
    print("Chunk ID :", chunk["chunk_id"])
    print("Page :", chunk["page"])
    print("=" * 60)
    print(chunk["text"])
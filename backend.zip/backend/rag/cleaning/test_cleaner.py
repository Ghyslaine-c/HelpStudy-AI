#TEST TEXT CLEANER

from rag.extraction.pdf_extractor import extract_text_from_pdf
from rag.cleaning.text_cleaner import clean_text

document = "data/documents/Circuits_logiques_01.pdf"

pages = extract_text_from_pdf(document)

cleaned_pages = []

for page in pages:
    cleaned_text = clean_text(page["text"])

    cleaned_pages.append({
        "page": page["page"],
        "text": cleaned_text
    })

print("Nombre de pages :", len(cleaned_pages))

print("\n--- PAGE 1 ---\n")
print(cleaned_pages[0]["text"])

print("\n--- PAGE 50 ---\n")
print(cleaned_pages[49]["text"])

print("\n--- PAGE 116 ---\n")
print(cleaned_pages[115]["text"])
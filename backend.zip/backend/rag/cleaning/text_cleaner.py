#NETTOYAGE 

import re                #importation du module re pour les expressions régulières

#nettoyage du texte extrait d'un document tout en conservant sa structure
def clean_text(text):
        # 1. Normaliser les espaces et tabulations
    text = re.sub(r"[ \t]+", " ", text)

    # 2. Supprimer les espaces au début et à la fin de chaque ligne
    lines = text.splitlines()
    lines = [line.strip() for line in lines]

    # 3. Supprimer les lignes complètement vides qui se répètent plusieurs fois
    cleaned_lines = []
    previous_line_empty = False

    for line in lines:

        if line == "":
            if not previous_line_empty:
                cleaned_lines.append(line)

            previous_line_empty = True

        else:
            cleaned_lines.append(line)
            previous_line_empty = False

     # 4. Reconstruire le texte
    text = "\n".join(cleaned_lines)

    # 5. Supprimer les espaces inutiles au début et à la fin
    return text.strip()
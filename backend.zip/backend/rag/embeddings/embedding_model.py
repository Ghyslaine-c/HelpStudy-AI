#EMBEDDINGS

from sentence_transformers import SentenceTransformer

#par defaut, on utilise le modèle "paraphrase-multilingual-MiniLM-L12-v2" qui est un modèle multilingue capable de générer des embeddings pour plusieurs langues. Il est basé sur la technologie MiniLM et est optimisé pour les tâches de paraphrase et de similarité sémantique.
MODEL_NAME = "paraphrase-multilingual-MiniLM-L12-v2"

#fonction pour charger le modèle d'embedding
def load_embedding_model():
    
    model = SentenceTransformer(MODEL_NAME)

    return model

#génère un embedding pour un texte donné en utilisant le modèle d'embedding chargé
def generate_embedding(model, text):
    
    embedding = model.encode(text)    #transforme le texte en vecteur numerique.

    return embedding
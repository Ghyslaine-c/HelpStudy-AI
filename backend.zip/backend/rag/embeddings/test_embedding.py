#TEST EMBEDDING

from rag.extraction.pdf_extractor import extract_text_from_pdf
from rag.cleaning.text_cleaner import clean_text
from rag.chunking.chunker import create_chunks
from rag.embeddings.embedding_model import load_embedding_model

#definit le chemin du document PDF à traiter
document = "data/documents/Circuits_logiques_01.pdf"

# Extraction
pages = extract_text_from_pdf(document)

# Nettoyage
cleaned_text = clean_text(pages[49]["text"])

# Chunking
chunks = create_chunks(
    cleaned_text,
    page_number=50
)

print("Nombre de chunks disponibles :", len(chunks))


# Charger le modèle
print("\nChargement du modèle...")

model = load_embedding_model()

print("Modèle chargé.")

# Tester sur les 3 premiers chunks disponibles
test_chunks = chunks[:3]

for chunk in test_chunks:

    embedding = model.encode(chunk["text"])

    print("\n" + "=" * 60)
    print("Chunk ID :", chunk["chunk_id"])
    print("Page :", chunk["page"])
    print("Dimension du vecteur :", len(embedding))
    print("Premiers éléments :", embedding[:10])
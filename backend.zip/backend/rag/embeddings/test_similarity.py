#TEST DE SIMILARITE SEMANTIQUE

from sentence_transformers import SentenceTransformer          #importation de la classe SentenceTransformer pour charger le modèle d'embedding
from sklearn.metrics.pairwise import cosine_similarity          #importation de la fonction cosine_similarity pour calculer la similarité entre les vecteurs d'embedding

# Chargement du modèle
print("Chargement du modèle...")

model = SentenceTransformer("sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2")
print("Modèle chargé.\n")

# 2. Phrases à comparer
phrase_1 = ("Un circuit logique permet de réaliser des opérations booléennes.")
phrase_2 = ("Les circuits logiques effectuent des opérations sur des valeurs booléennes.")
phrase_3 = ("La capitale de la France est Paris.")

# Génération des embeddings
print("Génération des embeddings...")

embeddings = model.encode([phrase_1, phrase_2, phrase_3])

print("Embeddings générés.")
print(f"Dimension des vecteurs : {embeddings.shape[1]}\n")

# Calcul des similarités
similarite_12 = cosine_similarity(
    [embeddings[0]],
    [embeddings[1]]
)[0][0]

similarite_13 = cosine_similarity(
    [embeddings[0]],
    [embeddings[2]]
)[0][0]

# Affichage des résultats
print("=" * 60)
print("TEST DE SIMILARITÉ SÉMANTIQUE")
print("=" * 60)

print("\nPhrase 1 :")
print(phrase_1)

print("\nPhrase 2 :")
print(phrase_2)

print(f"\nSimilarité entre phrase 1 et phrase 2 : {similarite_12:.4f}")

print("\n" + "-" * 60)

print("\nPhrase 1 :")
print(phrase_1)

print("\nPhrase 3 :")
print(phrase_3)

print(f"\nSimilarité entre phrase 1 et phrase 3 : {similarite_13:.4f}")

print("\n" + "=" * 60)
#extraction du pdf pae par page

import pymupdf            #importation de la bibliothèque PyMuPDF pour la manipulation des fichiers PDF
from pathlib import Path

#fonction d'extraction
def extract_text_from_pdf(file_path):

    path = Path(file_path)

    if not path.exists():
        raise FileNotFoundError(
            f"Document introuvable : {file_path}"
        )

    if path.suffix.lower() != ".pdf":
        raise ValueError(
            "Le fichier fourni n'est pas un PDF."
        )

    pages = []

    with pymupdf.open(path) as pdf:

        for page_number, page in enumerate(pdf, start=1):

            text = page.get_text()

            pages.append({
                "page": page_number,
                "text": text
            })

    return pages
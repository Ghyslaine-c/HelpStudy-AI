#TEST PDF EXTRACTOR

from pdf_extractor import extract_text_from_pdf


document = "data/documents/Circuits_logiques_01.pdf"

pages = extract_text_from_pdf(document)

print("Nombre de pages :", len(pages))

print("\n--- PREMIÈRE PAGE ---\n")
print(pages[0]["text"])
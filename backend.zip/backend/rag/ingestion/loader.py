#___INGESTION_____

#importation des modules nécessaires
from pathlib import Path

#fonction pour charger un document à partir d'un chemin de fichier
def load_document(file_path):
    path = Path(file_path)

    if not path.exists():
        raise FileNotFoundError(
            f"Document introuvable : {file_path}"
        )

    if not path.is_file():
        raise ValueError(
            f"Le chemin indiqué n'est pas un fichier : {file_path}"
        )

    return path
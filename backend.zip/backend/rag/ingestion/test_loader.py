#___TEST LOADER___
#importation de la fonction load_document depuis le module rag.ingestion.loader
from loader import load_document

# Test de la fonction load_document
document = load_document(
    "data/documents/Circuits_logiques_01.pdf"
)

print("Document trouvé :", document)
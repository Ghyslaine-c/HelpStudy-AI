#TEST VECTEUR DE RECHERCHE

from app.database import SessionLocal
#import des fonctions nécessaires pour le test
from rag.embeddings.embedding_model import load_embedding_model
from rag.retrieval.vector_search import search_similar_chunks

#fonction principale
def main():

    question = "Qu'est-ce qu'une porte logique ET ?"

    print("Chargement du modèle...")
    model = load_embedding_model()

    db = SessionLocal()

    try:

        results = search_similar_chunks(
            db=db,
            model=model,
            query=question,
            top_k=5
        )

        print("\n========================================")
        print("RESULTATS DE LA RECHERCHE VECTORIELLE")
        print("========================================")

        for rank, (chunk, distance) in enumerate(results, start=1):

            similarity = 1 - distance

            print(f"\n--- RESULTAT {rank} ---")
            print("Chunk :", chunk.chunk_index)
            print("Page :", chunk.page_number)
            print("Distance :", round(distance, 4))
            print("Similarité :", round(similarity, 4))
            print("Texte :")
            print(chunk.contenu[:500])

    finally:

        db.close()


if __name__ == "__main__":
    main()
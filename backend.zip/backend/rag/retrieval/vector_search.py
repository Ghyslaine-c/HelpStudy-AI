#RECHERCHE VECTORIELLE

from sqlalchemy.orm import Session

from app.models import DocumentChunk
from rag.embeddings.embedding_model import generate_embedding

#fonction pour rechercher les chunks les plus similaires à une question utilisateur
def search_similar_chunks(
    db: Session,
    model,
    query: str,
    top_k: int = 5
):
    # 1. Transformer la question en embedding
    query_embedding = generate_embedding(model, query)

    # 2. Recherche vectorielle avec pgvector
    results = (
        db.query(
            DocumentChunk,
            DocumentChunk.embedding.cosine_distance(
                query_embedding.tolist()
            ).label("distance")
        )
        .order_by("distance")
        .limit(top_k)
        .all()
    )

    return results
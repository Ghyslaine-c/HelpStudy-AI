#import des modules pour la session SQLAlchemy
from sqlalchemy.orm import Session

#import des modules pour la base de données et les modèles
from app.database import SessionLocal
from app.models import Document, DocumentChunk

#import des modules pour l'extraction, le nettoyage, le chunking et l'embedding
from rag.extraction.pdf_extractor import extract_text_from_pdf
from rag.cleaning.text_cleaner import clean_text
from rag.chunking.chunker import create_chunks
from rag.embeddings.embedding_model import load_embedding_model

# Configuration
DOCUMENT_PATH = "data/documents/Circuits_logiques_01.pdf"
DOCUMENT_TITLE = "Circuits logiques"
DOCUMENT_CATEGORY = "cours"

# 1. Créer les chunks
def create_all_chunks():
    pages = extract_text_from_pdf(DOCUMENT_PATH)
    all_chunks = []
    next_chunk_id = 1

    for page in pages:
        page_number = page["page"]

        # Nettoyage
        cleaned_text = clean_text(page["text"])

        # Chunking
        page_chunks = create_chunks(
            cleaned_text,
            page_number=page_number,
            start_chunk_id=next_chunk_id
        )

        all_chunks.extend(page_chunks)
        next_chunk_id += len(page_chunks)

    return all_chunks

# 2. Enregistrer dans PostgreSQL
def save_document_and_chunks(db: Session, chunks, model):

    # Vérifier si le document existe déjà
    document = (
        db.query(Document)
        .filter(Document.chemin_fichier_url == DOCUMENT_PATH)
        .first()
    )

    if document is None:

        document = Document(
            titre=DOCUMENT_TITLE,
            categorie=DOCUMENT_CATEGORY,
            chemin_fichier_url=DOCUMENT_PATH,
            contenu_texte=None
        )

        db.add(document)

        # Générer l'ID du document
        db.flush()
        print("Document créé avec ID :", document.id)

    else:
        print("Document déjà existant, ID :", document.id)

    # Vérifier si les chunks existent déjà
    existing_chunks = (
        db.query(DocumentChunk)
        .filter(DocumentChunk.document_id == document.id)
        .count()
    )

    if existing_chunks > 0:
        print(f"Attention : {existing_chunks} chunks existent déjà "f"pour ce document.")

        return document, existing_chunks

    # Générer les embeddings
    texts = [chunk["text"] for chunk in chunks]
    print(f"Génération des embeddings pour {len(texts)} chunks...")

    embeddings = model.encode(
        texts,
        convert_to_numpy=True,
        show_progress_bar=True
    )

    print("Embeddings générés.")

    # Créer les DocumentChunk
    for chunk, embedding in zip(chunks, embeddings):

        document_chunk = DocumentChunk(
            document_id=document.id,
            contenu=chunk["text"],
            chunk_index=chunk["chunk_id"],
            page_number=chunk["page"],
            embedding=embedding.tolist()
        )

        db.add(document_chunk)

    # Sauvegarder
    db.commit()

    print(f"{len(chunks)} chunks enregistrés dans PostgreSQL.")

    return document, len(chunks)

# 3. Programme principal
def main():

    print("========================================")
    print("HELPSTUDY AI - INGESTION RAG")
    print("========================================")

    # Création des chunks
    print("\n[1/4] Extraction + nettoyage + chunking...")

    chunks = create_all_chunks()

    print(f"Nombre total de chunks : {len(chunks)}")

    # Charger le modèle
    print("\n[2/4] Chargement du modèle d'embedding...")

    model = load_embedding_model()

    print("Modèle chargé.")

    # Connexion PostgreSQL
    print("\n[3/4] Connexion à PostgreSQL...")

    db = SessionLocal()

    try:

        document, count = save_document_and_chunks(
            db,
            chunks,
            model
        )

        print("\n[4/4] Terminé.")

        print("----------------------------------------")
        print("Document ID :", document.id)
        print("Chunks :", count)
        print("----------------------------------------")

    except Exception as e:

        db.rollback()

        print("\nERREUR :", e)

        raise

    finally:

        db.close()

if __name__ == "__main__":
    main()
CREATE TABLE recommandations (
    id SERIAL PRIMARY KEY,
    etudiant_id INT REFERENCES etudiants(id) ON DELETE CASCADE NOT NULL,
    contenu_recommandation TEXT NOT NULL,
    date_generation TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

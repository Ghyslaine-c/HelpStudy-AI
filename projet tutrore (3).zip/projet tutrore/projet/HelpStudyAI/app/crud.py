
from sqlalchemy.orm import Session
from app import models, schemas

# --- CRUD Utilisateurs ---
def create_utilisateur(db: Session, user: schemas.UtilisateurCreate):
    db_user = models.Utilisateur(
        nom=user.nom,
        prenom=user.prenom,
        email=user.email,
        mot_de_passe_hash=user.mot_de_passe, 
        role=user.role,
        promotion=user.promotion,
        faculte=user.faculte
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

def get_utilisateurs(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.Utilisateur).offset(skip).limit(limit).all()

# --- CRUD Documents ---
def create_document(db: Session, doc: schemas.DocumentCreate):
    db_doc = models.Document(**doc.model_dump())
    db.add(db_doc)
    db.commit()
    db.refresh(db_doc)
    return db_doc

def get_documents(db: Session):
    return db.query(models.Document).all()

# --- CRUD Conversations & Messages ---
def create_conversation(db: Session, user_id: int, conv: schemas.ConversationCreate):
    db_conv = models.Conversation(utilisateur_id=user_id, titre=conv.titre)
    db.add(db_conv)
    db.commit()
    db.refresh(db_conv)
    return db_conv

def add_message(db: Session, conv_id: int, msg: schemas.MessageCreate):
    db_msg = models.Message(conversation_id=conv_id, **msg.model_dump())
    db.add(db_msg)
    db.commit()
    db.refresh(db_msg)
    return db_msg



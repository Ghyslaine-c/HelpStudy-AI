from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from dotenv import load_dotenv
import os

# Charger les variables du fichier .env
load_dotenv()

# Récupérer l'URL de la base de données
DATABASE_URL = os.getenv("DATABASE_URL")

# Créer la connexion à PostgreSQL
engine = create_engine(DATABASE_URL)

# Créer une session
SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine
)

# Classe de base pour les modèles
Base = declarative_base()
# fonction dependance pour recuperer la session DB dans les retours FastAPI
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

from fastapi import FastAPI, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import text
from typing import List

from app.database import engine, Base, get_db
from app import models, schemas, crud

app = FastAPI(
    title="HelpStudy AI API",
    description="API d'assistance académique intelligente pour l'UCB",
    version="1.0.0"
)

# Création automatique de toutes les tables PostgreSQL définies dans models.py au démarrage
@app.on_event("startup")
def startup_event():
    Base.metadata.create_all(bind=engine)

# --- Routes de Vérification ---
@app.get("/", tags=["Santé"])
def accueil():
    return {"message": "Bienvenue sur HelpStudy AI API", "status": "Serveur opérationnel"}

@app.get("/test-db", tags=["Santé"])
def test_db():
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return {"message": "Connexion PostgreSQL réussie"}
    except Exception as e:
        return {"erreur": str(e)}

# --- Endpoints Utilisateurs ---
@app.post("/utilisateurs/", response_model=schemas.UtilisateurResponse, tags=["Utilisateurs"])
def reponse_creer_utilisateur(user: schemas.UtilisateurCreate, db: Session = Depends(get_db)):
    return crud.create_utilisateur(db=db, user=user)

@app.get("/utilisateurs/", response_model=List[schemas.UtilisateurResponse], tags=["Utilisateurs"])
def reponse_lire_utilisateurs(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    return crud.get_utilisateurs(db=db, skip=skip, limit=limit)

# --- Endpoints Documents ---
@app.post("/documents/", response_model=schemas.DocumentResponse, tags=["Documents"])
def reponse_ajouter_document(doc: schemas.DocumentCreate, db: Session = Depends(get_db)):
    return crud.create_document(db=db, doc=doc)

@app.get("/documents/", response_model=List[schemas.DocumentResponse], tags=["Documents"])
def reponse_liste_documents(db: Session = Depends(get_db)):
    return crud.get_documents(db=db)

# --- Endpoints Chat ---
@app.post("/utilisateurs/{user_id}/conversations/", response_model=schemas.ConversationResponse, tags=["Chat"])
def reponse_creer_conversation(user_id: int, conv: schemas.ConversationCreate, db: Session = Depends(get_db)):
    return crud.create_conversation(db=db, user_id=user_id, conv=conv)

@app.post("/conversations/{conv_id}/messages/", response_model=schemas.MessageResponse, tags=["Chat"])
def reponse_ajouter_message(conv_id: int, msg: schemas.MessageCreate, db: Session = Depends(get_db)):
    return crud.add_message(db=db, conv_id=conv_id, msg=msg)
 

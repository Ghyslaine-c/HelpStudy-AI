from sqlalchemy import Column, Integer, String, Text, ForeignKey, DateTime, Float, ARRAY
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
#from pgvector.sqlalchemy import Vector
from app.database import Base

class Utilisateur(Base):
    __tablename__ = "utilisateurs"

    id = Column(Integer, primary_key=True, index=True)
    nom = Column(String(50), nullable=False)
    prenom = Column(String(50), nullable=False)
    email = Column(String(100), unique=True, index=True, nullable=False)
    mot_de_passe_hash = Column(Text, nullable=False)
    role = Column(String(20), default="etudiant")
    promotion = Column(String(50), nullable=True)
    faculte = Column(String(100), nullable=True)
    date_creation = Column(DateTime(timezone=True), server_default=func.now())

    conversations = relationship("Conversation", back_populates="utilisateur", cascade="all, delete-orphan")
    evenements = relationship("Evenement", back_populates="utilisateur", cascade="all, delete-orphan")
    recommandations = relationship("Recommandation", back_populates="utilisateur", cascade="all, delete-orphan")

class Document(Base):
    __tablename__ = "documents"

    id = Column(Integer, primary_key=True, index=True)
    titre = Column(String(255), nullable=False)
    categorie = Column(String(100), nullable=False)
    chemin_fichier_url = Column(Text, nullable=False)
    contenu_texte = Column(Text, nullable=True)
    embedding = Column(ARRAY(float), nullable=True)
    date_versement = Column(DateTime(timezone=True), server_default=func.now())

class Conversation(Base):
    __tablename__ = "conversations"

    id = Column(Integer, primary_key=True, index=True)
    utilisateur_id = Column(Integer, ForeignKey("utilisateurs.id", ondelete="CASCADE"), nullable=False)
    titre = Column(String(150), default="Nouvelle discussion")
    date_creation = Column(DateTime(timezone=True), server_default=func.now())

    utilisateur = relationship("Utilisateur", back_populates="conversations")
    messages = relationship("Message", back_populates="conversation", cascade="all, delete-orphan")

class Message(Base):
    __tablename__ = "messages"

    id = Column(Integer, primary_key=True, index=True)
    conversation_id = Column(Integer, ForeignKey("conversations.id", ondelete="CASCADE"), nullable=False)
    role_expediteur = Column(String(10), nullable=False)
    contenu = Column(Text, nullable=False)
    date_envoi = Column(DateTime(timezone=True), server_default=func.now())

    conversation = relationship("Conversation", back_populates="messages")

class Evenement(Base):
    __tablename__ = "evenements"

    id = Column(Integer, primary_key=True, index=True)
    utilisateur_id = Column(Integer, ForeignKey("utilisateurs.id", ondelete="CASCADE"), nullable=False)
    titre = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    date_debut = Column(DateTime, nullable=False)
    date_fin = Column(DateTime, nullable=True)
    statut = Column(String(20), default="A faire")

    utilisateur = relationship("Utilisateur", back_populates="evenements")

class Recommandation(Base):
    __tablename__ = "recommandations"

    id = Column(Integer, primary_key=True, index=True)
    utilisateur_id = Column(Integer, ForeignKey("utilisateurs.id", ondelete="CASCADE"), nullable=False)
    contenu = Column(Text, nullable=False)
    date_generation = Column(DateTime(timezone=True), server_default=func.now())

    utilisateur = relationship("Utilisateur", back_populates="recommandations")


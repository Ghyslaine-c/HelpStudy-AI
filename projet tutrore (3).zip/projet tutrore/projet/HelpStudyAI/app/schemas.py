from pydantic import BaseModel
from datetime import datetime
from typing import Optional, List

# --- Utilisateur ---
class UtilisateurBase(BaseModel):
    nom: str
    prenom: str
    email: str
    role: Optional[str] = "etudiant"
    promotion: Optional[str] = None
    faculte: Optional[str] = None

class UtilisateurCreate(UtilisateurBase):
    mot_de_passe: str

class UtilisateurResponse(UtilisateurBase):
    id: int
    date_creation: datetime

    class Config:
        from_attributes = True

# --- Document ---
class DocumentCreate(BaseModel):
    titre: str
    categorie: str
    chemin_fichier_url: str
    contenu_texte: Optional[str] = None

class DocumentResponse(DocumentCreate):
    id: int
    date_versement: datetime

    class Config:
        from_attributes = True

# --- Message & Conversation ---
class MessageCreate(BaseModel):
    role_expediteur: str
    contenu: str

class MessageResponse(MessageCreate):
    id: int
    date_envoi: datetime

    class Config:
        from_attributes = True

class ConversationCreate(BaseModel):
    titre: Optional[str] = "Nouvelle discussion"

class ConversationResponse(BaseModel):
    id: int
    utilisateur_id: int
    titre: str
    date_creation: datetime
    messages: List[MessageResponse] = []

    class Config:
        from_attributes = True


